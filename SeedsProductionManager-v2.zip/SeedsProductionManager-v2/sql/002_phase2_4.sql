-- Seeds Production Manager v2 — phases 2–4 (tracking, money, farmer login, photos)
-- Additive only: no existing table or column is removed.

-- ---------- helpers ----------
alter table public.spm_farmers add column if not exists auth_id uuid unique references auth.users(id) on delete set null;
alter table public.spm_farmers add column if not exists photo text not null default '';
alter table public.spm_farmers add column if not exists id_photo text not null default '';
alter table public.spm_farmers add column if not exists bank jsonb not null default '{}'::jsonb;
alter table public.spm_users add column if not exists device_id text not null default '';
alter table public.spm_users add column if not exists lang text not null default 'en';
alter table public.spm_users add column if not exists consent_at timestamptz;
alter table public.spm_users add column if not exists signout_after timestamptz;
alter table public.spm_fields add column if not exists boundary jsonb;
alter table public.spm_fields add column if not exists expected_kg_per_acre numeric;
alter table public.spm_fields add column if not exists assigned_to uuid references public.spm_users(id);

create or replace function spm_private.me_farmer() returns uuid language sql stable security definer set search_path to '' as $$
  select id from public.spm_farmers where auth_id = (select auth.uid()) and deleted_at is null $$;

-- a staff member can see a person if that person is themselves or below them
create or replace function spm_private.can_see_person(t uuid) returns boolean language sql stable security definer set search_path to '' as $$
  select t is not null and (t = spm_private.me_id() or spm_private.can_see_user(t)) $$;

-- can the caller see this farmer (staff via hierarchy, farmer = self)
create or replace function spm_private.farmer_visible(fid uuid) returns boolean language sql stable security definer set search_path to '' as $$
  select exists (select 1 from public.spm_farmers f where f.id = fid and f.deleted_at is null and
    (f.auth_id = (select auth.uid()) or spm_private.me_role() = 'owner'
     or spm_private.can_see_farmer(f.company_id, f.organizer_id, f.sub_organizer_id, f.field_staff_id, f.created_by))) $$;

-- farmers read their own record and fields
create policy spm_farmers_self on public.spm_farmers for select to authenticated using (auth_id = (select auth.uid()));
create policy spm_fields_self on public.spm_fields for select to authenticated using (farmer_id = spm_private.me_farmer());
create policy spm_marks_self on public.spm_event_marks for select to authenticated
  using (exists (select 1 from public.spm_fields x where x.id = field_id and x.farmer_id = spm_private.me_farmer()));
create policy spm_seasons_farmer on public.spm_seasons for select to authenticated using (spm_private.me_farmer() is not null);
create policy spm_varieties_farmer on public.spm_varieties for select to authenticated using (spm_private.me_farmer() is not null);
create policy spm_ve_farmer on public.spm_variety_events for select to authenticated using (spm_private.me_farmer() is not null);
create policy spm_companies_farmer on public.spm_companies for select to authenticated using (spm_private.me_farmer() is not null);
create policy spm_settings_farmer on public.spm_settings for select to authenticated using (spm_private.me_farmer() is not null);
-- farmer can see the organizer they work with (name + phone only is shown by the app)
create policy spm_users_farmer on public.spm_users for select to authenticated
  using (id = (select organizer_id from public.spm_farmers where auth_id = (select auth.uid())));

-- ---------- tracking ----------
create table if not exists public.spm_attendance (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.spm_users(id) default spm_private.me_id(),
  day date not null default (now() at time zone 'Asia/Kolkata')::date,
  in_at timestamptz not null default now(), in_lat double precision, in_lng double precision, in_acc real,
  out_at timestamptz, out_lat double precision, out_lng double precision, out_acc real,
  km numeric not null default 0, note text not null default '',
  unique (user_id, day));
create table if not exists public.spm_track_points (
  id bigserial primary key,
  user_id uuid not null references public.spm_users(id) default spm_private.me_id(),
  at timestamptz not null default now(), lat double precision not null, lng double precision not null,
  acc real, speed real, battery real, mock boolean not null default false);
create index if not exists spm_track_points_user_at on public.spm_track_points(user_id, at);
create table if not exists public.spm_visits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.spm_users(id) default spm_private.me_id(),
  field_id uuid references public.spm_fields(id), farmer_id uuid references public.spm_farmers(id),
  start_at timestamptz not null default now(), end_at timestamptz,
  lat double precision, lng double precision, acc real, end_lat double precision, end_lng double precision,
  dist_m real, inside boolean, minutes real,
  stage text not null default '', condition text not null default '',
  plant_count int, detassel_pct int, rogue_done boolean, offtype_count int,
  irrigation_status text not null default '', labour_count int, moisture real, grain text not null default '',
  note text not null default '', photos text[] not null default '{}', flags text[] not null default '{}');
create index if not exists spm_visits_user on public.spm_visits(user_id, start_at);
create index if not exists spm_visits_field on public.spm_visits(field_id, start_at);

create table if not exists public.spm_reports (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('disease','pest','complaint','isolation','other')),
  farmer_id uuid references public.spm_farmers(id), field_id uuid references public.spm_fields(id),
  note text not null default '', photos text[] not null default '{}',
  lat double precision, lng double precision,
  status text not null default 'open' check (status in ('open','in_progress','closed')),
  by_user uuid default spm_private.me_id(), by_farmer uuid default spm_private.me_farmer(),
  at timestamptz not null default now(), reply text not null default '', closed_by uuid, closed_at timestamptz);

create table if not exists public.spm_expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.spm_users(id) default spm_private.me_id(),
  day date not null default current_date, kind text not null default 'fuel', amount numeric not null check (amount >= 0),
  note text not null default '', photo text not null default '',
  status text not null default 'waiting' check (status in ('waiting','approved','rejected')),
  decided_by uuid, decided_at timestamptz);
create table if not exists public.spm_leaves (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.spm_users(id) default spm_private.me_id(),
  from_day date not null, to_day date not null, reason text not null default '',
  status text not null default 'waiting' check (status in ('waiting','approved','rejected')),
  decided_by uuid, decided_at timestamptz, at timestamptz not null default now());
create table if not exists public.spm_tasks (
  id uuid primary key default gen_random_uuid(),
  assigned_to uuid not null references public.spm_users(id), created_by uuid default spm_private.me_id(),
  title text not null, note text not null default '', due date, farmer_id uuid references public.spm_farmers(id),
  done_at timestamptz, done_note text not null default '', at timestamptz not null default now());
create table if not exists public.spm_comments (
  id uuid primary key default gen_random_uuid(),
  entity text not null check (entity in ('farmer','field','event','report')), entity_id uuid not null,
  body text not null, by_user uuid default spm_private.me_id(), at timestamptz not null default now());
create table if not exists public.spm_calls (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default spm_private.me_id() references public.spm_users(id),
  farmer_id uuid not null references public.spm_farmers(id), kind text not null default 'call',
  note text not null default '', at timestamptz not null default now());
create table if not exists public.spm_logins (
  id bigserial primary key, user_id uuid default spm_private.me_id(), farmer_id uuid default spm_private.me_farmer(),
  at timestamptz not null default now(), device text not null default '', device_id text not null default '');

-- ---------- money ----------
create table if not exists public.spm_products (
  id uuid primary key default gen_random_uuid(), name text not null,
  kind text not null default 'other' check (kind in ('seed','fertilizer','pesticide','other')),
  unit text not null default 'kg', rate numeric not null default 0, active boolean not null default true,
  created_at timestamptz not null default now());
create table if not exists public.spm_stock_moves (
  id uuid primary key default gen_random_uuid(), product_id uuid not null references public.spm_products(id),
  qty numeric not null, kind text not null check (kind in ('in','out','adjust')),
  farmer_id uuid references public.spm_farmers(id), ledger_id uuid, note text not null default '',
  by_user uuid default spm_private.me_id(), at timestamptz not null default now());
create table if not exists public.spm_ledger (
  id uuid primary key default gen_random_uuid(),
  farmer_id uuid not null references public.spm_farmers(id), season_id uuid references public.spm_seasons(id),
  kind text not null check (kind in ('advance','input','deduction','payment','harvest')),
  amount numeric not null default 0, qty numeric, product_id uuid references public.spm_products(id),
  note text not null default '', day date not null default current_date,
  status text not null default 'requested' check (status in ('requested','approved','rejected','paid')),
  by_user uuid default spm_private.me_id(), by_farmer uuid default spm_private.me_farmer(),
  decided_by uuid, decided_at timestamptz, at timestamptz not null default now());
create table if not exists public.spm_harvests (
  id uuid primary key default gen_random_uuid(),
  field_id uuid not null references public.spm_fields(id), farmer_id uuid not null references public.spm_farmers(id),
  day date not null default current_date, weight_kg numeric not null default 0, moisture real,
  lot_no text not null default '', germination real, purity real, rate numeric, note text not null default '',
  by_user uuid default spm_private.me_id(), at timestamptz not null default now());
create table if not exists public.spm_agreements (
  id uuid primary key default gen_random_uuid(),
  farmer_id uuid not null references public.spm_farmers(id), company_id uuid references public.spm_companies(id),
  season_id uuid references public.spm_seasons(id), no text not null default '', made_on date not null default current_date,
  signature text not null default '', by_user uuid default spm_private.me_id(), at timestamptz not null default now(),
  unique (farmer_id, season_id));
create table if not exists public.spm_notices (
  id uuid primary key default gen_random_uuid(), title text not null, body text not null default '',
  for_farmers boolean not null default true, for_staff boolean not null default true,
  by_user uuid default spm_private.me_id(), at timestamptz not null default now());
create table if not exists public.spm_ratings (
  id uuid primary key default gen_random_uuid(), farmer_id uuid not null default spm_private.me_farmer(),
  organizer_id uuid, stars int not null check (stars between 1 and 5), note text not null default '',
  at timestamptz not null default now());
create table if not exists public.spm_referrals (
  id uuid primary key default gen_random_uuid(), farmer_id uuid default spm_private.me_farmer(),
  name text not null, mobile text not null, village text not null default '', next_season boolean not null default false,
  at timestamptz not null default now());

-- agreement number: <COMPANY CODE>/<season short>/0001, per company and season
create or replace function spm_private.agreement_no() returns trigger language plpgsql security definer set search_path to '' as $$
declare c text; n int;
begin
  if new.no <> '' then return new; end if;
  select upper(coalesce(nullif(code,''),'AG')) into c from public.spm_companies where id = new.company_id;
  perform pg_advisory_xact_lock(hashtext(coalesce(new.company_id::text,'') || coalesce(new.season_id::text,'')));
  select count(*) + 1 into n from public.spm_agreements where company_id is not distinct from new.company_id and season_id is not distinct from new.season_id;
  new.no := coalesce(c,'AG') || '/' || to_char(now(),'YY') || '/' || lpad(n::text, 4, '0');
  return new;
end $$;
create trigger spm_agreement_no before insert on public.spm_agreements for each row execute function spm_private.agreement_no();

-- input issue approved -> stock goes out
create or replace function spm_private.ledger_stock() returns trigger language plpgsql security definer set search_path to '' as $$
begin
  if new.kind = 'input' and new.product_id is not null and new.qty is not null
     and new.status in ('approved','paid') and (tg_op = 'INSERT' or old.status not in ('approved','paid')) then
    insert into public.spm_stock_moves(product_id, qty, kind, farmer_id, ledger_id, note, by_user)
    values (new.product_id, new.qty, 'out', new.farmer_id, new.id, 'Issued to farmer', spm_private.me_id());
  end if;
  return null;
end $$;
create trigger spm_ledger_stock after insert or update on public.spm_ledger for each row execute function spm_private.ledger_stock();

-- money decisions (approve / reject / mark paid)
create or replace function public.spm_money_decide(p_id uuid, p_status text, p_note text default '') returns text
language plpgsql security definer set search_path to '' as $$
declare f uuid;
begin
  if p_status not in ('approved','rejected','paid') then raise exception 'Unknown decision'; end if;
  select farmer_id into f from public.spm_ledger where id = p_id;
  if f is null or not spm_private.can_approve_farmer(f) then raise exception 'You cannot decide this entry'; end if;
  if p_status = 'paid' and spm_private.me_role() <> 'owner' then raise exception 'Only the owner can mark paid'; end if;
  update public.spm_ledger set status = p_status, decided_by = spm_private.me_id(), decided_at = now(),
    note = case when p_note <> '' then note || ' · ' || p_note else note end where id = p_id;
  return p_status;
end $$;

-- staff decisions on expenses and leaves (by anyone above the person)
create or replace function public.spm_staff_decide(p_kind text, p_id uuid, p_status text) returns text
language plpgsql security definer set search_path to '' as $$
declare u uuid;
begin
  if p_status not in ('approved','rejected') then raise exception 'Unknown decision'; end if;
  if p_kind = 'expense' then select user_id into u from public.spm_expenses where id = p_id;
  elsif p_kind = 'leave' then select user_id into u from public.spm_leaves where id = p_id;
  else raise exception 'Unknown entry'; end if;
  if u is null or u = spm_private.me_id() or not spm_private.can_see_user(u) then raise exception 'You cannot decide this entry'; end if;
  if p_kind = 'expense' then update public.spm_expenses set status = p_status, decided_by = spm_private.me_id(), decided_at = now() where id = p_id;
  else update public.spm_leaves set status = p_status, decided_by = spm_private.me_id(), decided_at = now() where id = p_id; end if;
  return p_status;
end $$;

-- ---------- row level security ----------
do $$ declare t text; begin
  foreach t in array array['spm_attendance','spm_track_points','spm_visits','spm_reports','spm_expenses','spm_leaves','spm_tasks',
    'spm_comments','spm_calls','spm_logins','spm_products','spm_stock_moves','spm_ledger','spm_harvests','spm_agreements',
    'spm_notices','spm_ratings','spm_referrals'] loop
    execute format('alter table public.%I enable row level security', t);
  end loop; end $$;

-- own rows + rows of people below (never above)
create policy att_read on public.spm_attendance for select to authenticated using (spm_private.can_see_person(user_id));
create policy att_ins on public.spm_attendance for insert to authenticated with check (user_id = spm_private.me_id());
create policy att_upd on public.spm_attendance for update to authenticated using (user_id = spm_private.me_id()) with check (user_id = spm_private.me_id());
create policy tp_read on public.spm_track_points for select to authenticated using (spm_private.can_see_person(user_id));
create policy tp_ins on public.spm_track_points for insert to authenticated with check (user_id = spm_private.me_id());
create policy vis_read on public.spm_visits for select to authenticated using (spm_private.can_see_person(user_id));
create policy vis_ins on public.spm_visits for insert to authenticated with check (user_id = spm_private.me_id());
create policy vis_upd on public.spm_visits for update to authenticated using (user_id = spm_private.me_id()) with check (user_id = spm_private.me_id());
create policy rep_read on public.spm_reports for select to authenticated using (
  spm_private.can_see_person(by_user) or (farmer_id is not null and spm_private.farmer_visible(farmer_id)) or by_farmer = spm_private.me_farmer());
create policy rep_ins on public.spm_reports for insert to authenticated with check (
  (by_user = spm_private.me_id() and (farmer_id is null or spm_private.farmer_visible(farmer_id)))
  or (by_farmer = spm_private.me_farmer() and farmer_id = spm_private.me_farmer()));
create policy rep_upd on public.spm_reports for update to authenticated using (
  spm_private.me_id() is not null and (farmer_id is null or spm_private.farmer_visible(farmer_id)));
create policy exp_read on public.spm_expenses for select to authenticated using (spm_private.can_see_person(user_id));
create policy exp_ins on public.spm_expenses for insert to authenticated with check (user_id = spm_private.me_id());
create policy lv_read on public.spm_leaves for select to authenticated using (spm_private.can_see_person(user_id));
create policy lv_ins on public.spm_leaves for insert to authenticated with check (user_id = spm_private.me_id());
create policy task_read on public.spm_tasks for select to authenticated using (spm_private.can_see_person(assigned_to) or created_by = spm_private.me_id());
create policy task_ins on public.spm_tasks for insert to authenticated with check (spm_private.can_see_user(assigned_to) and assigned_to <> spm_private.me_id() or spm_private.me_role() = 'owner');
create policy task_upd on public.spm_tasks for update to authenticated using (assigned_to = spm_private.me_id() or created_by = spm_private.me_id());
create policy com_read on public.spm_comments for select to authenticated using (spm_private.me_id() is not null);
create policy com_ins on public.spm_comments for insert to authenticated with check (by_user = spm_private.me_id());
create policy call_read on public.spm_calls for select to authenticated using (spm_private.can_see_person(user_id));
create policy call_ins on public.spm_calls for insert to authenticated with check (user_id = spm_private.me_id() and spm_private.farmer_visible(farmer_id));
create policy log_read on public.spm_logins for select to authenticated using (spm_private.me_role() = 'owner' or spm_private.can_see_person(user_id));
create policy log_ins on public.spm_logins for insert to authenticated with check (user_id = spm_private.me_id() or farmer_id = spm_private.me_farmer());
create policy prod_read on public.spm_products for select to authenticated using (true);
create policy prod_write on public.spm_products for all to authenticated using (spm_private.me_role() = 'owner') with check (spm_private.me_role() = 'owner');
create policy sm_read on public.spm_stock_moves for select to authenticated using (spm_private.me_id() is not null);
create policy sm_ins on public.spm_stock_moves for insert to authenticated with check (spm_private.me_role() = 'owner');
create policy led_read on public.spm_ledger for select to authenticated using (spm_private.farmer_visible(farmer_id));
create policy led_ins on public.spm_ledger for insert to authenticated with check (
  status = 'requested' and (spm_private.can_edit_farmer(farmer_id) or (farmer_id = spm_private.me_farmer() and kind in ('advance','input')))
  or (spm_private.me_role() = 'owner'));
create policy hv_read on public.spm_harvests for select to authenticated using (spm_private.farmer_visible(farmer_id));
create policy hv_ins on public.spm_harvests for insert to authenticated with check (spm_private.can_edit_farmer(farmer_id));
create policy hv_upd on public.spm_harvests for update to authenticated using (spm_private.can_edit_farmer(farmer_id));
create policy ag_read on public.spm_agreements for select to authenticated using (spm_private.farmer_visible(farmer_id));
create policy ag_ins on public.spm_agreements for insert to authenticated with check (spm_private.can_edit_farmer(farmer_id));
create policy ag_upd on public.spm_agreements for update to authenticated using (spm_private.can_edit_farmer(farmer_id));
create policy nt_read on public.spm_notices for select to authenticated using (
  (for_staff and spm_private.me_id() is not null) or (for_farmers and spm_private.me_farmer() is not null) or spm_private.me_role() = 'owner');
create policy nt_write on public.spm_notices for all to authenticated using (spm_private.me_role() = 'owner') with check (spm_private.me_role() = 'owner');
create policy rt_ins on public.spm_ratings for insert to authenticated with check (farmer_id = spm_private.me_farmer());
create policy rt_read on public.spm_ratings for select to authenticated using (spm_private.me_role() = 'owner' or farmer_id = spm_private.me_farmer());
create policy rf_ins on public.spm_referrals for insert to authenticated with check (farmer_id = spm_private.me_farmer());
create policy rf_read on public.spm_referrals for select to authenticated using (spm_private.me_id() is not null or farmer_id = spm_private.me_farmer());

-- audit trail on money and tracking decisions
do $$ declare t text; begin
  foreach t in array array['spm_ledger','spm_harvests','spm_agreements','spm_products','spm_stock_moves','spm_expenses','spm_leaves','spm_notices','spm_reports'] loop
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function spm_private.audit()', t || '_audit', t);
  end loop; end $$;

-- ---------- photos ----------
insert into storage.buckets (id, name, public) values ('spm-photos','spm-photos', false) on conflict (id) do nothing;
create policy spm_photos_read on storage.objects for select to authenticated using (bucket_id = 'spm-photos');
create policy spm_photos_ins on storage.objects for insert to authenticated
  with check (bucket_id = 'spm-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);

-- demo buttons on the sign-in screen follow this one setting (readable before sign-in)
create policy spm_settings_demo_flag on public.spm_settings for select to anon, authenticated using (key = 'demo_login');
insert into public.spm_settings(key, value) values ('demo_login', 'true'::jsonb) on conflict (key) do nothing;
