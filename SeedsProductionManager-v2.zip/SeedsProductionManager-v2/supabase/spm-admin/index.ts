// spm-admin: the only place a secret key is used. It runs on the server, never in the app.
// Owner (and Admin) only: create staff/farmer logins, reset passwords or PINs.
import { createClient } from 'npm:@supabase/supabase-js@2';

const STAFF_DOMAIN = 'staff.cropline.in';
const FARMER_DOMAIN = 'farmer.cropline.in';
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const url = Deno.env.get('SUPABASE_URL')!;
    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { auth: { persistSession: false } });
    const token = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
    if (!token) return json({ error: 'Not signed in' }, 401);
    const { data: who, error: whoErr } = await admin.auth.getUser(token);
    if (whoErr || !who?.user) return json({ error: 'Not signed in' }, 401);

    const { data: caller } = await admin.from('spm_users').select('id, role, active, is_admin').eq('auth_id', who.user.id).maybeSingle();
    if (!caller || !caller.active || caller.role !== 'owner') return json({ error: 'Only the owner can do this' }, 403);

    const body = await req.json().catch(() => ({}));
    const password = String(body.password || '');

    // ---- farmer logins: mobile number + PIN ----
    if (body.action === 'farmer_login' || body.action === 'farmer_pin') {
      const farmerId = String(body.farmer_id || '');
      if (!/^[0-9a-f-]{36}$/i.test(farmerId)) return json({ error: 'Unknown farmer' }, 400);
      if (!/^\d{6,8}$/.test(password)) return json({ error: 'PIN must be 6 to 8 digits' }, 400);
      const { data: f } = await admin.from('spm_farmers').select('id, mobile, auth_id, name').eq('id', farmerId).maybeSingle();
      if (!f) return json({ error: 'Unknown farmer' }, 404);
      if (body.action === 'farmer_pin') {
        if (!f.auth_id) return json({ error: 'This farmer has no login yet' }, 409);
        const { error } = await admin.auth.admin.updateUserById(f.auth_id, { password });
        return error ? json({ error: 'Could not change the PIN' }, 500) : json({ ok: true });
      }
      if (f.auth_id) return json({ error: 'This farmer already has a login' }, 409);
      const mobile = String(f.mobile || '').replace(/\D/g, '').slice(-10);
      if (mobile.length !== 10) return json({ error: 'Add a 10-digit mobile number first' }, 400);
      const { data: made, error: mkErr } = await admin.auth.admin.createUser({
        email: `${mobile}@${FARMER_DOMAIN}`, password, email_confirm: true, user_metadata: { app: 'spm', kind: 'farmer' },
      });
      if (mkErr || !made?.user) return json({ error: mkErr?.message?.includes('registered') ? 'This mobile already has a login' : 'Could not create the login' }, 409);
      const { error: linkErr } = await admin.from('spm_farmers').update({ auth_id: made.user.id }).eq('id', farmerId);
      if (linkErr) { await admin.auth.admin.deleteUser(made.user.id); return json({ error: 'Could not link the login' }, 500); }
      return json({ ok: true, login: mobile });
    }

    // ---- staff logins ----
    const userId = String(body.user_id || '');
    if (!/^[0-9a-f-]{36}$/i.test(userId)) return json({ error: 'Unknown person' }, 400);
    const { data: target } = await admin.from('spm_users').select('id, auth_id, username, role, is_admin').eq('id', userId).maybeSingle();
    if (!target) return json({ error: 'Unknown person' }, 404);
    if (target.is_admin && !caller.is_admin) return json({ error: 'Only the admin can change the admin login' }, 403);

    if (body.action === 'force_signout') {
      await admin.from('spm_users').update({ signout_after: new Date().toISOString(), device_id: '' }).eq('id', userId);
      return json({ ok: true });
    }
    if (body.action === 'reset_device') {
      await admin.from('spm_users').update({ device_id: '' }).eq('id', userId);
      return json({ ok: true });
    }
    if (password.length < 8 || password.length > 72) return json({ error: 'Password needs 8 to 72 characters' }, 400);

    if (body.action === 'create_login') {
      if (target.auth_id) return json({ error: 'This person already has a login' }, 409);
      const username = String(body.username || '').trim().toLowerCase();
      if (!/^[a-z0-9._-]{3,30}$/.test(username)) return json({ error: 'User ID: 3 to 30 small letters, numbers, dot or dash' }, 400);
      const { data: taken } = await admin.from('spm_users').select('id').eq('username', username).maybeSingle();
      if (taken) return json({ error: 'That user ID is taken' }, 409);
      const { data: made, error: mkErr } = await admin.auth.admin.createUser({
        email: `${username}@${STAFF_DOMAIN}`, password, email_confirm: true, user_metadata: { app: 'spm' },
      });
      if (mkErr || !made?.user) return json({ error: mkErr?.message?.includes('registered') ? 'That user ID is taken' : 'Could not create the login' }, 409);
      const { error: linkErr } = await admin.from('spm_users').update({ auth_id: made.user.id, username }).eq('id', userId);
      if (linkErr) { await admin.auth.admin.deleteUser(made.user.id); return json({ error: 'Could not link the login' }, 500); }
      return json({ ok: true });
    }
    if (body.action === 'set_password') {
      if (!target.auth_id) return json({ error: 'This person has no login yet' }, 409);
      const { error } = await admin.auth.admin.updateUserById(target.auth_id, { password });
      if (error) return json({ error: 'Could not change the password' }, 500);
      return json({ ok: true });
    }
    return json({ error: 'Unknown action' }, 400);
  } catch (_e) {
    return json({ error: 'Server error' }, 500);
  }
});
