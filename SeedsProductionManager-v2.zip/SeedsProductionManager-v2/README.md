# The Seeds Production Manager — version 2

A phone-first web app for seed-production work: farmers, fields, crop events, approvals, team tracking, money, harvest, agreements and a farmer app — with every feature switchable per role.

## What is in this folder

| Folder | What it is |
|---|---|
| `app/` | The app. Upload this folder to Netlify (production.cropline.in). No build step. |
| `sql/` | Database changes. **Already applied** to the Supabase project — kept here as a record. |
| `supabase/spm-admin/` | Server function for creating logins (staff and farmers), resetting passwords/PINs, force sign-out. **Already deployed.** |
| `FEATURES.md` | Status of all 236 features (207 done, 27 partial, 2 not built). |

## Roles (top to bottom)

Admin → Owner → Observer → Organizer → Sub-organizer → Field assistant → Company assistant → Farmer.
Each role sees the work of roles below it, never above. Sub-organizer, Field assistant, Company assistant and Farmer are tracked.
Feature switches: More → Access control (Admin: all roles, Owner: roles below Owner).

## How to put it live

1. Netlify is blocking new deploys until credits are added (Billing in app.netlify.com). After that:
2. Netlify → project **production-cropline** → Deploys → drag the **app** folder onto the page.
3. Open production.cropline.in on a phone and sign in. Use the browser menu → *Add to Home screen* to install it.
4. To go back to the old version: Netlify → Deploys → pick the earlier deploy → *Publish deploy*.

## Before real farmers' data goes in

- Settings → *Demo login on the sign-in screen* → **Off**.
- Delete the sample data (farmers tagged `DEMO`, the `test.*` users) — ask Claude, it needs your confirmation.
- Settings: companies (code is used in agreement numbers), seasons, varieties + crop events, rates, rules, print setup, agreement template.
- Team: add people, set who reports to whom, create logins.
- Farmers: Farmer page → *Create farmer login* gives the farmer a mobile + PIN login.

## Test logins (sample data only)

`test.supervisor`, `test.org1`, `test.org2`, `test.sub1`, `test.staff1`, `test.staff2`, `test.staff3`, `test.viewer` — password `demo`.
Your own login `aman.owner` is the Admin and keeps its own password.

## Limits to know

- Location tracking runs only while the app is open on the phone (web apps are stopped in the background). A native Android app would be needed for all-day background tracking.
- Farmer login uses a PIN, not an SMS OTP (OTP needs a paid SMS provider).
- Reminders show when the app is opened; there is no push notification when the app is closed.
- Some limits (phone lock, locked seasons, feature limits by company/season/person) are enforced by the app, not by the database.
- Tested in a phone-size browser on sample data. Test on two or three real phones in the field before rolling out.
