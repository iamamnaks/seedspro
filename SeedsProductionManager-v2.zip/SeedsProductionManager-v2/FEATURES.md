# Feature status — The Seeds Production Manager v2

Done = built and tested on sample data in a phone-size browser. Partial = works with the limit noted. Not built = not in this version.
Some features are always on for anyone who can open that screen (for example search, sowing date, check-out).

| # | Area | Feature | Status | Note |
|---|---|---|---|---|
| 1 | Company setup & control | Company profile: logo, GST, address, signatory, stamp and signature | Done |  |
| 2 | Company setup & control | Agreement number series per company and season | Done |  |
| 3 | Company setup & control | Agreement template editor with merge fields | Done |  |
| 4 | Company setup & control | Print page setup: paper, margins, stamp area, font, footer | Done |  |
| 5 | Company setup & control | Bilingual agreement print (English + Telugu / Bengali / Hindi) | Done |  |
| 6 | Company setup & control | Seasons: open, close, lock past season from edits | Done |  |
| 7 | Company setup & control | Variety master: events, days, isolation distance, expected yield per acre | Done |  |
| 8 | Company setup & control | Procurement rate per variety per season | Done |  |
| 9 | Company setup & control | Advance limit per acre per variety | Done |  |
| 10 | Company setup & control | Money features switch (on / owner only / off) | Done |  |
| 11 | Company setup & control | Products & stock master (seed, fertilizer, pesticide) with rates | Done |  |
| 12 | Company setup & control | Delivery / collection locations list | Done |  |
| 13 | Company setup & control | Holiday and Sunday rules for due dates | Done |  |
| 14 | Company setup & control | GPS accuracy required (5 / 10 / 20 m) | Done |  |
| 15 | Company setup & control | Visit radius for a valid field visit | Done |  |
| 16 | Company setup & control | Minutes per acre for visit time check | Done |  |
| 17 | Company setup & control | Overdue rule: days before warning and red | Done |  |
| 18 | Company setup & control | Approval rules: who approves farmers, fields, events, payments | Partial | Approvals follow the team tree (fixed rule); rules are not editable |
| 19 | Company setup & control | Auto-approve entries from trusted staff | Not built | Not built — needs a server change so trusted staff entries skip approval |
| 20 | Company setup & control | Login roles and custom permission sets | Done |  |
| 21 | Company setup & control | Reset password, switch login off, force sign-out | Done |  |
| 22 | Company setup & control | Login history: who signed in, when, which phone | Done |  |
| 23 | Company setup & control | One-device-per-user lock | Partial | Phone lock is checked by the app, not by the server |
| 24 | Company setup & control | Change log with old and new values | Done |  |
| 25 | Company setup & control | Removed-records bin with restore | Done |  |
| 26 | Company setup & control | Daily automatic backup + restore | Partial | Backup download works; restore from file is not built (ask before restoring live data) |
| 27 | Company setup & control | Excel / PDF export with column picker and filters | Done |  |
| 28 | Company setup & control | Bulk import farmers and fields from Excel | Done |  |
| 29 | Company setup & control | Duplicate farmer check (mobile, name + village) | Done |  |
| 30 | Company setup & control | Season dashboard: farmers, acres, sown, events due, overdue | Done |  |
| 31 | Company setup & control | Organizer league table: acres, overdue %, visits done | Done |  |
| 32 | Company setup & control | Map of all fields coloured by stage or overdue | Done |  |
| 33 | Company setup & control | Isolation conflict report (fields closer than set distance) | Done |  |
| 34 | Company setup & control | Expected production by variety and village | Done |  |
| 35 | Company setup & control | Advance outstanding by organizer and farmer | Done |  |
| 36 | Company setup & control | Farmer ledger: advance, inputs, deductions, payment, balance | Done |  |
| 37 | Company setup & control | Payment batch approval and bank file export | Partial | Generic CSV (name, account, IFSC, amount); check your bank's upload format |
| 38 | Company setup & control | Harvest weighment and moisture entry | Done |  |
| 39 | Company setup & control | Lot / batch number from field to packet | Done |  |
| 40 | Company setup & control | Quality test results per lot (germination, purity) | Done |  |
| 41 | Company setup & control | Rejection and deduction rules | Done |  |
| 42 | Company setup & control | Final settlement sheet per farmer | Done |  |
| 43 | Company setup & control | WhatsApp / SMS templates for farmer messages | Done |  |
| 44 | Company setup & control | Notification rules (who gets alerts for what) | Partial | Daily reminder of due events while the app is opened; no per-person rules |
| 45 | Company setup & control | App language per user | Partial | Menus and main buttons in Telugu, Bengali, Hindi; screens and data stay English |
| 46 | Company setup & control | Theme colour, Auto dark mode, text size default | Done |  |
| 47 | Company setup & control | Demo login on/off switch | Done |  |
| 48 | Company setup & control | Data lock after season close | Partial | Locked season blocks edits in the app (owner can still edit) |
| 49 | Company setup & control | Multi-company switcher at the top | Done |  |
| 50 | Company setup & control | Usage report: which staff use the app daily | Done |  |
| 51 | Team monitoring | Team dashboard across assigned organizers | Done |  |
| 52 | Team monitoring | Approve / return / reject farmers and fields | Done |  |
| 53 | Team monitoring | Approve event marks with photo check | Not built | Not built — event marks are recorded with photo but have no separate approval step |
| 54 | Team monitoring | Overdue events by organizer, oldest first | Done |  |
| 55 | Team monitoring | Fields not visited in 15 / 30 days | Done |  |
| 56 | Team monitoring | Fields without location list | Done |  |
| 57 | Team monitoring | Map of team fields with today's due events | Done |  |
| 58 | Team monitoring | Staff live-day view: visits done today with time and place | Done |  |
| 59 | Team monitoring | Visit route of a staff member for a day | Done |  |
| 60 | Team monitoring | Fake-visit check: visit outside field radius | Done |  |
| 61 | Team monitoring | Short-visit check: time on field below minimum | Done |  |
| 62 | Team monitoring | Reassign farmers between organizers | Done |  |
| 63 | Team monitoring | Bulk mark events done for a village | Done |  |
| 64 | Team monitoring | Comment on any field or event | Done |  |
| 65 | Team monitoring | Weekly team report (PDF / WhatsApp) | Done |  |
| 66 | Team monitoring | Variety-wise acres and stage summary | Done |  |
| 67 | Team monitoring | Isolation conflicts in team area | Done |  |
| 68 | Team monitoring | Advance requests waiting for approval | Done |  |
| 69 | Team monitoring | Input issue approval | Done |  |
| 70 | Team monitoring | Harvest schedule for next 15 days | Done |  |
| 71 | Team monitoring | Truck / pickup plan for harvest | Done |  |
| 72 | Team monitoring | Staff attendance (first check-in, last check-out) | Done |  |
| 73 | Team monitoring | Staff target vs achieved acres | Done |  |
| 74 | Team monitoring | Escalation: overdue > N days goes to owner | Done |  |
| 75 | Team monitoring | Search any farmer by ID, name, mobile, village | Done |  |
| 76 | Team monitoring | Download team data to Excel | Done |  |
| 77 | Team monitoring | Field photo gallery by stage | Done |  |
| 78 | Team monitoring | Disease / pest report list from field staff | Done |  |
| 79 | Team monitoring | Notes and tasks assigned to organizers | Done |  |
| 80 | Team monitoring | Monthly visit count per staff | Done |  |
| 81 | Farmer & field management | My dashboard: farmers, acres, due today, overdue | Done |  |
| 82 | Farmer & field management | Add farmer with photo, ID proof photo, bank details | Done |  |
| 83 | Farmer & field management | Add fields with GPS, survey no, irrigation | Done |  |
| 84 | Farmer & field management | Foundation seed issue date and quantity | Done |  |
| 85 | Farmer & field management | Sowing date entry with photo | Done |  |
| 86 | Farmer & field management | Agreement create, print, share PDF on WhatsApp | Done |  |
| 87 | Farmer & field management | Farmer signature on phone screen | Done |  |
| 88 | Farmer & field management | Advance request for a farmer | Done |  |
| 89 | Farmer & field management | Input issue to farmer (from stock) | Done |  |
| 90 | Farmer & field management | Event calendar for my fields | Done |  |
| 91 | Farmer & field management | Today's route: due fields in nearest-first order | Done |  |
| 92 | Farmer & field management | Field visit log with stage and condition | Done |  |
| 93 | Farmer & field management | Approve entries from roles below | Done |  |
| 94 | Farmer & field management | Sent-back items to fix | Done |  |
| 95 | Farmer & field management | Village-wise farmer list | Done |  |
| 96 | Farmer & field management | Call or WhatsApp farmer from the app | Done |  |
| 97 | Farmer & field management | Bulk SMS reminder for an event to a village | Partial | One-tap WhatsApp reminder per farmer from the crop event; no bulk SMS gateway |
| 98 | Farmer & field management | Expected yield per field | Done |  |
| 99 | Farmer & field management | Harvest entry: date, weight, moisture | Done |  |
| 100 | Farmer & field management | Farmer balance view | Done |  |
| 101 | Farmer & field management | My staff: visits today and overdue per staff | Done |  |
| 102 | Farmer & field management | Assign fields to field staff | Done |  |
| 103 | Farmer & field management | Offline work with auto-sync | Done |  |
| 104 | Farmer & field management | Excel download of my farmers | Done |  |
| 105 | Farmer & field management | Isolation warning when adding a field | Done |  |
| 106 | Farmer & field management | Field status: failed, abandoned, ploughed out with reason | Done |  |
| 107 | Farmer & field management | Rogueing / detasseling labour count entry | Done |  |
| 108 | Farmer & field management | Disease or pest report with photo | Done |  |
| 109 | Farmer & field management | My monthly report PDF | Done |  |
| 110 | Farmer & field management | Reminder notifications for due events | Partial | Reminder while the app is open; no push when the app is closed |
| 111 | Day-to-day field entry | My farmers and fields only | Done |  |
| 112 | Day-to-day field entry | Add farmer and field (goes for approval) | Done |  |
| 113 | Day-to-day field entry | Mark events done with photo | Done |  |
| 114 | Day-to-day field entry | Field visit log | Done |  |
| 115 | Day-to-day field entry | Today's due list | Done |  |
| 116 | Day-to-day field entry | Overdue list | Done |  |
| 117 | Day-to-day field entry | Add / correct field location | Done |  |
| 118 | Day-to-day field entry | Sowing date entry | Done |  |
| 119 | Day-to-day field entry | Input issue entry (for approval) | Done |  |
| 120 | Day-to-day field entry | Call / WhatsApp farmer | Done |  |
| 121 | Day-to-day field entry | My downline's visits today | Done |  |
| 122 | Day-to-day field entry | Sent-back items to fix (entry) | Done |  |
| 123 | Day-to-day field entry | Village filter | Done |  |
| 124 | Day-to-day field entry | Offline mode | Done |  |
| 125 | Day-to-day field entry | Event reminders | Partial | Same as 110 |
| 126 | Day-to-day field entry | Disease / pest report | Done |  |
| 127 | Day-to-day field entry | Harvest entry | Done |  |
| 128 | Day-to-day field entry | My acres and stage summary | Done |  |
| 129 | Day-to-day field entry | Farmer list download | Done |  |
| 130 | Day-to-day field entry | Change my password | Done |  |
| 131 | Field tracking | One-tap check-in at start of day with GPS | Done |  |
| 132 | Field tracking | Check-out at end of day | Done |  |
| 133 | Field tracking | Today's work list in route order | Done |  |
| 134 | Field tracking | Navigate to field (Google Maps) | Done |  |
| 135 | Field tracking | Visit start / end with GPS and time | Done |  |
| 136 | Field tracking | Visit must be inside field radius | Done |  |
| 137 | Field tracking | Mark event done with photo (time and GPS stamped) | Done |  |
| 138 | Field tracking | Skip event with reason | Done |  |
| 139 | Field tracking | Crop stage and condition on each visit | Done |  |
| 140 | Field tracking | Plant count / stand count entry | Done |  |
| 141 | Field tracking | Detasseling progress % per field | Done |  |
| 142 | Field tracking | Rogueing done entry | Done |  |
| 143 | Field tracking | Off-type / pollen-shedder count | Done |  |
| 144 | Field tracking | Disease / pest report with photo (field) | Done |  |
| 145 | Field tracking | Irrigation status | Done |  |
| 146 | Field tracking | Add field location (10 m averaged GPS) | Done |  |
| 147 | Field tracking | Walk boundary to measure area | Done |  |
| 148 | Field tracking | Farmer complaint entry | Done |  |
| 149 | Field tracking | Labour count entry | Done |  |
| 150 | Field tracking | Offline work, sync later | Done |  |
| 151 | Field tracking | Big buttons, voice note option | Partial | Voice typing works where the phone supports it |
| 152 | Field tracking | Local language screens | Partial | Same as 45 |
| 153 | Field tracking | My visits today / this week | Done |  |
| 154 | Field tracking | Sent-back items to fix (field) | Done |  |
| 155 | Field tracking | Overdue fields warning | Done |  |
| 156 | Field tracking | Daily km travelled | Done |  |
| 157 | Field tracking | Expense entry (fuel, food) with bill photo | Done |  |
| 158 | Field tracking | Leave request | Done |  |
| 159 | Field tracking | Farmer call log | Done |  |
| 160 | Field tracking | Harvest readiness check (moisture, grain) | Done |  |
| 161 | Field tracking | Isolation check: nearby maize field report | Done |  |
| 162 | Field tracking | Weather alert for my area | Partial | Open-Meteo forecast near your fields (needs internet) |
| 163 | Field tracking | Low-battery / low-GPS warning | Done |  |
| 164 | Field tracking | Change my password (field) | Done |  |
| 165 | Field tracking | Help video per screen | Done |  |
| 166 | Display & reports | Read-only dashboard | Done |  |
| 167 | Display & reports | TV mode: auto-rotating screens for office | Done |  |
| 168 | Display & reports | Season totals by company and variety | Done |  |
| 169 | Display & reports | Organizer league table (view) | Done |  |
| 170 | Display & reports | Map of fields by stage | Done |  |
| 171 | Display & reports | Overdue counts by organizer | Done |  |
| 172 | Display & reports | Harvest progress | Done |  |
| 173 | Display & reports | Download reports (if allowed) | Done |  |
| 174 | Display & reports | No farmer mobile numbers shown | Done |  |
| 175 | Display & reports | Auto-refresh every 5 minutes | Done |  |
| 176 | Farmer self-service | Login with mobile + OTP | Partial | Mobile number + PIN (6–8 digits) set by the owner; OTP needs an SMS provider |
| 177 | Farmer self-service | My fields and variety | Done |  |
| 178 | Farmer self-service | My agreement PDF | Done |  |
| 179 | Farmer self-service | Upcoming work on my fields with dates | Done |  |
| 180 | Farmer self-service | Detasseling and rogueing reminders | Partial | Same as 110 |
| 181 | Farmer self-service | Inputs received | Done |  |
| 182 | Farmer self-service | Advance received | Done |  |
| 183 | Farmer self-service | Harvest weight and moisture | Done |  |
| 184 | Farmer self-service | Deductions and reasons | Done |  |
| 185 | Farmer self-service | Final payment and balance | Done |  |
| 186 | Farmer self-service | Payment status (pending / paid) | Done |  |
| 187 | Farmer self-service | Call my organizer | Done |  |
| 188 | Farmer self-service | Raise complaint with photo | Done |  |
| 189 | Farmer self-service | Request inputs or advance | Done |  |
| 190 | Farmer self-service | Crop advice per stage | Done |  |
| 191 | Farmer self-service | Weather for my village | Partial | Same as 162 |
| 192 | Farmer self-service | Notices from company | Done |  |
| 193 | Farmer self-service | Language choice | Partial | Same as 45 |
| 194 | Farmer self-service | Voice instructions | Partial | Uses the phone's voice; quality depends on the phone |
| 195 | Farmer self-service | Refer another farmer | Done |  |
| 196 | Farmer self-service | Next season booking interest | Done |  |
| 197 | Farmer self-service | Past seasons history | Done |  |
| 198 | Farmer self-service | Bank details view (masked) | Done |  |
| 199 | Farmer self-service | Download my statement PDF | Done |  |
| 200 | Farmer self-service | Rate my organizer | Done |  |
| 201 | NEW: Tracking & hierarchy | Live location during work hours (Sub-organizer, Field assistant, Company assistant) | Partial | Records location only while the app is open and the person is checked in, in work hours; phones stop web apps in the background |
| 202 | NEW: Tracking & hierarchy | Day timeline per person: check-in, visits, check-out | Done |  |
| 203 | NEW: Tracking & hierarchy | Route replay on map for any day | Done |  |
| 204 | NEW: Tracking & hierarchy | Time spent on each field | Done |  |
| 205 | NEW: Tracking & hierarchy | Photo with GPS + time watermark | Done |  |
| 206 | NEW: Tracking & hierarchy | Idle alert: no movement or entry for 2 hours in work time | Done |  |
| 207 | NEW: Tracking & hierarchy | Fake GPS / mock location detection | Partial | Detects impossible jumps and identical readings; cannot detect every fake-GPS app |
| 208 | NEW: Tracking & hierarchy | Missed planned visits list | Partial | Shown as overdue events and fields not visited; there is no separate visit plan |
| 209 | NEW: Tracking & hierarchy | Farmer app activity: last opened, notices read | Done |  |
| 210 | NEW: Tracking & hierarchy | Farmer complaint tracking with status | Done |  |
| 211 | NEW: Tracking & hierarchy | Company assistant task list and completion | Done |  |
| 212 | NEW: Tracking & hierarchy | Company assistant input / stock handover tracking | Done |  |
| 213 | NEW: Tracking & hierarchy | Downline-only view: each person sees only people below them | Done |  |
| 214 | NEW: Tracking & hierarchy | Upline hidden: lower roles cannot see names, phones or work of upper roles | Done |  |
| 215 | NEW: Tracking & hierarchy | Drill-down: tap a person → their team → their farmers | Done |  |
| 216 | NEW: Tracking & hierarchy | Daily summary pushed to each upper level | Partial | Summary ready to send on WhatsApp in one tap; not pushed automatically |
| 217 | NEW: Tracking & hierarchy | Exception report: overdue, no visit, fake GPS | Done |  |
| 218 | NEW: Tracking & hierarchy | Attendance calendar per person | Done |  |
| 219 | NEW: Tracking & hierarchy | Work-hours setting: tracking only inside work hours | Done |  |
| 220 | NEW: Tracking & hierarchy | Tracking consent screen at first login | Done |  |
| 221 | NEW: Tracking & hierarchy | Battery-saver tracking mode | Partial | Records less often when battery is under 20% |
| 222 | NEW: Tracking & hierarchy | Offline tracking stored and synced later | Done |  |
| 223 | NEW: Tracking & hierarchy | Performance score per person | Done |  |
| 224 | NEW: Tracking & hierarchy | Heatmap of visits by village | Done |  |
| 225 | NEW: Tracking & hierarchy | Audit log of permission changes (who enabled what, when) | Done |  |
| 226 | NEW: Tracking & hierarchy | Feature on/off per company | Partial | Set by feature number; applied by the app at sign-in |
| 227 | NEW: Tracking & hierarchy | Feature on/off per season | Partial | Same as 226 |
| 228 | NEW: Tracking & hierarchy | Temporary access with expiry date | Partial | Same as 226 (+feature until a date) |
| 229 | NEW: Tracking & hierarchy | Copy permissions from one role to another | Done |  |
| 230 | NEW: Tracking & hierarchy | Per-person override (within the role's limit) | Partial | Same as 226 |
| 231 | NEW: Tracking & hierarchy | Approval chain follows the hierarchy automatically | Done |  |
| 232 | NEW: Tracking & hierarchy | Escalate up the chain if not approved in N days | Done |  |
| 233 | NEW: Tracking & hierarchy | Reassign downline when a person leaves | Done |  |
| 234 | NEW: Tracking & hierarchy | Handover report on staff exit | Done |  |
| 235 | NEW: Tracking & hierarchy | Export limited to own downline | Done |  |
| 236 | NEW: Tracking & hierarchy | Masked farmer mobile for lower roles | Done |  |