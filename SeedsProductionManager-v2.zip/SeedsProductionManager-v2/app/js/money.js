/* Money: ledger, advances, inputs, stock, harvest, settlement, payments, agreements */
'use strict';
function moneyOn() { const m = setting('money', 'off'); return can(10) || can(36) || can(100) || can(182) ? (m === 'on' || (m === 'owner' && isOwner()) || (m !== 'off' && S.farmer)) : false; }
const ledSign = k => ({advance: -1, input: -1, deduction: -1, payment: -1, harvest: 1}[k] || 0);
function balance(led) { return sum(led.filter(l => l.status !== 'rejected' && l.status !== 'requested'), l => ledSign(l.kind) * l.amount); }
function ledgerSummary(led) {
  const by = k => sum(led.filter(l => l.kind === k && ['approved', 'paid'].includes(l.status)), l => l.amount);
  return `<div class="tiles"><div class="tile"><b>${rs(by('advance'))}</b><span>Advance</span></div><div class="tile"><b>${rs(by('input'))}</b><span>Inputs</span></div><div class="tile"><b>${rs(by('harvest'))}</b><span>Harvest value</span></div><div class="tile ${balance(led) < 0 ? 'bad' : 'ok'}"><b>${rs(balance(led))}</b><span>Balance (+ we owe farmer)</span></div></div>${led.some(l => l.status === 'requested') ? `<p class="sm"><span class="tag warn">${led.filter(l => l.status === 'requested').length} waiting for approval</span></p>` : ''}`;
}
function ledgerForm(fid, kind) {
  const f = byId('farmers', fid), acres = sum(fieldsOf(fid), x => x.acres), lim = setting('advance_per_acre', 0) * acres;
  const used = sum((S.D.ledger || []).filter(l => l.farmer_id === fid && l.kind === 'advance' && l.status !== 'rejected'), l => l.amount);
  const prods = (S.D.products || []).filter(p => p.active);
  sheet(`<h3>${{advance: 'Advance request', input: 'Issue inputs', deduction: 'Deduction', payment: 'Payment', harvest: 'Harvest credit'}[kind]} · ${esc(f.name)}</h3>
  ${kind === 'advance' && lim ? `<p class="sm mut">Limit ${rs(lim)} (${rs(setting('advance_per_acre', 0))}/acre × ${num(acres)} ac) · already ${rs(used)}</p>` : ''}
  ${kind === 'input' ? `<label class="f">Product</label><select class="in" id="lg_p">${prods.map(p => `<option value="${p.id}" data-rate="${p.rate}">${esc(p.name)} · ${rs(p.rate)}/${esc(p.unit)} · stock ${num(stockOf(p.id))}</option>`).join('')}</select><label class="f">Quantity</label><input class="in" id="lg_q" inputmode="decimal">` : ''}
  <label class="f">Amount ₹</label><input class="in" id="lg_a" inputmode="decimal"><label class="f">Date</label><input class="in" type="date" id="lg_d" value="${today()}"><label class="f">Note</label><input class="in" id="lg_n">
  <div class="btns" style="margin-top:12px"><button class="btn pri" id="lg_s">${isOwner() ? 'Save (approved)' : 'Send for approval'}</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, p => {
    const q = p.querySelector('#lg_q'), ps = p.querySelector('#lg_p'); const upd = () => { if (q && ps) { const r = +ps.selectedOptions[0].dataset.rate; p.querySelector('#lg_a').value = Math.round((parseFloat(q.value) || 0) * r); } }; if (q) { q.oninput = upd; ps.onchange = upd; }
    p.querySelector('#lg_s').onclick = async () => { const a = parseFloat(p.querySelector('#lg_a').value); if (!(a > 0)) return toast('Enter the amount');
      if (kind === 'advance' && lim && used + a > lim && !(await ask('Over the advance limit', `This makes ${rs(used + a)}, above the limit of ${rs(lim)}. Send anyway?`, 'Send anyway'))) return;
      const row = {farmer_id: fid, season_id: (currentSeason() || {}).id, kind, amount: a, day: p.querySelector('#lg_d').value, note: p.querySelector('#lg_n').value, status: 'requested'};
      if (q) { row.qty = parseFloat(q.value) || null; row.product_id = ps.value || null; }
      try { let r = await save('spm_ledger', row); if (isOwner() && r.id) { await rpc('spm_money_decide', {p_id: r.id, p_status: 'approved', p_note: ''}); r.status = 'approved'; } (S.D.ledger = S.D.ledger || []).unshift(r); closeSheet(); toast(r.status === 'approved' ? 'Saved' : 'Sent for approval'); render(); } catch (e) { toast(e.message); } };
  });
}
async function moneyDecide(id, st) { try { await rpc('spm_money_decide', {p_id: id, p_status: st, p_note: ''}); const l = (S.D.ledger || []).find(x => x.id === id); if (l) l.status = st; toast(st); await loadExtra(['ledger', 'stock']); render(); } catch (e) { toast(e.message); } }
const stockOf = pid => sum((S.D.stock || []).filter(m => m.product_id === pid), m => m.kind === 'out' ? -m.qty : m.qty);
function vLedger(fid) {
  const f = byId('farmers', fid), led = (S.D.ledger || []).filter(l => l.farmer_id === fid).sort((a, b) => a.day.localeCompare(b.day)); let bal = 0;
  return hdr('Ledger · ' + f.name, f.code) + `<div class="wrap"><div class="card">${ledgerSummary(led)}<div class="btns">${isOwner() ? ['advance', 'input', 'deduction', 'payment', 'harvest'].map(k => `<button class="btn sm" onclick="ledgerForm('${fid}','${k}')">＋ ${k}</button>`).join('') : ''}${can(42) ? `<button class="btn sm" onclick="settlement('${fid}')">Settlement sheet</button>` : ''}</div></div>
  <div class="card tw"><table class="t"><tr><th>Date</th><th>Entry</th><th class="r">Amount</th><th class="r">Balance</th><th>Status</th></tr>${led.map(l => { if (!['requested', 'rejected'].includes(l.status)) bal += ledSign(l.kind) * l.amount; return `<tr><td>${dmy(l.day)}</td><td>${esc(l.kind)}${l.qty ? ` · ${num(l.qty)} ${esc((byId('products', l.product_id) || {}).name || '')}` : ''}<br><span class="sm mut">${esc(l.note)}</span></td><td class="r">${ledSign(l.kind) < 0 ? '−' : '+'}${rs(l.amount)}</td><td class="r">${rs(bal)}</td><td><span class="tag ${l.status === 'rejected' ? 'bad' : l.status === 'requested' ? 'warn' : 'ok'}">${l.status}</span>${isOwner() && l.status === 'approved' && l.kind === 'payment' ? `<br><button class="btn sm" onclick="moneyDecide('${l.id}','paid')">Mark paid</button>` : ''}</td></tr>`; }).join('')}</table></div></div>`;
}

/* ---------- products & stock (11) ---------- */
function vProducts() {
  return hdr('Products & stock') + `<div class="wrap"><div class="btns" style="margin-bottom:12px">${isOwner() ? `<button class="btn pri" onclick="productForm()">＋ Product</button>` : ''}</div>
  <div class="card">${(S.D.products || []).map(p => `<div class="it" onclick="${isOwner() ? `productForm('${p.id}')` : ''}"><div class="main"><b>${esc(p.name)}</b><span>${esc(p.kind)} · ${rs(p.rate)}/${esc(p.unit)}${p.active ? '' : ' · not in use'}</span></div><div class="side"><b>${num(stockOf(p.id))}</b> ${esc(p.unit)}<br>${isOwner() ? `<button class="btn sm" onclick="event.stopPropagation();stockIn('${p.id}')">＋ Stock</button>` : ''}</div></div>`).join('') || '<p class="mut">No products yet.</p>'}</div>
  ${can(212) ? `<div class="card"><h2>Inputs issued (last 30)</h2>${(S.D.stock || []).filter(m => m.kind === 'out').slice(0, 30).map(m => `<div class="sm">${dt(m.at)} · ${esc((byId('products', m.product_id) || {}).name)} · ${num(m.qty)} · ${esc((byId('farmers', m.farmer_id) || {}).name || '')} · by ${esc(userName(m.by_user))}</div>`).join('') || '<p class="mut sm">None.</p>'}</div>` : ''}</div>`;
}
function productForm(id) {
  const p = id ? byId('products', id) : {kind: 'fertilizer', unit: 'kg', active: true};
  sheet(`<h3>${id ? 'Edit product' : 'New product'}</h3><label class="f">Name</label><input class="in" id="pr_n" value="${esc(p.name)}"><div class="row"><div><label class="f">Type</label><select class="in" id="pr_k">${['seed', 'fertilizer', 'pesticide', 'other'].map(k => `<option ${p.kind === k ? 'selected' : ''}>${k}</option>`).join('')}</select></div><div><label class="f">Unit</label><input class="in" id="pr_u" value="${esc(p.unit)}"></div></div>
  <label class="f">Rate ₹ per unit</label><input class="in" id="pr_r" inputmode="decimal" value="${esc(p.rate)}"><label class="sm" style="display:flex;gap:8px;margin-top:10px"><input type="checkbox" id="pr_a" ${p.active ? 'checked' : ''}> In use</label>
  <div class="btns" style="margin-top:12px"><button class="btn pri" id="pr_s">Save</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, x => x.querySelector('#pr_s').onclick = async () => {
    const row = {name: x.querySelector('#pr_n').value.trim(), kind: x.querySelector('#pr_k').value, unit: x.querySelector('#pr_u').value.trim(), rate: parseFloat(x.querySelector('#pr_r').value) || 0, active: x.querySelector('#pr_a').checked}; if (!row.name) return toast('Enter the name');
    try { const r = await save('spm_products', row, id ? {id} : {}); if (id) Object.assign(p, r); else (S.D.products = S.D.products || []).push(r); closeSheet(); render(); } catch (e) { toast(e.message); } });
}
async function stockIn(pid) { const q = await askText('Add stock', 'Quantity received', '', {mode: 'decimal', required: true}); if (!q) return; try { const r = await save('spm_stock_moves', {product_id: pid, qty: parseFloat(q), kind: 'in', note: 'Received'}); (S.D.stock = S.D.stock || []).unshift(r); render(); } catch (e) { toast(e.message); } }

/* ---------- harvest (38, 39, 40, 99, 127) ---------- */
function harvestForm(fieldId) {
  const x = byId('fields', fieldId); const lot = `${(varietyName(x.variety_id) || 'LOT').replace(/\W/g, '')}-${today().replace(/-/g, '').slice(2)}-${(farmerOf(x) || {}).code || ''}`;
  sheet(`<h3>Harvest entry</h3><div class="row"><div><label class="f">Date</label><input class="in" type="date" id="hv_d" value="${today()}" max="${today()}"></div><div><label class="f">Weight (kg)</label><input class="in" id="hv_w" inputmode="decimal"></div></div>
  <div class="row"><div><label class="f">Moisture %</label><input class="in" id="hv_m" inputmode="decimal"></div><div>${can(39) ? `<label class="f">Lot / batch no.</label><input class="in" id="hv_l" value="${esc(lot)}">` : ''}</div></div>
  ${can(40) ? `<div class="row"><div><label class="f">Germination %</label><input class="in" id="hv_g" inputmode="decimal"></div><div><label class="f">Purity %</label><input class="in" id="hv_p" inputmode="decimal"></div></div>` : ''}
  <label class="f">Note</label><input class="in" id="hv_n"><div class="btns" style="margin-top:12px"><button class="btn pri" id="hv_s">Save</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, p => p.querySelector('#hv_s').onclick = async () => {
    const g = k => (p.querySelector('#hv_' + k) || {}).value; const n = k => { const v = parseFloat(g(k)); return isNaN(v) ? null : v; }; if (!(n('w') > 0)) return toast('Enter the weight');
    const rate = (setting('rates', {})[x.variety_id] || {})[x.season_id] || null;
    try { const r = await save('spm_harvests', {field_id: fieldId, farmer_id: x.farmer_id, day: g('d'), weight_kg: n('w'), moisture: n('m'), lot_no: g('l') || '', germination: n('g'), purity: n('p'), rate, note: g('n') || ''}); (S.D.harvests = S.D.harvests || []).push(r); closeSheet(); toast('Harvest saved'); render(); } catch (e) { toast(e.message); } });
}
function vHarvest() {
  const FL = (S.D.fields || []).filter(f => !f.deleted_at && f.status === 'active'); const soon = FL.map(f => ({f, d: harvestDue(f)})).filter(x => x.d && x.d <= addDays(today(), 15)).sort((a, b) => a.d.localeCompare(b.d));
  const hv = S.D.harvests || [];
  return hdr('Harvest', `${num(sum(hv, h => h.weight_kg) / 1000, 2)} t received`) + `<div class="wrap">
  <div class="card"><h2>Harvest due in the next 15 days (${soon.length})${can(71) ? '<span class="sp"></span><button class="btn sm" onclick="truckPlan()">Pickup plan</button>' : ''}</h2>${soon.map(({f, d}) => { const fa = farmerOf(f) || {}; return `<div class="it" onclick="go('field/${f.id}')"><div class="main"><b>${esc(fa.name)} · ${num(f.acres)} ac</b><span>${esc(fa.village)} · ${esc(varietyName(f.variety_id))}</span></div><div class="side">${dmy(d)}</div></div>`; }).join('') || '<p class="mut">None.</p>'}</div>
  <div class="card"><h2>Received</h2><div class="tw"><table class="t"><tr><th>Date</th><th>Farmer</th><th class="r">kg</th><th class="r">Moist %</th><th>Lot</th>${can(40) ? '<th class="r">Germ %</th><th class="r">Purity %</th>' : ''}</tr>${hv.slice().sort((a, b) => b.day.localeCompare(a.day)).slice(0, 100).map(h => `<tr><td>${dmy(h.day)}</td><td>${esc((byId('farmers', h.farmer_id) || {}).name)}</td><td class="r">${num(h.weight_kg, 0)}</td><td class="r">${num(h.moisture)}</td><td>${esc(h.lot_no)}</td>${can(40) ? `<td class="r">${num(h.germination)}</td><td class="r">${num(h.purity)}</td>` : ''}</tr>`).join('')}</table></div></div></div>`;
}
function truckPlan() {
  const FL = (S.D.fields || []).filter(f => !f.deleted_at); const rows = FL.map(f => ({f, d: harvestDue(f)})).filter(x => x.d && x.d <= addDays(today(), 15)).map(({f, d}) => { const fa = farmerOf(f) || {}; return {Date: dmy(d), Village: fa.village, Farmer: fa.name, Mobile: fa.mobile, Acres: f.acres, 'Expected kg': f.expected_kg_per_acre ? Math.round(f.expected_kg_per_acre * f.acres) : '', Location: f.lat ? mapsLink(f.lat, f.lng) : ''}; });
  rows.sort((a, b) => (a.Date + a.Village).localeCompare(b.Date + b.Village)); exportXlsx('pickup-plan', {Pickup: rows});
}

/* ---------- settlement (41, 42) & payments (37) ---------- */
function settleCalc(fid) {
  const hv = (S.D.harvests || []).filter(h => h.farmer_id === fid), led = (S.D.ledger || []).filter(l => l.farmer_id === fid && ['approved', 'paid'].includes(l.status));
  const rules = setting('deduction_rules', {moisture_base: 12, pct_per_moisture: 1, reject_germination: 0});
  const lines = hv.map(h => { const fl = byId('fields', h.field_id) || {}; const rate = h.rate || (setting('rates', {})[fl.variety_id] || {})[fl.season_id] || 0;
    const extra = Math.max(0, (h.moisture || 0) - rules.moisture_base); const ded = Math.round(h.weight_kg * extra * rules.pct_per_moisture / 100); const rej = rules.reject_germination && h.germination != null && h.germination < rules.reject_germination;
    const net = rej ? 0 : h.weight_kg - ded; return {h, rate, ded, rej, net, value: Math.round(net * rate)}; });
  const value = sum(lines, l => l.value), adv = sum(led.filter(l => l.kind === 'advance'), l => l.amount), inp = sum(led.filter(l => l.kind === 'input'), l => l.amount), dd = sum(led.filter(l => l.kind === 'deduction'), l => l.amount), paid = sum(led.filter(l => l.kind === 'payment'), l => l.amount);
  return {lines, value, adv, inp, dd, paid, due: value - adv - inp - dd - paid};
}
function settlement(fid) {
  const f = byId('farmers', fid), s = settleCalc(fid);
  sheet(`<h3>Settlement · ${esc(f.name)}</h3><table class="t"><tr><th>Lot</th><th class="r">kg</th><th class="r">Moisture cut</th><th class="r">Rate</th><th class="r">Value</th></tr>${s.lines.map(l => `<tr><td>${esc(l.h.lot_no)}${l.rej ? ' <span class="tag bad">rejected</span>' : ''}</td><td class="r">${num(l.h.weight_kg, 0)}</td><td class="r">${num(l.ded, 0)}</td><td class="r">${rs(l.rate)}</td><td class="r">${rs(l.value)}</td></tr>`).join('')}</table>
  <p>Harvest value <b>${rs(s.value)}</b><br>− Advance ${rs(s.adv)}<br>− Inputs ${rs(s.inp)}<br>− Deductions ${rs(s.dd)}<br>− Already paid ${rs(s.paid)}<br><b>Balance to pay: ${rs(s.due)}</b></p>
  <div class="btns"><button class="btn" onclick="window.print()">Print</button>${isOwner() && s.due > 0 ? `<button class="btn pri" onclick="closeSheet();ledgerForm('${fid}','payment')">Record payment</button>` : ''}<button class="btn" onclick="closeSheet()">Close</button></div>`);
}
function vPayments() {
  const rows = visibleFarmers().map(f => ({f, s: settleCalc(f.id)})).filter(x => x.s.value || x.s.adv || x.s.inp);
  return hdr('Payments & advances') + `<div class="wrap"><div class="tiles"><div class="tile"><b>${rs(sum(rows, r => r.s.adv))}</b><span>Advance given</span></div><div class="tile"><b>${rs(sum(rows, r => r.s.inp))}</b><span>Inputs given</span></div><div class="tile"><b>${rs(sum(rows, r => r.s.value))}</b><span>Harvest value</span></div><div class="tile"><b>${rs(sum(rows, r => Math.max(0, r.s.due)))}</b><span>To pay</span></div></div>
  <div class="btns" style="margin-bottom:12px">${can(37) ? '<button class="btn" onclick="bankFile()">Bank payment file (CSV)</button>' : ''}${can(35) ? '<button class="btn" onclick="advanceReport()">Advance outstanding (Excel)</button>' : ''}</div>
  <div class="card tw"><table class="t"><tr><th>Farmer</th><th class="r">Advance</th><th class="r">Inputs</th><th class="r">Harvest</th><th class="r">Balance</th></tr>${rows.map(r => `<tr onclick="go('ledger/${r.f.id}')"><td>${esc(r.f.name)}<br><span class="sm mut">${esc(r.f.code)} · ${esc(userName(r.f.organizer_id))}</span></td><td class="r">${rs(r.s.adv)}</td><td class="r">${rs(r.s.inp)}</td><td class="r">${rs(r.s.value)}</td><td class="r"><b>${rs(r.s.due)}</b></td></tr>`).join('') || '<tr><td colspan="5" class="mut">No money entries yet.</td></tr>'}</table></div></div>`;
}
function bankFile() {
  const rows = visibleFarmers().map(f => ({f, s: settleCalc(f.id)})).filter(x => x.s.due > 0 && x.f.bank && x.f.bank.acno).map(({f, s}) => ({'Beneficiary name': f.name, 'Account number': f.bank.acno, IFSC: f.bank.ifsc, Amount: s.due, Narration: `Seed payment ${f.code}`, Mobile: f.mobile}));
  if (!rows.length) return toast('Nobody to pay with bank details'); downloadText(`bank-payments-${today()}.csv`, csv(rows)); toast(`${rows.length} payments in the file — check it before uploading to the bank`);
}
function advanceReport() { exportXlsx('advance-outstanding', {Advance: visibleFarmers().map(f => ({f, s: settleCalc(f.id)})).filter(x => x.s.adv || x.s.inp).map(({f, s}) => ({'Farmer ID': f.code, Farmer: f.name, Village: f.village, Organizer: userName(f.organizer_id), Advance: s.adv, Inputs: s.inp, 'Harvest value': s.value, Balance: s.due}))}); }

/* ---------- agreements (2, 3, 4, 5, 86, 87) ---------- */
const DEFAULT_TEMPLATE = `SEED PRODUCTION AGREEMENT

Agreement No. {{no}}    Date: {{date}}

This agreement is made between {{company}}, {{company_address}} (the Company) and {{farmer}}, son/daughter of {{father}}, of {{village}}, {{mandal}}, {{district}}, {{state}}, mobile {{mobile}} (the Grower).

1. The Grower will produce hybrid seed of {{variety}} on {{acres}} acres (survey no. {{survey}}) in season {{season}}, using foundation seed supplied by the Company.
2. The Grower will follow the Company's instructions on isolation, detasseling, rogueing and harvest, and allow Company staff to visit the field.
3. The Company will buy the seed that meets its quality standards at the rate fixed for the season, after deducting advances and inputs supplied.
4. Seed that fails germination or purity standards may be rejected.

Grower's signature                                   For {{company}}`;
function mergeTemplate(t, f, ag) {
  const fl = fieldsOf(f.id), c = byId('companies', f.company_id) || {};
  const m = {no: ag.no, date: dmy(ag.made_on), company: c.name || '', company_address: c.address || '', farmer: f.name, father: f.father, village: f.village, mandal: f.mandal, district: f.district, state: f.state, mobile: f.mobile, variety: [...new Set(fl.map(x => varietyName(x.variety_id)))].join(', '), acres: num(sum(fl, x => x.acres), 2), survey: fl.map(x => x.survey_no).filter(Boolean).join(', '), season: (byId('seasons', ag.season_id) || {}).name || ''};
  return esc(t).replace(/\{\{(\w+)\}\}/g, (_, k) => esc(m[k] ?? ''));
}
async function agreementMake(fid) {
  const f = byId('farmers', fid), sid = (currentSeason() || {}).id; let ag = (S.D.agreements || []).find(a => a.farmer_id === fid && a.season_id === sid);
  if (!ag) { try { ag = await save('spm_agreements', {farmer_id: fid, company_id: f.company_id, season_id: sid}); (S.D.agreements = S.D.agreements || []).push(ag); } catch (e) { return toast(e.message); } }
  const P = setting('print', {size: 'A4', top: 40, firstTop: 60, bottom: 20, left: 18, right: 18, font: 11});
  const tpl = setting('agreement_template', DEFAULT_TEMPLATE), local = can(5) ? setting('agreement_template_local', '') : '';
  sheet(`<h3>Agreement ${esc(ag.no)}</h3><div id="agdoc" style="white-space:pre-wrap;font-size:13px;border:1px solid var(--bd);padding:10px;border-radius:8px;max-height:40vh;overflow:auto">${mergeTemplate(tpl, f, ag)}${local ? '\n\n' + mergeTemplate(local, f, ag) : ''}</div>
  ${can(87) && !['viewer', 'supervisor'].includes(S.me.role) ? `<label class="f">Farmer signature${ag.signature ? ' (signed — sign again to replace)' : ''}</label><canvas class="sig" id="sig"></canvas><div class="btns"><button class="btn sm" id="sg_c">Clear</button><button class="btn sm pri" id="sg_s">Save signature</button></div>` : ''}
  <div class="btns" style="margin-top:12px"><button class="btn pri" id="ag_p">Print / PDF</button>${can(86) && f.mobile ? `<a class="btn" target="_blank" rel="noopener" href="https://wa.me/91${esc(f.mobile)}?text=${encodeURIComponent(`Your seed production agreement ${ag.no} with ${companyName(f.company_id)} is ready.`)}">Share on WhatsApp</a>` : ''}<button class="btn" onclick="closeSheet()">Close</button></div>`, p => {
    const c = p.querySelector('#sig'); if (c) { c.width = c.clientWidth; c.height = 160; const x = c.getContext('2d'); x.lineWidth = 2.5; x.lineCap = 'round'; let d = false, drawn = false;
      const pos = e => { const r = c.getBoundingClientRect(), t = e.touches ? e.touches[0] : e; return [t.clientX - r.left, t.clientY - r.top]; };
      const s = e => { d = true; x.beginPath(); x.moveTo(...pos(e)); e.preventDefault(); }, m = e => { if (!d) return; x.lineTo(...pos(e)); x.stroke(); drawn = true; e.preventDefault(); }, u = () => d = false;
      c.addEventListener('pointerdown', s); c.addEventListener('pointermove', m); addEventListener('pointerup', u);
      p.querySelector('#sg_c').onclick = () => { x.clearRect(0, 0, c.width, c.height); drawn = false; };
      p.querySelector('#sg_s').onclick = async () => { if (!drawn) return toast('Ask the farmer to sign'); try { const r = await save('spm_agreements', {signature: c.toDataURL('image/png')}, {id: ag.id}); Object.assign(ag, r); toast('Signature saved'); } catch (e) { toast(e.message); } }; }
    p.querySelector('#ag_p').onclick = () => printAgreement(f, ag, P, tpl, local);
  });
}
function printAgreement(f, ag, P, tpl, local) {
  const sizes = {A4: [210, 297], Legal: [216, 356], Letter: [216, 279]}; const [w, h] = P.size === 'Custom' ? [P.w, P.h] : sizes[P.size] || sizes.A4;
  const c = byId('companies', f.company_id) || {};
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${esc(ag.no)}</title><style>@page{size:${w}mm ${h}mm;margin:${P.top}mm ${P.right}mm ${P.bottom}mm ${P.left}mm}@page:first{margin-top:${P.firstTop}mm}body{font:${P.font}pt/1.5 "Noto Sans",Arial,sans-serif;white-space:pre-wrap}.f{position:fixed;bottom:-${P.bottom - 4}mm;left:0;right:0;font-size:8pt;color:#555;text-align:center}img{height:60px}</style></head><body>${mergeTemplate(tpl, f, ag)}${local ? '\n\n' + mergeTemplate(local, f, ag) : ''}${ag.signature ? `\n\n<img src="${ag.signature}" alt="Signature">` : ''}<div class="f">Agreement between ${esc(c.name || '')} and ${esc(f.name)} | No. ${esc(ag.no)} | ${dmy(ag.made_on)}</div><script>onload=()=>setTimeout(()=>print(),300)<\/script></body></html>`;
  const wdw = window.open('', '_blank'); if (!wdw) return toast('Allow pop-ups to print'); wdw.document.write(html); wdw.document.close();
}
