/* Tracking: check-in/out, live location, visits, route, maps, person timeline, exceptions */
'use strict';
const WORK = () => setting('work_hours', {from: '07:00', to: '19:00'});
const inWorkHours = () => { const w = WORK(), n = new Date(), hm = pad(n.getHours()) + ':' + pad(n.getMinutes()); return hm >= w.from && hm <= w.to; };
const myAtt = () => (S.D.attendance || []).find(a => a.user_id === S.me.id && a.day === today());

/* ---------- consent (feature 220) ---------- */
async function ensureConsent() {
  if (!can(220) || (S.me && S.me.consent_at)) return true;
  const ok = await ask('Location tracking', `While you are checked in and between ${WORK().from} and ${WORK().to}, this app records your location every few minutes so your team can see field work. Nothing is recorded after you check out or outside work hours. Do you agree?`, 'I agree');
  if (ok) { await save('spm_users', {consent_at: new Date().toISOString()}, {id: S.me.id}).catch(() => {}); S.me.consent_at = new Date().toISOString(); }
  return ok;
}

/* ---------- attendance (131, 132, 72, 218) ---------- */
function attendanceCard() {
  const a = myAtt();
  if (!a) return `<div class="card"><h2>Start of day</h2><button class="btn pri block big-btn" onclick="checkIn()">${T('Check in')}</button><p class="sm mut">Records time and GPS.</p></div>`;
  if (!a.out_at) return `<div class="card"><h2>Checked in at ${tm(a.in_at)}<span class="sp"></span><span class="tag ok">Working</span></h2><p class="sm mut" id="trk">${tracking.on ? 'Location sharing on' : can(201) ? 'Location sharing off' : ''}</p><div class="btns"><button class="btn" onclick="go('route')">Today's route</button><button class="btn bad" onclick="checkOut()">${T('Check out')}</button></div></div>`;
  return `<div class="card"><h2>Day finished<span class="sp"></span><span class="tag">${tm(a.in_at)} – ${tm(a.out_at)}</span></h2><p class="sm mut">${num(a.km)} km travelled</p></div>`;
}
async function checkIn() {
  if (!(await ensureConsent())) return;
  try { const fx = await gpsDialog('Check in'); const r = await save('spm_attendance', {in_lat: fx.lat, in_lng: fx.lng, in_acc: fx.acc, note: fx.mock ? 'Location looked fake' : ''}); (S.D.attendance = S.D.attendance || []).push(r); toast('Checked in at ' + tm(r.in_at)); startTracking(); render(); }
  catch (e) { toast(e.message); }
}
async function checkOut() {
  const a = myAtt(); if (!a) return;
  try { let fx = {}; try { fx = await gpsDialog('Check out'); } catch (e) { if (e.message === 'Cancelled') return; }
    const km = await dayKm(S.me.id, today()); const r = await save('spm_attendance', {out_at: new Date().toISOString(), out_lat: fx.lat || null, out_lng: fx.lng || null, out_acc: fx.acc || null, km: Math.round(km * 10) / 10}, {id: a.id});
    Object.assign(a, r); stopTracking(); toast('Checked out'); render(); } catch (e) { toast(e.message); }
}
async function dayKm(userId, day) { try { const pts = await rest('spm_track_points', `select=lat,lng,acc,at&user_id=eq.${userId}&at=gte.${day}T00:00:00%2B05:30&at=lt.${addDays(day, 1)}T00:00:00%2B05:30&order=at`); return routeKm(pts); } catch (e) { return 0; } }
function routeKm(pts) { let k = 0; for (let i = 1; i < pts.length; i++) { if ((pts[i].acc || 0) > 60) continue; const d = haversine(pts[i - 1].lat, pts[i - 1].lng, pts[i].lat, pts[i].lng); if (d < 5000) k += d; } return k / 1000; }

/* ---------- live location while the app is open (201, 219, 221, 222, 163, 207) ---------- */
const tracking = {on: false, watch: null, last: null, lastSent: 0, timer: null};
async function startTracking() {
  if (tracking.on || !can(201) || !S.me || !['sub_organizer', 'field_staff', 'company_assistant'].includes(S.me.role)) return;
  const a = myAtt(); if (!a || a.out_at || !S.me.consent_at || !inWorkHours()) return;
  tracking.on = true; const every = can(221) && (await batteryLevel()) < 0.2 ? 600000 : 180000;
  tracking.watch = navigator.geolocation.watchPosition(async p => {
    const c = p.coords, now = Date.now(); if (!inWorkHours()) return stopTracking();
    const moved = tracking.last ? haversine(tracking.last.lat, tracking.last.lng, c.latitude, c.longitude) : 9999;
    if (now - tracking.lastSent < every && moved < 150) return;
    const jump = tracking.last && tracking.lastSent ? moved / ((now - tracking.lastSent) / 1000) : 0; // m/s
    const pt = {lat: c.latitude, lng: c.longitude, acc: c.accuracy, speed: c.speed, battery: await batteryLevel(), mock: can(207) && jump > 70};
    tracking.last = pt; tracking.lastSent = now; save('spm_track_points', pt).catch(() => {});
    if (can(163) && pt.battery != null && pt.battery < 0.15) toast('Battery low — charge your phone to keep tracking');
    if (can(163) && c.accuracy > 100) toast('Weak GPS signal');
  }, () => {}, {enableHighAccuracy: true, maximumAge: 60000});
  const el = $('#trk'); if (el) el.textContent = 'Location sharing on';
}
function stopTracking() { if (tracking.watch != null) navigator.geolocation.clearWatch(tracking.watch); tracking.on = false; tracking.watch = null; }
async function batteryLevel() { try { const b = await navigator.getBattery(); return b.level; } catch (e) { return null; } }

/* ---------- visits (135, 136, 139–145, 149, 160, 204, 61) ---------- */
const openVisit = () => (S.D.visits || []).find(v => v.user_id === (S.me || {}).id && !v.end_at && v.start_at.slice(0, 10) === today());
function visitControls(x) {
  const ov = openVisit();
  if (ov && ov.field_id === x.id) return `<p>Visit started ${tm(ov.start_at)} ${ov.inside === false ? '<span class="tag bad">You were outside the field</span>' : ov.inside ? '<span class="tag ok">At field</span>' : ''}</p><button class="btn pri block big-btn" onclick="endVisit('${ov.id}')">${T('End visit')}</button>`;
  if (ov) return `<p class="mut">Finish your visit at another field first.</p><button class="btn" onclick="go('field/${ov.field_id}')">Go to open visit</button>`;
  const lv = lastVisit(x.id); return `${lv ? `<p class="sm mut">Last visit ${dmy(lv.start_at.slice(0, 10))} by ${esc(userName(lv.user_id))}</p>` : ''}<button class="btn pri block big-btn" onclick="startVisit('${x.id}')">${T('Start visit')}</button>`;
}
async function startVisit(fieldId) {
  const x = byId('fields', fieldId); if (can(131) && ['field_staff', 'company_assistant', 'sub_organizer'].includes(S.me.role) && !myAtt()) { if (await ask('Not checked in', 'Check in first so the day is recorded?', 'Check in')) await checkIn(); if (!myAtt()) return; }
  try { const fx = await gpsDialog('Start visit'); const radius = setting('visit_radius_m', 100);
    const dist = x.lat != null ? haversine(fx.lat, fx.lng, x.lat, x.lng) : null; const inside = dist == null ? null : dist <= radius + (fx.acc || 0);
    if (can(136) && inside === false && !(await ask('You are not at the field', `You are about ${Math.round(dist)} m from the saved field location (limit ${radius} m). Start anyway? It will be marked "outside field".`, 'Start anyway'))) return;
    const flags = []; if (inside === false) flags.push('outside field'); if (fx.mock) flags.push('fake GPS suspected'); if (x.lat == null) flags.push('field has no location');
    const r = await save('spm_visits', {field_id: fieldId, farmer_id: x.farmer_id, lat: fx.lat, lng: fx.lng, acc: fx.acc, dist_m: dist, inside, flags});
    (S.D.visits = S.D.visits || []).unshift(r); if (x.lat == null && (can(146) || can(117)) && await ask('Field has no location', 'Save your current location as the field location?', 'Save location')) { const f2 = await save('spm_fields', {lat: fx.lat, lng: fx.lng, acc: fx.acc, loc_source: 'Visit GPS', loc_at: new Date().toISOString()}, {id: fieldId}); Object.assign(x, f2); }
    toast('Visit started'); render();
  } catch (e) { toast(e.message); }
}
function endVisit(id) {
  const v = (S.D.visits || []).find(z => z.id === id), x = byId('fields', v.field_id) || {};
  const stages = ['Sowing', 'Germination', 'Vegetative', 'Tasseling', 'Silking', 'Grain filling', 'Maturity', 'Harvested'];
  sheet(`<h3>${T('End visit')}</h3>
  ${can(139) ? `<label class="f">Crop stage</label><select class="in" id="vs_stage"><option value=""></option>${stages.map(s => `<option>${s}</option>`).join('')}</select>
  <label class="f">Condition</label><div class="chips" id="vs_cond">${['Good', 'Average', 'Poor'].map(c => `<button class="chip" data-v="${c}">${c}</button>`).join('')}</div>` : ''}
  <div class="row">${can(140) ? `<div><label class="f">Plant count / stand count</label><input class="in" id="vs_pc" inputmode="numeric"></div>` : ''}${can(141) ? `<div><label class="f">Detasseling done %</label><input class="in" id="vs_det" inputmode="numeric"></div>` : ''}</div>
  <div class="row">${can(143) ? `<div><label class="f">Off-types / pollen shedders</label><input class="in" id="vs_off" inputmode="numeric"></div>` : ''}${can(149) || can(107) ? `<div><label class="f">Labour count</label><input class="in" id="vs_lab" inputmode="numeric"></div>` : ''}</div>
  ${can(142) ? `<label class="sm" style="display:flex;gap:8px;margin-top:10px"><input type="checkbox" id="vs_rog"> Rogueing done</label>` : ''}
  ${can(145) ? `<label class="f">Irrigation status</label><select class="in" id="vs_irr"><option></option><option>Adequate</option><option>Needs water</option><option>Waterlogged</option></select>` : ''}
  ${can(160) ? `<div class="row"><div><label class="f">Grain moisture %</label><input class="in" id="vs_moist" inputmode="decimal"></div><div><label class="f">Grain / cob</label><input class="in" id="vs_grain" placeholder="e.g. hard, black layer"></div></div>` : ''}
  <label class="f">Note</label><textarea class="in" id="vs_note"></textarea>
  ${can(151) ? `<button class="btn sm" id="vs_voice" style="margin-top:6px">🎤 Voice note</button>` : ''}
  <button class="btn sm" id="vs_ph" style="margin-top:6px">Add photo</button><div id="vs_phs" class="sm mut"></div>
  <div class="btns" style="margin-top:14px"><button class="btn pri" id="vs_save">${T('End visit')}</button><button class="btn" onclick="closeSheet()">${T('Cancel')}</button></div>`, p => {
    let cond = '', photos = [], fx = null; $$('#vs_cond .chip', p).forEach(c => c.onclick = () => { cond = c.dataset.v; $$('#vs_cond .chip', p).forEach(z => z.classList.toggle('on', z === c)); });
    p.querySelector('#vs_ph').onclick = async () => { try { fx = fx || await gpsFix({maxMs: 15000, need: 50}).catch(() => null); const path = await uploadPhoto(await pickPhoto(fx)); photos.push(path); p.querySelector('#vs_phs').textContent = photos.length + ' photo(s) added'; } catch (e) { toast(e.message); } };
    const vb = p.querySelector('#vs_voice'); if (vb) vb.onclick = () => { const R = window.SpeechRecognition || window.webkitSpeechRecognition; if (!R) return toast('Voice typing not available on this phone'); const r = new R(); r.lang = {te: 'te-IN', bn: 'bn-IN', hi: 'hi-IN'}[prefs().lang] || 'en-IN'; r.onresult = e => { p.querySelector('#vs_note').value += ' ' + e.results[0][0].transcript; }; r.start(); vb.textContent = 'Listening…'; r.onend = () => vb.textContent = '🎤 Voice note'; };
    p.querySelector('#vs_save').onclick = async () => {
      const g = k => (p.querySelector('#vs_' + k) || {}).value; const n = k => { const v = parseFloat(g(k)); return isNaN(v) ? null : v; };
      let end = {}; try { end = await gpsFix({maxMs: 20000, need: 50}); } catch (e) {}
      const minutes = (Date.now() - new Date(v.start_at)) / 60000, minNeed = setting('visit_minutes_per_acre', 20) * (x.acres || 1) * 0.25;
      const flags = [...(v.flags || [])]; if (can(61) && minutes < Math.min(minNeed, 30)) flags.push('short visit');
      const row = {end_at: new Date().toISOString(), end_lat: end.lat || null, end_lng: end.lng || null, minutes: Math.round(minutes * 10) / 10, stage: g('stage') || '', condition: cond, plant_count: n('pc'), detassel_pct: n('det'), offtype_count: n('off'), labour_count: n('lab'), rogue_done: p.querySelector('#vs_rog') ? p.querySelector('#vs_rog').checked : null, irrigation_status: g('irr') || '', moisture: n('moist'), grain: g('grain') || '', note: g('note') || '', photos, flags};
      try { const r = await save('spm_visits', row, {id}); Object.assign(v, r); closeSheet(); toast('Visit saved'); render(); } catch (e) { toast(e.message); }
    };
  });
}
function visitSheet(id) {
  const v = (S.D.visits || []).find(z => z.id === id); if (!v) return; const f = byId('farmers', v.farmer_id) || {};
  sheet(`<h3>Visit · ${dt(v.start_at)}</h3><p>${esc(userName(v.user_id))} · ${esc(f.name)}<br>${v.end_at ? `Ended ${tm(v.end_at)} · ${Math.round(v.minutes || 0)} min` : 'Still open'}${v.dist_m != null ? ` · ${Math.round(v.dist_m)} m from field` : ''}</p>
  <p>${[v.stage && 'Stage: ' + esc(v.stage), v.condition && 'Condition: ' + esc(v.condition), v.plant_count != null && 'Plants: ' + v.plant_count, v.detassel_pct != null && 'Detasseling: ' + v.detassel_pct + '%', v.offtype_count != null && 'Off-types: ' + v.offtype_count, v.rogue_done && 'Rogueing done', v.labour_count != null && 'Labour: ' + v.labour_count, v.irrigation_status && 'Irrigation: ' + esc(v.irrigation_status), v.moisture != null && 'Moisture: ' + v.moisture + '%'].filter(Boolean).join('<br>')}</p>
  ${v.note ? `<p>${esc(v.note)}</p>` : ''}${photoStrip(v.photos)}${(v.flags || []).length ? `<p><span class="tag warn">${esc(v.flags.join(', '))}</span></p>` : ''}
  <div class="btns"><button class="btn" onclick="closeSheet()">Close</button>${v.lat ? `<a class="btn" target="_blank" rel="noopener" href="${mapsLink(v.lat, v.lng)}">Where</a>` : ''}</div>`, p => hydratePhotos(p));
}

/* ---------- route order (91, 133) ---------- */
function vRoute() {
  return hdr("Today's route", 'Due fields, nearest first') + `<div class="wrap"><div class="card" id="rt"><p class="mut">Getting your location…</p></div></div>`;
}
async function bindRoute() {
  const due = allDue(); const seen = new Set(); let list = due.filter(d => { if (seen.has(d.field.id)) return false; seen.add(d.field.id); return d.field.lat != null; });
  let here = null; try { here = await gpsFix({maxMs: 15000, need: 100}); } catch (e) {}
  const out = []; let cur = here; while (list.length) { if (cur) list.sort((a, b) => haversine(cur.lat, cur.lng, a.field.lat, a.field.lng) - haversine(cur.lat, cur.lng, b.field.lat, b.field.lng)); const n = list.shift(); out.push({...n, d: cur ? haversine(cur.lat, cur.lng, n.field.lat, n.field.lng) : null}); cur = {lat: n.field.lat, lng: n.field.lng}; }
  const noLoc = due.filter(d => d.field.lat == null).length;
  ($('#rt') || {}).innerHTML = (out.length ? `<div class="list">${out.map((d, i) => { const f = farmerOf(d.field) || {}; return `<div class="it" onclick="go('field/${d.field.id}')"><div class="av">${i + 1}</div><div class="main"><b>${esc(f.name)} · ${esc(d.ev.name)}</b><span>${esc(f.village)} · ${d.d != null ? num(d.d / 1000) + ' km' : ''}</span></div><div class="side"><a class="btn sm" target="_blank" rel="noopener" href="${navLink(d.field.lat, d.field.lng)}" onclick="event.stopPropagation()">Go</a></div></div>`; }).join('')}</div>` : '<p class="mut">No due fields with a location.</p>') + (noLoc ? `<p class="sm mut">${noLoc} due fields have no location.</p>` : '');
}

/* ---------- maps (32, 57, 170, 224) ---------- */
let mapObj = null;
async function needLeaflet() { if (!window.L) { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = 'vendor/leaflet.css'; document.head.appendChild(l); await loadScript('vendor/leaflet.js'); } }
function vMap() { return hdr('Map of fields') + `<div class="wrap"><div class="chips" style="margin-bottom:8px"><button class="chip on" data-m="stage">By status</button>${can(224) ? '<button class="chip" data-m="heat">Visits heatmap</button>' : ''}</div><div id="map" class="map" style="height:70vh"></div><p class="sm mut">Red: overdue · amber: due today · green: on track · grey: not sown.</p></div>`; }
async function bindMap() {
  await needLeaflet(); const pts = (S.D.fields || []).filter(f => f.lat != null && !f.deleted_at); if (mapObj) mapObj.remove();
  mapObj = L.map('map'); L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom: 19, attribution: '© OpenStreetMap'}).addTo(mapObj);
  const layer = L.layerGroup().addTo(mapObj);
  const draw = mode => { layer.clearLayers();
    if (mode === 'heat') { const g = groupBy((S.D.visits || []).filter(v => v.lat), v => v.lat.toFixed(2) + ',' + v.lng.toFixed(2)); Object.entries(g).forEach(([k, a]) => { const [la, ln] = k.split(',').map(Number); L.circle([la, ln], {radius: 400, color: '#b42318', weight: 0, fillOpacity: Math.min(.7, .1 + a.length / 20)}).bindTooltip(a.length + ' visits').addTo(layer); }); return; }
    pts.forEach(x => { const ev = fieldEvents(x), od = ev.some(e => e.state === 'overdue'), td = ev.some(e => e.state === 'today'); const c = !x.sown_on ? '#9ca3af' : od ? '#b42318' : td ? '#d97706' : '#15803d'; const f = farmerOf(x) || {};
      L.circleMarker([x.lat, x.lng], {radius: 7, color: '#fff', weight: 1, fillColor: c, fillOpacity: .9}).bindPopup(`<b>${esc(f.name)}</b><br>${num(x.acres)} ac · ${esc(varietyName(x.variety_id))}<br><a href="#/field/${x.id}">Open field</a>`).addTo(layer); }); };
  draw('stage'); if (pts.length) mapObj.fitBounds(pts.map(x => [x.lat, x.lng]), {padding: [20, 20]}); else mapObj.setView([17.4, 78.4], 8);
  $$('[data-m]').forEach(b => b.onclick = () => { $$('[data-m]').forEach(z => z.classList.toggle('on', z === b)); draw(b.dataset.m); });
}

/* ---------- people: timeline, route replay, attendance calendar, score (58, 59, 202, 203, 215, 218, 223) ---------- */
function vPerson(id) {
  const u = byId('users', id); if (!u) return hdr('Person') + '<div class="wrap"><div class="card">Not visible to you.</div></div>';
  const kids = (S.D.users || []).filter(k => k.parent_id === id), fs = (S.D.farmers || []).filter(f => !f.deleted_at && [f.organizer_id, f.sub_organizer_id, f.field_staff_id].includes(id));
  return hdr(u.full_name, ROLE[u.role] + (u.phone ? ' · ' + esc(u.phone) : '')) + `<div class="wrap">
  <div class="tiles"><div class="tile"><b>${fs.length}</b><span>Farmers</span></div><div class="tile"><b>${num(sum(fs.flatMap(f => fieldsOf(f.id)), x => x.acres))}</b><span>Acres</span></div>${can(223) ? `<div class="tile" id="score"><b>…</b><span>Score (30 days)</span></div>` : ''}</div>
  ${kids.length && can(215) ? `<div class="card"><h2>Team below</h2><div class="list">${kids.map(k => `<div class="it" onclick="go('person/${k.id}')"><div class="av">${esc(initials(k.full_name))}</div><div class="main"><b>${esc(k.full_name)}</b><span>${ROLE[k.role]}</span></div><div class="side">›</div></div>`).join('')}</div></div>` : ''}
  ${can(202) || can(58) ? `<div class="card"><h2>Day timeline<span class="sp"></span><input type="date" class="in" id="pday" value="${today()}" max="${today()}" style="width:auto"></h2><div id="ptl" class="mut">Loading…</div>${can(203) || can(59) ? '<div id="pmap" class="map" style="margin-top:10px"></div>' : ''}</div>` : ''}
  ${can(218) || can(72) ? `<div class="card"><h2>Attendance this month</h2><div id="pcal" class="mut">Loading…</div></div>` : ''}
  ${fs.length && can(215) ? `<div class="card"><h2>Farmers</h2><div class="list">${fs.slice(0, 50).map(f => `<div class="it" onclick="go('farmer/${f.id}')"><div class="main"><b>${esc(f.name)}</b><span>${esc(f.code)} · ${esc(f.village)}</span></div><div class="side">›</div></div>`).join('')}</div></div>` : ''}
  ${isOwner() ? `<div class="btns"><button class="btn" onclick="go('team/edit/${id}')">Edit person</button></div>` : ''}</div>`;
}
async function bindPerson(id) {
  const load = async day => {
    const el = $('#ptl'); if (!el) return; el.textContent = 'Loading…';
    try { const [pts, vis, att] = await Promise.all([rest('spm_track_points', `select=*&user_id=eq.${id}&at=gte.${day}T00:00:00%2B05:30&at=lt.${addDays(day, 1)}T00:00:00%2B05:30&order=at`),
        rest('spm_visits', `select=*&user_id=eq.${id}&start_at=gte.${day}T00:00:00%2B05:30&start_at=lt.${addDays(day, 1)}T00:00:00%2B05:30&order=start_at`), rest('spm_attendance', `select=*&user_id=eq.${id}&day=eq.${day}`)]);
      const a = att[0]; const items = [];
      if (a) items.push([a.in_at, `Checked in${a.in_lat ? '' : ' (no GPS)'}`]); vis.forEach(v => { const f = byId('farmers', v.farmer_id) || {}; items.push([v.start_at, `Visit: ${esc(f.name)} ${v.minutes ? '· ' + Math.round(v.minutes) + ' min' : '· open'} ${(v.flags || []).length ? `<span class="tag warn">${esc(v.flags.join(', '))}</span>` : ''}`]); });
      if (a && a.out_at) items.push([a.out_at, 'Checked out']); items.sort((x, y) => x[0].localeCompare(y[0]));
      const gaps = []; const ts = [...pts.map(p => p.at), ...vis.map(v => v.start_at)].sort(); for (let i = 1; i < ts.length; i++) if (new Date(ts[i]) - new Date(ts[i - 1]) > 2 * 3600e3) gaps.push(`${tm(ts[i - 1])}–${tm(ts[i])}`);
      el.innerHTML = (items.length ? items.map(([t, s]) => `<div class="sm" style="padding:4px 0"><b>${tm(t)}</b> · ${s}</div>`).join('') : '<p class="mut">No activity.</p>') + `<p class="sm mut">${num(routeKm(pts))} km · ${pts.length} location points${pts.some(p => p.mock) ? ' · <span class="tag bad">fake GPS suspected</span>' : ''}${can(206) && gaps.length ? ` · <span class="tag warn">Idle ${gaps.join(', ')}</span>` : ''}</p>`;
      if ($('#pmap') && (pts.length || vis.length)) { await needLeaflet(); if (mapObj) mapObj.remove(); mapObj = L.map('pmap'); L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom: 19, attribution: '© OpenStreetMap'}).addTo(mapObj);
        const ll = pts.map(p => [p.lat, p.lng]); if (ll.length > 1) L.polyline(ll, {color: '#1d4ed8', weight: 3}).addTo(mapObj);
        vis.filter(v => v.lat).forEach(v => L.circleMarker([v.lat, v.lng], {radius: 7, color: v.inside === false ? '#b42318' : '#15803d'}).bindTooltip(tm(v.start_at)).addTo(mapObj));
        const all = [...ll, ...vis.filter(v => v.lat).map(v => [v.lat, v.lng])]; mapObj.fitBounds(all, {padding: [20, 20], maxZoom: 16}); } else if ($('#pmap')) $('#pmap').innerHTML = '<p class="mut c" style="padding:20px">No route for this day.</p>';
    } catch (e) { el.textContent = e.message; }
  };
  const d = $('#pday'); if (d) { d.onchange = () => load(d.value); load(d.value); }
  const cal = $('#pcal'); if (cal) { const m = today().slice(0, 7); try { const rows = await rest('spm_attendance', `select=day,in_at,out_at,km&user_id=eq.${id}&day=gte.${m}-01&order=day`); const lv = (S.D.leaves || []).filter(l => l.user_id === id && l.status === 'approved');
    const days = new Date(+m.slice(0, 4), +m.slice(5, 7), 0).getDate(); cal.innerHTML = `<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px">${Array.from({length: days}, (_, i) => { const dd = `${m}-${pad(i + 1)}`, a = rows.find(r => r.day === dd), l = lv.some(x => x.from_day <= dd && x.to_day >= dd); return `<div class="c sm" style="padding:6px 0;border-radius:6px;background:${a ? 'var(--okbg)' : l ? 'var(--warnbg)' : dd < today() ? 'var(--badbg)' : 'var(--soft)'}">${i + 1}<br>${a ? tm(a.in_at) : l ? 'Leave' : ''}</div>`; }).join('')}</div><p class="sm mut">${rows.length} days present · ${num(sum(rows, r => r.km))} km</p>`; } catch (e) { cal.textContent = e.message; } }
  const sc = $('#score'); if (sc) { try { const from = addDays(today(), -30); const [v, a] = await Promise.all([rest('spm_visits', `select=inside,flags,minutes&user_id=eq.${id}&start_at=gte.${from}`), rest('spm_attendance', `select=day&user_id=eq.${id}&day=gte.${from}`)]);
    const good = v.filter(x => x.inside !== false && !(x.flags || []).includes('short visit')).length; const s = Math.round(Math.min(100, (a.length / 26) * 40 + Math.min(1, v.length / 60) * 40 + (v.length ? good / v.length : 0) * 20)); sc.innerHTML = `<b>${s}</b><span>Score (30 days) · ${v.length} visits, ${a.length} days</span>`; } catch (e) { sc.remove(); } }
}

/* ---------- exceptions (217, 60, 61, 206, 207, 208, 74) ---------- */
function vExceptions() { return hdr('Exceptions', 'Things that need attention') + `<div class="wrap" id="exc"><div class="card mut">Loading…</div></div>`; }
async function bindExceptions() {
  const el = $('#exc'); const from = addDays(today(), -7);
  try { const [v, pts, att] = await Promise.all([rest('spm_visits', `select=*&start_at=gte.${from}&order=start_at.desc`), rest('spm_track_points', `select=user_id,at,mock&at=gte.${today()}&mock=eq.true`), rest('spm_attendance', `select=*&day=eq.${today()}`)]);
    const staff = (S.D.users || []).filter(u => ['sub_organizer', 'field_staff', 'company_assistant'].includes(u.role) && u.active);
    const bad = v.filter(x => (x.flags || []).length), missing = staff.filter(u => !att.find(a => a.user_id === u.id)), fake = [...new Set(pts.map(p => p.user_id))];
    const overdueLong = allDue().filter(d => d.late >= setting('escalate_days', 7));
    const idle = [];
    if (can(206) && inWorkHours()) { for (const a of att.filter(x => !x.out_at)) { const last = [...v.filter(x => x.user_id === a.user_id).map(x => x.start_at), a.in_at].sort().pop(); if (Date.now() - new Date(last) > 2 * 3600e3) idle.push(a.user_id); } }
    const card = (t, arr, fn) => `<div class="card"><h2>${t} (${arr.length})</h2>${arr.length ? `<div class="list">${arr.slice(0, 50).map(fn).join('')}</div>` : '<p class="mut sm">None.</p>'}</div>`;
    el.innerHTML = card('Visit problems (7 days)', bad, x => `<div class="it" onclick="visitSheet('${x.id}')"><div class="main"><b>${esc(userName(x.user_id))} · ${dt(x.start_at)}</b><span>${esc((byId('farmers', x.farmer_id) || {}).name)}</span></div><div class="side"><span class="tag warn">${esc(x.flags.join(', '))}</span></div></div>`)
      + (can(207) ? card('Fake GPS suspected today', fake, u => `<div class="it" onclick="go('person/${u}')"><div class="main"><b>${esc(userName(u))}</b></div><div class="side">›</div></div>`) : '')
      + (can(206) ? card('Idle more than 2 hours', idle, u => `<div class="it" onclick="go('person/${u}')"><div class="main"><b>${esc(userName(u))}</b></div><div class="side">›</div></div>`) : '')
      + card('Not checked in today', missing, u => `<div class="it" onclick="go('person/${u.id}')"><div class="main"><b>${esc(u.full_name)}</b><span>${ROLE[u.role]}</span></div><div class="side">${u.phone ? `<a class="btn sm" href="tel:${esc(u.phone)}" onclick="event.stopPropagation()">Call</a>` : ''}</div></div>`)
      + card(`Overdue ${setting('escalate_days', 7)}+ days`, overdueLong, d => { const f = farmerOf(d.field) || {}; return `<div class="it" onclick="go('field/${d.field.id}')"><div class="main"><b>${esc(f.name)} · ${esc(d.ev.name)}</b><span>${esc(userName(f.organizer_id))}</span></div><div class="side"><span class="tag bad">${d.late} days</span></div></div>`; });
    el.querySelectorAll('img[data-ph]').length && hydratePhotos(el);
  } catch (e) { el.innerHTML = `<div class="card">${esc(e.message)}</div>`; }
}

/* ---------- expenses & leave (157, 158) ---------- */
function expenseForm() {
  sheet(`<h3>Expense</h3><label class="f">Type</label><select class="in" id="ex_k"><option>fuel</option><option>food</option><option>travel</option><option>other</option></select>
  <div class="row"><div><label class="f">Amount ₹</label><input class="in" id="ex_a" inputmode="decimal"></div><div><label class="f">Date</label><input class="in" type="date" id="ex_d" value="${today()}" max="${today()}"></div></div>
  <label class="f">Note</label><input class="in" id="ex_n"><button class="btn sm" id="ex_ph" style="margin-top:8px">Bill photo</button>
  <div class="btns" style="margin-top:12px"><button class="btn pri" id="ex_s">Save</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, p => {
    let photo = ''; p.querySelector('#ex_ph').onclick = async () => { try { photo = await uploadPhoto(await pickPhoto()); p.querySelector('#ex_ph').textContent = '✓ Bill added'; } catch (e) { toast(e.message); } };
    p.querySelector('#ex_s').onclick = async () => { const a = parseFloat(p.querySelector('#ex_a').value); if (!(a >= 0)) return toast('Enter the amount'); try { const r = await save('spm_expenses', {kind: p.querySelector('#ex_k').value, amount: a, day: p.querySelector('#ex_d').value, note: p.querySelector('#ex_n').value, photo}); (S.D.expenses = S.D.expenses || []).unshift(r); closeSheet(); toast('Expense sent for approval'); render(); } catch (e) { toast(e.message); } };
  });
}
function leaveForm() {
  sheet(`<h3>Leave request</h3><div class="row"><div><label class="f">From</label><input class="in" type="date" id="lv_f" value="${today()}"></div><div><label class="f">To</label><input class="in" type="date" id="lv_t" value="${today()}"></div></div><label class="f">Reason</label><input class="in" id="lv_r">
  <div class="btns" style="margin-top:12px"><button class="btn pri" id="lv_s">Send</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, p => {
    p.querySelector('#lv_s').onclick = async () => { const f = p.querySelector('#lv_f').value, t = p.querySelector('#lv_t').value; if (t < f) return toast('End date is before start'); try { const r = await save('spm_leaves', {from_day: f, to_day: t, reason: p.querySelector('#lv_r').value}); (S.D.leaves = S.D.leaves || []).unshift(r); closeSheet(); toast('Leave request sent'); render(); } catch (e) { toast(e.message); } };
  });
}
function vMyWork() {
  const mine = (S.D.visits || []).filter(v => v.user_id === S.me.id); const wk = addDays(today(), -6);
  const ex = (S.D.expenses || []).filter(e => e.user_id === S.me.id).slice(0, 10), lv = (S.D.leaves || []).filter(e => e.user_id === S.me.id).slice(0, 5);
  return hdr('My work') + `<div class="wrap"><div class="tiles"><div class="tile"><b>${mine.filter(v => v.start_at.slice(0, 10) === today()).length}</b><span>Visits today</span></div><div class="tile"><b>${mine.filter(v => v.start_at.slice(0, 10) >= wk).length}</b><span>Visits this week</span></div></div>
  <div class="btns" style="margin-bottom:12px">${can(157) ? '<button class="btn" onclick="expenseForm()">＋ Expense</button>' : ''}${can(158) ? '<button class="btn" onclick="leaveForm()">＋ Leave request</button>' : ''}</div>
  ${ex.length ? `<div class="card"><h2>My expenses</h2>${ex.map(e => `<div class="sm">${dmy(e.day)} · ${esc(e.kind)} · ${rs(e.amount)} · <span class="tag ${e.status === 'approved' ? 'ok' : e.status === 'rejected' ? 'bad' : 'warn'}">${e.status}</span></div>`).join('')}</div>` : ''}
  ${lv.length ? `<div class="card"><h2>My leave</h2>${lv.map(e => `<div class="sm">${dmy(e.from_day)}–${dmy(e.to_day)} · <span class="tag ${e.status === 'approved' ? 'ok' : e.status === 'rejected' ? 'bad' : 'warn'}">${e.status}</span></div>`).join('')}</div>` : ''}
  <div class="card"><h2>Recent visits</h2>${mine.slice(0, 20).map(v => `<div class="it" onclick="visitSheet('${v.id}')"><div class="main"><b>${esc((byId('farmers', v.farmer_id) || {}).name)}</b><span>${dt(v.start_at)}</span></div></div>`).join('') || '<p class="mut">No visits yet.</p>'}</div></div>`;
}
