/* Start-up, navigation and routing */
'use strict';
async function loadExtra(keys) {
  if (S.farmer) return; const since = n => addDays(today(), -n); const q = (t, x) => rest(t, x).catch(() => []);
  const all = {
    visits: () => q('spm_visits', `select=*&start_at=gte.${since(90)}&order=start_at.desc&limit=5000`), attendance: () => q('spm_attendance', `select=*&day=gte.${since(31)}`),
    reports: () => q('spm_reports', 'select=*&order=at.desc&limit=300'), tasks: () => q('spm_tasks', 'select=*&order=at.desc&limit=300'), ledger: () => q('spm_ledger', 'select=*&order=day.desc&limit=5000'),
    harvests: () => q('spm_harvests', 'select=*'), agreements: () => q('spm_agreements', 'select=id,farmer_id,season_id,no,made_on,company_id,signature'), products: () => q('spm_products', 'select=*&order=name'),
    stock: () => q('spm_stock_moves', 'select=*&order=at.desc&limit=2000'), notices: () => q('spm_notices', 'select=*&order=at.desc&limit=20'), expenses: () => q('spm_expenses', 'select=*&order=day.desc&limit=300'),
    leaves: () => q('spm_leaves', 'select=*&order=at.desc&limit=200'), comments: () => q('spm_comments', 'select=*&order=at.desc&limit=500'), calls: () => q('spm_calls', 'select=*&order=at.desc&limit=500'),
    supOrgs: () => q('spm_supervisor_organizers', 'select=*'), viewerScope: () => q('spm_viewer_scope', 'select=*')};
  const ks = keys || Object.keys(all); const res = await Promise.all(ks.map(k => all[k]())); ks.forEach((k, i) => S.D[k] = res[i]);
  ls.set('spm2_data_' + S.me.id, S.D);
}
function navItems() {
  if (S.farmer) return farmerNav();
  const r = S.me.role, field = ['field_staff', 'company_assistant'].includes(r), hasTeam = isOwner() || ['supervisor', 'organizer', 'sub_organizer'].includes(r) || (S.D.users || []).some(u => u.parent_id === S.me.id);
  const n = [['today', T('Today'), 'today'], ['farmers', T('Farmers'), 'farmers']];
  if (field) n.push(['mywork', T('Track'), 'track']); else if (r === 'viewer') n.push(['reports', T('Reports'), 'today']); else n.push(['approvals', T('Approvals'), 'approvals']);
  if (hasTeam && r !== 'viewer') n.push(['team', T('Team'), 'team']); n.push(['more', T('More'), 'more']); return n;
}
function drawNav() {
  const nav = $('#nav'); const base = (S.route || '').split('/')[0] || (S.farmer ? 'home' : 'today');
  const wait = S.me ? (S.D.farmers || []).filter(f => f.status === 'waiting' && !f.deleted_at).length + (S.D.fields || []).filter(f => f.approval === 'waiting' && !f.deleted_at).length : 0;
  nav.innerHTML = navItems().map(([r, l, i]) => `<a href="#/${r}" class="${base === r ? 'on' : ''}">${icon(i)}<span>${l}${r === 'approvals' && wait && (can(52) || can(93)) ? `<span class="dot">${wait}</span>` : ''}</span></a>`).join(''); nav.hidden = false;
}
const ROUTES = {
  today: [vToday, () => loadWeather()], farmers: [vFarmers, bindFarmers], farmer: [vFarmer], field: [vField], approvals: [vApprovals], team: [vTeam], person: [vPerson, bindPerson], more: [vMore],
  due: [vDue], fields: [vFieldList], route: [vRoute, bindRoute], map: [vMap, bindMap], live: [vLive, bindLive], exceptions: [vExceptions, bindExceptions], mywork: [vMyWork], reports: [vReports, bindReports],
  tv: [vTV, bindTV], gallery: [vGallery, () => hydratePhotos()], problems: [vProblems], payments: [vPayments], products: [vProducts], harvest: [vHarvest], ledger: [vLedger], bulk: [vBulk, bindBulk],
  access: [vAccess, bindAccess], settings: [vSettings], variety: [vVariety], log: [vLog, bindLog], bin: [vBin, bindBin], overrides: [vOverrides], referrals: [vReferrals, bindReferrals],
  home: [vFarmerHome, () => loadWeather()], ffield: [vFarmerField], fmoney: [vFarmerMoney], fhelp: [vFarmerHelp], fmore: [vFarmerMore]};
function render() {
  if (!S.sess || !S.loaded) return;
  if (!$('#sheet').hidden && location.hash.replace(/^#\/?/, '') !== S.route) closeSheet(); // leaving a screen closes its pop-up
  const h = location.hash.replace(/^#\/?/, ''); S.route = h || prefs().start || 'today';
  if (S.farmer && !h) S.route = 'home';
  const parts = S.route.split('/'); let key = parts[0], arg = parts.slice(1).join('/');
  if (key === 'team' && parts[1] === 'edit') { $('#app').innerHTML = vPersonEdit(parts[2]); bindPersonEdit(parts[2]); drawNav(); return; }
  const farmerOnly = ['home', 'ffield', 'fmoney', 'fhelp', 'fmore'];
  if (S.farmer && !farmerOnly.includes(key)) key = 'home'; if (!S.farmer && farmerOnly.includes(key)) key = 'today';
  const R = ROUTES[key] || ROUTES[S.farmer ? 'home' : 'today'];
  try { $('#app').innerHTML = R[0](arg); } catch (e) { console.error(e); $('#app').innerHTML = hdr('Something went wrong') + `<div class="wrap"><div class="card">${esc(e.message)}<br><button class="btn" onclick="go('')">Go to start</button></div></div>`; }
  if (key !== 'tv') drawNav(); syncBadge(); hydratePhotos();
  const help = (setting('help_videos', {}) || {})[key]; if (help && can(165)) { const t = $('.top'); if (t) t.insertAdjacentHTML('beforeend', `<a class="ib" href="${esc(help)}" target="_blank" rel="noopener" aria-label="${T('Help')}" style="text-decoration:none;display:grid;place-items:center">?</a>`); }
  if (R[1]) try { R[1](arg); } catch (e) { console.error(e); }
  window.scrollTo(0, 0);
}
addEventListener('hashchange', render);
async function start() {
  $('#app').innerHTML = '<div class="boot">Loading your data…</div>';
  try { await loadData(); if (S.me) { await applyFeatureLimits(); await loadExtra(); } }
  catch (e) { if (e.message !== 'Signed out') renderLogin(e.message); return; }
  render(); syncOutbox(); remindDue(); if (S.me) startTracking();
  if (S.me && isOwner() && can(26) && ls.get('spm2_last_backup') !== today() && new Date().getDay() === 1) setTimeout(() => toast('Monday: take a backup from Settings → Data'), 3000);
}
setInterval(() => { if (S.sess && S.loaded && navigator.onLine && document.visibilityState === 'visible' && !$('#sheet').innerHTML) { loadData(true).then(() => S.me && loadExtra(['visits', 'tasks', 'ledger', 'reports'])).then(() => { if (!$('#sheet').innerHTML && !/^(access|settings|team\/edit)/.test(S.route)) { const y = scrollY; render(); scrollTo(0, y); } }).catch(() => {}); } }, 5 * 60 * 1000);
(async function boot() {
  applyPrefs(); if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
  S.sess = ls.get('spm2_sess');
  if (!S.sess) { renderLogin(); demoCheck(); return; }
  try { await loadMe(false); await start(); } catch (e) { if (e.message !== 'Signed out') { if (!navigator.onLine && ls.get('spm2_feat')) { S.feat = new Set(ls.get('spm2_feat')); } renderLogin(e.message); } }
})();
async function demoCheck() { // demo buttons show only while the owner keeps "Demo login" on (feature 47)
  try { const r = await fetch(`${CFG.url}/rest/v1/spm_settings?select=value&key=eq.demo_login`, {headers: {apikey: CFG.key}}); const d = await r.json(); if (d[0] && d[0].value === true && !CFG.demo) { CFG.demo = true; renderLogin(); } } catch (e) {}
}
