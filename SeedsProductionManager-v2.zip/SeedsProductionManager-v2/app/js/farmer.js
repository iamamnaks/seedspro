/* Farmer app (176–200): own fields, work dates, money, complaints, agreement, notices */
'use strict';
async function loadFarmerData() {
  const fid = S.farmer.id; const q = (t, x) => rest(t, x).catch(() => []);
  const [farmers, fields, marks, vevents, varieties, seasons, companies, settings, ledger, harvests, agreements, notices, reports, users, products] = await Promise.all([
    q('spm_farmers', `select=*&id=eq.${fid}`), q('spm_fields', `select=*&farmer_id=eq.${fid}&deleted_at=is.null`), q('spm_event_marks', 'select=*'), q('spm_variety_events', 'select=*&order=sort'), q('spm_varieties', 'select=*'), q('spm_seasons', 'select=*&order=created_at.desc'),
    q('spm_companies', 'select=*'), q('spm_settings', 'select=*'), q('spm_ledger', `select=*&farmer_id=eq.${fid}&order=day`), q('spm_harvests', `select=*&farmer_id=eq.${fid}`), q('spm_agreements', `select=*&farmer_id=eq.${fid}`),
    q('spm_notices', 'select=*&for_farmers=eq.true&order=at.desc&limit=10'), q('spm_reports', `select=*&farmer_id=eq.${fid}&order=at.desc`), q('spm_users', 'select=id,full_name,phone,role'), q('spm_products', 'select=*')]);
  S.farmer = farmers[0] || S.farmer;
  S.D = {farmers: [S.farmer], fields, marks, vevents, varieties, seasons, companies, ledger, harvests, agreements, notices, reports, users, products, settings: Object.fromEntries(settings.map(s => [s.key, s.value]))};
}
const farmerDue = () => allDue(S.D.fields);
function farmerNav() { return [['home', T('Home'), 'home'], ['fmoney', T('Money'), 'money'], ['fhelp', T('Complaint'), 'approvals'], ['fmore', T('More'), 'more']]; }
function vFarmerHome() {
  const f = S.farmer, fl = S.D.fields || [], org = (S.D.users || []).find(u => u.id === f.organizer_id), up = [];
  fl.forEach(x => fieldEvents(x).filter(e => ['overdue', 'today', 'upcoming'].includes(e.state)).slice(0, 3).forEach(e => up.push({...e, field: x})));
  up.sort((a, b) => (a.expected || '9').localeCompare(b.expected || '9'));
  const n = (S.D.notices || [])[0];
  return hdr(`${T('Home')} · ${f.name}`, `${esc(f.code)} · ${esc(f.village)}`, false) + `<div class="wrap">
  ${n && can(192) ? `<div class="banner ok"><b>${esc(n.title)}</b><br>${esc(n.body)}</div>` : ''}
  ${can(179) ? `<div class="card"><h2>Upcoming work<span class="sp"></span>${can(194) ? `<button class="btn sm" onclick="speak(voiceSummary())">🔊 Listen</button>` : ''}</h2>${up.slice(0, 8).map(e => `<div class="it"><div class="main"><b>${esc(e.ev.name)}</b><span>${num(e.field.acres)} ac · ${esc(varietyName(e.field.variety_id))}${e.ev.note ? ' · ' + esc(e.ev.note) : ''}</span></div><div class="side">${e.state === 'overdue' ? `<span class="tag bad">${e.late} days late</span>` : e.state === 'today' ? `<span class="tag warn">${T('Today')}</span>` : dmy(e.expected)}</div></div>`).join('') || '<p class="mut">No work due. Your sowing date may be missing — ask your organizer.</p>'}</div>` : ''}
  ${can(177) ? `<div class="card"><h2>${T('My fields')}</h2>${fl.map(x => `<div class="it" onclick="go('ffield/${x.id}')"><div class="main"><b>${num(x.acres)} ac · ${esc(varietyName(x.variety_id))}</b><span>${x.survey_no ? 'Survey ' + esc(x.survey_no) + ' · ' : ''}${x.sown_on ? 'Sown ' + dmy(x.sown_on) : 'Not sown yet'}</span></div><div class="side">›</div></div>`).join('') || '<p class="mut">No fields yet.</p>'}</div>` : ''}
  ${can(187) && org ? `<div class="card"><h2>Your organizer</h2><p>${esc(org.full_name)}</p>${org.phone ? `<div class="btns"><a class="btn pri" href="tel:${esc(org.phone)}">Call</a><a class="btn" target="_blank" rel="noopener" href="https://wa.me/91${esc(org.phone)}">WhatsApp</a></div><p class="sm mut">${esc(org.phone)}</p>` : ''}</div>` : ''}
  ${can(191) ? `<div class="card" id="wx"><h2>Weather</h2><p class="mut sm">Loading…</p></div>` : ''}</div>`;
}
function voiceSummary() { const d = farmerDue(); return d.length ? d.map(e => `${e.ev.name}, ${e.state === 'overdue' ? e.late + ' days late' : 'due today'}`).join('. ') : 'No work is due today.'; }
function vFarmerField(id) {
  const x = (S.D.fields || []).find(f => f.id === id); if (!x) return hdr('Field') + '<div class="wrap">Not found</div>';
  const adv = setting('crop_advice', {}) || {}; const lv = null;
  return hdr(`${num(x.acres)} ac · ${varietyName(x.variety_id)}`, x.sown_on ? 'Sown ' + dmy(x.sown_on) : '') + `<div class="wrap"><div class="card"><h2>Work on this field</h2>${fieldEvents(x).map(e => `<div class="it"><div class="main"><b>${esc(e.ev.name)}</b><span>${e.expected ? dmy(e.expected) : 'After sowing'}${e.ev.note ? ' · ' + esc(e.ev.note) : ''}</span></div><div class="side">${{done: '<span class="tag ok">Done</span>', skipped: '<span class="tag">Skipped</span>', overdue: `<span class="tag bad">Late</span>`, today: `<span class="tag warn">${T('Today')}</span>`, upcoming: '', nodate: ''}[e.state]}</div></div>`).join('')}</div>
  ${can(190) && Object.keys(adv).length ? `<div class="card"><h2>Crop advice</h2>${Object.entries(adv).map(([k, v]) => `<p><b>${esc(k)}</b><br>${esc(v)}</p>`).join('')}</div>` : ''}
  ${(S.D.harvests || []).filter(h => h.field_id === id).length && can(183) ? `<div class="card"><h2>Harvest</h2>${(S.D.harvests || []).filter(h => h.field_id === id).map(h => `<p>${dmy(h.day)} · ${num(h.weight_kg, 0)} kg · moisture ${num(h.moisture)}%</p>`).join('')}</div>` : ''}
  ${x.lat != null ? `<a class="btn block" target="_blank" rel="noopener" href="${mapsLink(x.lat, x.lng)}">Open in Google Maps</a>` : ''}</div>`;
}
function vFarmerMoney() {
  const led = S.D.ledger || [], hv = S.D.harvests || [], f = S.farmer; const by = k => led.filter(l => l.kind === k && l.status !== 'rejected');
  if (!moneyOn() && !can(185)) return hdr(T('Money'), '', false) + '<div class="wrap"><div class="card mut">Money details are not shown in this app.</div></div>';
  const s = settleCalc(f.id);
  return hdr(T('Money'), '', false) + `<div class="wrap">
  ${can(185) ? `<div class="tiles"><div class="tile"><b>${rs(s.value)}</b><span>Harvest value</span></div><div class="tile"><b>${rs(s.adv + s.inp + s.dd)}</b><span>Advance, inputs, deductions</span></div><div class="tile"><b>${rs(s.paid)}</b><span>Paid to you</span></div><div class="tile ${s.due > 0 ? 'ok' : ''}"><b>${rs(s.due)}</b><span>Balance to receive</span></div></div>` : ''}
  ${can(182) ? `<div class="card"><h2>Advance</h2>${by('advance').map(l => `<div class="sm">${dmy(l.day)} · ${rs(l.amount)} · <span class="tag ${l.status === 'requested' ? 'warn' : 'ok'}">${l.status === 'requested' ? 'waiting' : l.status}</span></div>`).join('') || '<p class="mut sm">None.</p>'}</div>` : ''}
  ${can(181) ? `<div class="card"><h2>Inputs received</h2>${by('input').map(l => `<div class="sm">${dmy(l.day)} · ${num(l.qty)} ${esc(((S.D.products || []).find(p => p.id === l.product_id) || {}).name || '')} · ${rs(l.amount)}</div>`).join('') || '<p class="mut sm">None.</p>'}</div>` : ''}
  ${can(184) ? `<div class="card"><h2>Deductions</h2>${s.lines.filter(l => l.ded || l.rej).map(l => `<div class="sm">${esc(l.h.lot_no)} · ${l.rej ? 'Rejected (quality)' : num(l.ded, 0) + ' kg for moisture ' + num(l.h.moisture) + '%'}</div>`).join('')}${by('deduction').map(l => `<div class="sm">${dmy(l.day)} · ${rs(l.amount)} · ${esc(l.note)}</div>`).join('') || (s.lines.some(l => l.ded || l.rej) ? '' : '<p class="mut sm">None.</p>')}</div>` : ''}
  ${can(186) ? `<div class="card"><h2>Payments</h2>${by('payment').map(l => `<div class="sm">${dmy(l.day)} · ${rs(l.amount)} · <span class="tag ${l.status === 'paid' ? 'ok' : 'warn'}">${l.status === 'paid' ? 'paid' : 'pending'}</span></div>`).join('') || '<p class="mut sm">No payments yet.</p>'}</div>` : ''}
  ${can(198) && f.bank && f.bank.acno ? `<div class="card"><h2>Bank account</h2><p>${esc(f.bank.bank)} · ${esc(f.bank.ifsc)} · ••••${esc(String(f.bank.acno).slice(-4))}</p></div>` : ''}
  <div class="btns">${can(189) ? `<button class="btn" onclick="farmerRequest()">Request advance or inputs</button>` : ''}${can(199) ? `<button class="btn" onclick="statementPDF()">Download statement</button>` : ''}</div></div>`;
}
function farmerRequest() {
  sheet(`<h3>Request</h3><div class="chips" id="fr_k"><button class="chip on" data-v="advance">Advance</button><button class="chip" data-v="input">Inputs</button></div><label class="f">Amount ₹ (or value of inputs)</label><input class="in" id="fr_a" inputmode="decimal"><label class="f">What do you need?</label><input class="in" id="fr_n">
  <div class="btns" style="margin-top:12px"><button class="btn pri" id="fr_s">Send request</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, p => { let k = 'advance'; $$('#fr_k .chip', p).forEach(c => c.onclick = () => { k = c.dataset.v; $$('#fr_k .chip', p).forEach(z => z.classList.toggle('on', z === c)); });
    p.querySelector('#fr_s').onclick = async () => { const a = parseFloat(p.querySelector('#fr_a').value); if (!(a > 0)) return toast('Enter the amount'); try { const r = await save('spm_ledger', {farmer_id: S.farmer.id, season_id: (currentSeason() || {}).id, kind: k, amount: a, note: p.querySelector('#fr_n').value, status: 'requested'}); S.D.ledger.push(r); closeSheet(); toast('Request sent to your organizer'); render(); } catch (e) { toast(e.message); } }; });
}
function statementPDF() {
  const f = S.farmer, s = settleCalc(f.id), led = S.D.ledger || [];
  const w = window.open('', '_blank'); if (!w) return toast('Allow pop-ups to download'); w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Statement ${esc(f.code)}</title><style>body{font:12pt Arial;margin:20mm}td,th{padding:4px 8px;border-bottom:1px solid #ccc;text-align:left}</style></head><body><h2>Statement — ${esc(f.name)} (${esc(f.code)})</h2><p>${esc(f.village)} · ${dmy(today())}</p>
  <table><tr><th>Date</th><th>Entry</th><th>Amount</th><th>Status</th></tr>${led.map(l => `<tr><td>${dmy(l.day)}</td><td>${esc(l.kind)} ${esc(l.note)}</td><td>${rs(l.amount)}</td><td>${esc(l.status)}</td></tr>`).join('')}</table>
  <p>Harvest value ${rs(s.value)} · Advance ${rs(s.adv)} · Inputs ${rs(s.inp)} · Deductions ${rs(s.dd)} · Paid ${rs(s.paid)}<br><b>Balance ${rs(s.due)}</b></p><script>onload=()=>print()<\/script></body></html>`); w.document.close();
}
function vFarmerHelp() {
  const r = S.D.reports || [];
  return hdr(T('Complaint'), '', false) + `<div class="wrap">${can(188) ? `<button class="btn pri block big-btn" onclick="reportForm('${S.farmer.id}', null)">Raise a complaint or problem</button>` : ''}
  ${can(210) ? `<div class="card" style="margin-top:12px"><h2>My complaints</h2>${r.map(x => `<div class="it"><div class="main"><b>${esc(x.kind)} · ${dmy(x.at.slice(0, 10))}</b><span>${esc(x.note)}${x.reply ? '<br><b>Reply:</b> ' + esc(x.reply) : ''}</span></div><div class="side"><span class="tag ${x.status === 'closed' ? 'ok' : 'warn'}">${x.status.replace('_', ' ')}</span></div></div>`).join('') || '<p class="mut">None.</p>'}</div>` : ''}</div>`;
}
function vFarmerMore() {
  const f = S.farmer, ag = (S.D.agreements || []).slice().sort((a, b) => b.made_on.localeCompare(a.made_on));
  return hdr(T('More'), '', false) + `<div class="wrap">
  ${can(178) ? `<div class="card"><h2>My agreement</h2>${ag.map(a => `<div class="it" onclick="farmerAgreement('${a.id}')"><div class="main"><b>${esc(a.no)}</b><span>${dmy(a.made_on)} · ${esc((byId('seasons', a.season_id) || {}).name || '')}</span></div><div class="side">Open ›</div></div>`).join('') || '<p class="mut">Not made yet.</p>'}</div>` : ''}
  ${can(192) ? `<div class="card"><h2>${T('Notices')}</h2>${(S.D.notices || []).map(n => `<p><b>${esc(n.title)}</b> · ${dmy(n.at.slice(0, 10))}<br>${esc(n.body)}</p>`).join('') || '<p class="mut">None.</p>'}</div>` : ''}
  ${can(197) ? `<div class="card"><h2>Past seasons</h2>${Object.entries(groupBy(S.D.fields || [], x => x.season_id)).map(([sid, a]) => `<p>${esc((byId('seasons', sid) || {}).name || 'No season')} · ${num(sum(a, x => x.acres))} ac · ${esc([...new Set(a.map(x => varietyName(x.variety_id)))].join(', '))}</p>`).join('')}</div>` : ''}
  <div class="card"><div class="btns">${can(195) ? '<button class="btn" onclick="referForm(false)">Refer a farmer</button>' : ''}${can(196) ? '<button class="btn" onclick="referForm(true)">I want to grow next season</button>' : ''}${can(200) ? '<button class="btn" onclick="rateOrganizer()">Rate my organizer</button>' : ''}</div></div>
  <div class="card"><h2>My preferences</h2>${prefsForm()}</div>
  <button class="btn bad block" onclick="logout()">${T('Sign out')}</button></div>`;
}
function farmerAgreement(id) { const a = S.D.agreements.find(x => x.id === id); const P = setting('print', {size: 'A4', top: 40, firstTop: 60, bottom: 20, left: 18, right: 18, font: 11}); printAgreement(S.farmer, a, P, setting('agreement_template', DEFAULT_TEMPLATE), setting('agreement_template_local', '')); }
function referForm(self) {
  if (self) return save('spm_referrals', {name: S.farmer.name, mobile: S.farmer.mobile || '-', village: S.farmer.village, next_season: true}).then(() => toast('Thank you — your organizer will call you')).catch(e => toast(e.message));
  sheet(`<h3>Refer a farmer</h3><label class="f">Name</label><input class="in" id="rf_n"><label class="f">Mobile</label><input class="in" id="rf_m" inputmode="numeric" maxlength="10"><label class="f">Village</label><input class="in" id="rf_v">
  <div class="btns" style="margin-top:12px"><button class="btn pri" id="rf_s">Send</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, p => p.querySelector('#rf_s').onclick = async () => { const m = p.querySelector('#rf_m').value.replace(/\D/g, ''); if (!p.querySelector('#rf_n').value.trim() || m.length !== 10) return toast('Enter name and 10-digit mobile'); try { await save('spm_referrals', {name: p.querySelector('#rf_n').value.trim(), mobile: m, village: p.querySelector('#rf_v').value.trim()}); closeSheet(); toast('Thank you'); } catch (e) { toast(e.message); } });
}
function rateOrganizer() {
  sheet(`<h3>Rate your organizer</h3><div class="chips" id="st">${[1, 2, 3, 4, 5].map(n => `<button class="chip" data-v="${n}">${'★'.repeat(n)}</button>`).join('')}</div><label class="f">Comment</label><input class="in" id="st_n"><div class="btns" style="margin-top:12px"><button class="btn pri" id="st_s">Send</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, p => {
    let v = 0; $$('#st .chip', p).forEach(c => c.onclick = () => { v = +c.dataset.v; $$('#st .chip', p).forEach(z => z.classList.toggle('on', z === c)); });
    p.querySelector('#st_s').onclick = async () => { if (!v) return toast('Choose stars'); try { await save('spm_ratings', {stars: v, organizer_id: S.farmer.organizer_id, note: p.querySelector('#st_n').value}); closeSheet(); toast('Thank you'); } catch (e) { toast(e.message); } }; });
}
