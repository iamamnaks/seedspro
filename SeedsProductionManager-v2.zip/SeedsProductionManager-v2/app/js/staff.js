/* Sign-in, Today, Farmers, Fields, crop events, Approvals */
'use strict';

/* ---------- sign-in ---------- */
function renderLogin(msg) {
  $('#nav').hidden = true;
  const demo = CFG.demo ? `<div class="card"><h2>Demo with sample data</h2><p class="mut sm">Tap a role to see what that person can see.</p><div class="chips">${CFG.demoUsers.map(([u, l]) => `<button class="chip" data-demo="${u}">${esc(l)}</button>`).join('')}</div></div>` : '';
  $('#app').innerHTML = `<header class="top"><h1>The Seeds Production Manager<small>Staff and farmer sign-in</small></h1></header>
  <div class="wrap" style="max-width:460px">${demo}<form class="card" id="lf"><h2>${T('Sign in')}</h2>
  <label class="f" for="lu">User ID — or farmer mobile number</label><input class="in" id="lu" autocomplete="username" autocapitalize="none" required>
  <label class="f" for="lp">Password or PIN</label><input class="in" id="lp" type="password" autocomplete="current-password" required>
  <label class="sm" style="display:flex;gap:8px;margin-top:8px"><input type="checkbox" id="lsh"> Show password</label>
  <button class="btn pri block big-btn" style="margin-top:14px">${T('Sign in')}</button><p class="sm" id="le" style="color:var(--bad)">${esc(msg || '')}</p>
  <p class="sm mut">Forgot your password? Ask the company owner to reset it.</p></form></div>`;
  $('#lsh').onchange = e => $('#lp').type = e.target.checked ? 'text' : 'password';
  const doLogin = async (u, p) => { $('#le').textContent = 'Signing in…'; try { await login(u, p); await start(); } catch (e) { $('#le').textContent = e.message === 'Invalid login credentials' ? 'Wrong user ID or password' : e.message; } };
  $('#lf').onsubmit = e => { e.preventDefault(); doLogin($('#lu').value, $('#lp').value); };
  $$('[data-demo]').forEach(b => b.onclick = () => doLogin(b.dataset.demo, CFG.demoPassword));
}

/* ---------- Today ---------- */
function vToday() {
  const me = S.me, F = (S.D.farmers || []).filter(f => !f.deleted_at), FL = (S.D.fields || []).filter(f => !f.deleted_at && f.status === 'active');
  const due = allDue(FL), over = due.filter(d => d.state === 'overdue'), tday = due.filter(d => d.state === 'today');
  const wait = F.filter(f => f.status === 'waiting').length + FL.filter(f => f.approval === 'waiting').length;
  const noLoc = FL.filter(f => f.lat == null).length, notSown = FL.filter(f => !f.sown_on).length;
  const acres = sum(FL, f => f.acres);
  const nv = days => FL.filter(f => { const v = lastVisit(f.id); return !v || daysBetween(v.start_at.slice(0, 10), today()) >= days; }).length;
  const tiles = [
    [F.length, 'Farmers', '', 'farmers'], [num(acres, 1), 'Acres', '', 'farmers'],
    [over.length, T('Overdue'), over.length ? 'bad' : 'ok', 'due/overdue'], [tday.length, T('Due today'), tday.length ? 'warn' : '', 'due/today'],
    ...((can(52) || can(93)) && wait ? [[wait, 'To approve', 'warn', 'approvals']] : []),
    ...(can(56) || can(146) ? [[noLoc, 'Fields without location', noLoc ? 'warn' : '', 'fields/noloc']] : []),
    ...(can(55) ? [[nv(15), 'Not visited 15 days', nv(15) ? 'warn' : '', 'fields/novisit15'], [nv(30), 'Not visited 30 days', nv(30) ? 'bad' : '', 'fields/novisit30']] : []),
    [notSown, 'Waiting for sowing date', '', 'fields/notsown'],
  ];
  const myTasks = (S.D.tasks || []).filter(t => t.assigned_to === me.id && !t.done_at);
  const late2 = F.filter(f => f.status === 'waiting' && daysBetween(f.created_at.slice(0, 10), today()) > 2).length;
  const sowSoon = can(70) ? FL.filter(f => { const h = harvestDue(f); return h && h >= today() && h <= addDays(today(), 15); }).length : 0;
  return hdr(T('Today') + "'s work", `${new Date().toLocaleDateString('en-IN', {weekday: 'long', day: 'numeric', month: 'short'})} · ${ROLE[isAdmin() ? 'admin' : me.role]} · ${esc(me.full_name)}`, false) + `<div class="wrap">
    ${noticeBanner()}${late2 && can(52) ? `<div class="banner warn">${late2} entries have waited more than 2 days for approval.</div>` : ''}
    ${(can(131) && ['sub_organizer', 'field_staff', 'company_assistant'].includes(me.role)) ? attendanceCard() : ''}
    <div class="tiles">${tiles.map(([v, l, c, r]) => `<div class="tile ${c}" onclick="go('${r}')"><b>${v}</b><span>${l}</span></div>`).join('')}${sowSoon ? `<div class="tile" onclick="go('harvest')"><b>${sowSoon}</b><span>Harvest due in 15 days</span></div>` : ''}</div>
    ${myTasks.length ? `<div class="card"><h2>My tasks</h2><div class="list">${myTasks.map(t => `<div class="it" onclick="taskSheet('${t.id}')"><div class="main"><b>${esc(t.title)}</b><span>${t.due ? 'Due ' + dmy(t.due) : ''} ${esc(userName(t.created_by))}</span></div><div class="side">›</div></div>`).join('')}</div></div>` : ''}
    <div class="card"><h2>${T('Overdue')} and ${T('Due today').toLowerCase()} <span class="sp"></span>${can(133) || can(91) ? `<button class="btn sm" onclick="go('route')">Route order</button>` : ''}${can(27) || can(76) || can(104) ? `<button class="btn sm" onclick="exportDue()">Excel</button>` : ''}</h2>${dueList(due.slice(0, 40))}${due.length > 40 ? `<button class="btn block" onclick="go('due/all')">Show all ${due.length}</button>` : ''}</div>
    ${(can(54) || can(31)) && ['owner', 'supervisor', 'organizer', 'viewer'].includes(me.role) ? byOrganizerCard(due) : ''}
    ${can(162) ? `<div class="card" id="wx"><h2>Weather</h2><p class="mut sm">Loading…</p></div>` : ''}
  </div>`;
}
function noticeBanner() { const n = (S.D.notices || []).filter(x => x.for_staff).slice(0, 1)[0]; return n && can(192) ? `<div class="banner ok"><b>${esc(n.title)}</b> ${esc(n.body)}</div>` : ''; }
function dueList(arr) {
  if (!arr.length) return '<p class="mut">Nothing due. Good work.</p>';
  return `<div class="list">${arr.map(d => { const f = farmerOf(d.field) || {}; return `<div class="it" onclick="go('field/${d.field.id}')"><div class="main"><b>${esc(d.ev.name)} · ${num(d.field.acres)} ac</b><span>${esc(f.code)} ${esc(f.name)} · ${esc(f.village)}${f.field_staff_id ? ' · ' + esc(userName(f.field_staff_id)) : ''}</span></div><div class="side">${d.state === 'overdue' ? `<span class="tag bad">${d.late} days late</span>` : '<span class="tag warn">Today</span>'}${d.ev.priority === 'high' ? '<br><span class="tag">High</span>' : ''}</div></div>`; }).join('')}</div>`;
}
function byOrganizerCard(due) {
  const orgs = (S.D.users || []).filter(u => u.role === 'organizer'); if (!orgs.length) return '';
  const rows = orgs.map(o => { const fs = (S.D.farmers || []).filter(f => f.organizer_id === o.id && !f.deleted_at); const ids = new Set(fs.map(f => f.id));
    const fl = (S.D.fields || []).filter(f => ids.has(f.farmer_id) && !f.deleted_at); const ov = due.filter(d => ids.has(d.field.farmer_id) && d.state === 'overdue').length;
    const vis = (S.D.visits || []).filter(v => ids.has(v.farmer_id) && v.start_at.slice(0, 7) === today().slice(0, 7)).length;
    return {o, n: fs.length, ac: sum(fl, f => f.acres), ov, pct: fl.length ? Math.round(100 * ov / Math.max(1, fl.length)) : 0, vis}; }).sort((a, b) => b.ac - a.ac);
  return `<div class="card"><h2>By organizer</h2><div class="tw"><table class="t"><tr><th>Organizer</th><th class="r">Farmers</th><th class="r">Acres</th><th class="r">Overdue</th><th class="r">Visits this month</th></tr>
  ${rows.map(r => `<tr onclick="go('person/${r.o.id}')"><td>${esc(r.o.full_name)}</td><td class="r">${r.n}</td><td class="r">${num(r.ac)}</td><td class="r">${r.ov ? `<span class="tag bad">${r.ov}</span>` : 0}</td><td class="r">${r.vis}</td></tr>`).join('')}</table></div></div>`;
}
function exportDue() {
  const rows = allDue().map(d => { const f = farmerOf(d.field) || {}; return {Event: d.ev.name, Priority: d.ev.priority, Expected: dmy(d.expected), 'Days late': d.late, 'Farmer ID': f.code, Farmer: f.name, Village: f.village, Mobile: f.mobile, Acres: d.field.acres, Variety: varietyName(d.field.variety_id), Organizer: userName(f.organizer_id), 'Field staff': userName(f.field_staff_id)}; });
  exportXlsx('due-events', {Due: rows});
}
function vDue(kind) {
  const d = allDue().filter(x => kind === 'all' || x.state === kind);
  return hdr(kind === 'overdue' ? T('Overdue') : kind === 'today' ? T('Due today') : 'Overdue and due today', d.length + ' events') + `<div class="wrap"><div class="card">${dueList(d)}</div></div>`;
}
function harvestDue(f) { const ev = fieldEvents(f).find(x => /harvest/i.test(x.ev.name)); return ev && !ev.done_on ? ev.expected : null; }
async function loadWeather() {
  const el = $('#wx'); if (!el) return; const fl = (S.D.fields || []).find(f => f.lat != null);
  let lat = fl && fl.lat, lng = fl && fl.lng; if (!lat) { el.remove(); return; }
  try { const r = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max&timezone=Asia%2FKolkata&forecast_days=4`); const w = await r.json();
    el.innerHTML = `<h2>Weather near your fields</h2><div class="tiles">${w.daily.time.map((t, i) => `<div class="tile"><span>${dmy(t).slice(0, 5)}</span><b style="font-size:20px">${Math.round(w.daily.temperature_2m_max[i])}° / ${Math.round(w.daily.temperature_2m_min[i])}°</b><span>${w.daily.precipitation_sum[i]} mm rain · wind ${Math.round(w.daily.wind_speed_10m_max[i])} km/h</span>${w.daily.precipitation_sum[i] > 20 || w.daily.wind_speed_10m_max[i] > 40 ? '<br><span class="tag bad">Alert</span>' : ''}</div>`).join('')}</div><p class="sm mut">Forecast from Open-Meteo.</p>`;
  } catch (e) { el.innerHTML = '<h2>Weather</h2><p class="mut sm">Not available offline.</p>'; }
}

/* ---------- Farmers ---------- */
let FQ = {q: '', org: '', village: '', status: ''};
function visibleFarmers() { const co = can(49) && prefs().company; return (S.D.farmers || []).filter(f => !f.deleted_at && (!co || f.company_id === co)); }
const seasonLocked = x => !isOwner() && (setting('locked_seasons', []) || []).includes(x && x.season_id);
function vFarmers() {
  const orgs = (S.D.users || []).filter(u => u.role === 'organizer');
  const villages = [...new Set(visibleFarmers().map(f => f.village).filter(Boolean))].sort();
  const addBtn = (can(82) || can(112)) && !['viewer', 'supervisor'].includes(S.me.role) ? `<button class="btn pri" onclick="farmerForm()">＋ Add farmer</button>` : '';
  return hdr(T('Farmers'), visibleFarmers().length + ' farmers', false) + `<div class="wrap"><div class="search"><input class="in" id="fq" placeholder="${T('Search')} — ID, name, village or mobile" value="${esc(FQ.q)}" autocomplete="off">
  <div class="chips" style="margin-top:8px">${orgs.length > 1 ? `<select class="in" id="fo" style="width:auto"><option value="">All organizers</option>${orgs.map(o => `<option value="${o.id}" ${FQ.org === o.id ? 'selected' : ''}>${esc(o.full_name)}</option>`).join('')}</select>` : ''}
  ${(can(95) || can(123)) && villages.length > 1 ? `<select class="in" id="fv" style="width:auto"><option value="">All villages</option>${villages.map(v => `<option ${FQ.village === v ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select>` : ''}
  <select class="in" id="fs" style="width:auto"><option value="">Any status</option>${['approved', 'waiting', 'returned', 'rejected'].map(s => `<option ${FQ.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select>
  ${addBtn}${can(27) || can(104) || can(129) || can(76) ? `<button class="btn" onclick="exportFarmers()">Excel</button>` : ''}</div></div><div class="card" id="flist"></div></div>`;
}
function farmerListHTML() {
  const q = FQ.q.toLowerCase();
  const arr = visibleFarmers().filter(f => (!FQ.org || f.organizer_id === FQ.org) && (!FQ.village || f.village === FQ.village) && (!FQ.status || f.status === FQ.status) &&
    (!q || [f.code, f.name, f.village, f.mobile, f.father].some(v => String(v || '').toLowerCase().includes(q))));
  const show = arr.slice(0, 200);
  return show.length ? `<div class="list">${show.map(f => { const fl = fieldsOf(f.id); return `<div class="it" onclick="go('farmer/${f.id}')"><div class="av">${esc(initials(f.name))}</div><div class="main"><b>${esc(f.name)}</b><span>${esc(f.code)} · ${esc(f.village)}${f.mobile ? ' · ' + esc(maskMobile(f.mobile)) : ''}</span></div><div class="side">${num(sum(fl, x => x.acres))} ac<br>${f.status !== 'approved' ? `<span class="tag ${f.status === 'waiting' ? 'warn' : 'bad'}">${f.status}</span>` : ''}</div></div>`; }).join('')}</div>${arr.length > 200 ? `<p class="mut sm">Showing 200 of ${arr.length}. Search to narrow.</p>` : ''}` : '<p class="mut">No farmers match.</p>';
}
function maskMobile(m) { return (can(236) && ['field_staff', 'company_assistant'].includes(S.me && S.me.role)) || (S.me && S.me.role === 'viewer' && can(174)) ? String(m).replace(/\d(?=\d{3})/g, '•') : m; }
function bindFarmers() {
  const draw = () => { $('#flist').innerHTML = farmerListHTML(); };
  $('#fq').oninput = e => { FQ.q = e.target.value; draw(); };
  ['fo', 'fv', 'fs'].forEach(id => { const el = $('#' + id); if (el) el.onchange = e => { FQ[{fo: 'org', fv: 'village', fs: 'status'}[id]] = e.target.value; draw(); }; });
  draw();
}
function exportFarmers() {
  const rows = []; visibleFarmers().forEach(f => { const fl = fieldsOf(f.id); (fl.length ? fl : [{}]).forEach(x => rows.push({'Farmer ID': f.code, Farmer: f.name, Father: f.father, Mobile: maskMobile(f.mobile), Village: f.village, Mandal: f.mandal, District: f.district, State: f.state, Company: companyName(f.company_id), Organizer: userName(f.organizer_id), 'Sub-organizer': userName(f.sub_organizer_id), 'Field staff': userName(f.field_staff_id), Status: f.status, Acres: x.acres, 'Survey no': x.survey_no, Variety: varietyName(x.variety_id), 'Sowing date': dmy(x.sown_on), 'Foundation seed date': dmy(x.fs_delivered_on), Latitude: x.lat, Longitude: x.lng, 'Location link': x.lat ? mapsLink(x.lat, x.lng) : '', 'Field status': x.status})); });
  exportXlsx('farmers-fields', {Fields: rows});
}
function farmerForm(id) {
  const f = id ? byId('farmers', id) : {state: 'Telangana', company_id: (S.me.company_id || (S.D.companies[0] || {}).id)};
  const villages = S.D.villages || [], orgs = (S.D.users || []).filter(u => u.role === 'organizer'), subs = (S.D.users || []).filter(u => u.role === 'sub_organizer'), staff = (S.D.users || []).filter(u => u.role === 'field_staff');
  const sel = (id, arr, v, none = 'None') => `<select class="in" id="${id}"><option value="">${none}</option>${arr.map(u => `<option value="${u.id}" ${v === u.id ? 'selected' : ''}>${esc(u.full_name || u.name)}</option>`).join('')}</select>`;
  const assign = ['owner', 'supervisor'].includes(S.me.role) || (S.me.role === 'organizer');
  sheet(`<h3>${id ? 'Edit farmer' : 'Add farmer'}</h3>
  <label class="f">Farmer name *</label><input class="in" id="ff_name" value="${esc(f.name)}">
  <label class="f">Father's name</label><input class="in" id="ff_father" value="${esc(f.father)}">
  <label class="f">Mobile (10 digits)</label><input class="in" id="ff_mobile" inputmode="numeric" maxlength="10" value="${esc(f.mobile)}"><div class="sm" id="ff_dup" style="color:var(--warn)"></div>
  <label class="f">Village *</label><input class="in" id="ff_village" list="vl" value="${esc(f.village)}"><datalist id="vl">${villages.map(v => `<option value="${esc(v.name)}">`).join('')}</datalist>
  <div class="row"><div><label class="f">Mandal</label><input class="in" id="ff_mandal" value="${esc(f.mandal)}"></div><div><label class="f">District</label><input class="in" id="ff_district" value="${esc(f.district)}"></div></div>
  <label class="f">State</label><select class="in" id="ff_state">${['Telangana', 'Andhra Pradesh', 'Karnataka', 'Maharashtra', 'West Bengal', 'Bihar', 'Assam', 'Jharkhand', 'Odisha', 'Madhya Pradesh', 'Other'].map(s => `<option ${f.state === s ? 'selected' : ''}>${s}</option>`).join('')}</select>
  ${(S.D.companies || []).length > 1 ? `<label class="f">Company</label>${sel('ff_company', S.D.companies, f.company_id, 'Choose')}` : ''}
  ${assign ? `<label class="f">Organizer</label>${sel('ff_org', orgs, f.organizer_id, S.me.role === 'organizer' ? 'Me' : 'No organizer yet')}<label class="f">Sub-organizer</label>${sel('ff_sub', subs, f.sub_organizer_id)}<label class="f">Field staff</label>${sel('ff_staff', staff, f.field_staff_id)}` : ''}
  ${can(82) ? `<label class="f">Photos</label><div class="btns"><button class="btn sm" id="ff_ph">Farmer photo ${f.photo ? '✓' : ''}</button><button class="btn sm" id="ff_idph">ID proof photo ${f.id_photo ? '✓' : ''}</button></div>
  <label class="f">Bank account (for payments)</label><div class="row"><input class="in" id="ff_bname" placeholder="Bank name" value="${esc((f.bank || {}).bank)}"><input class="in" id="ff_ifsc" placeholder="IFSC" value="${esc((f.bank || {}).ifsc)}"></div><input class="in" id="ff_acno" placeholder="Account number" inputmode="numeric" style="margin-top:8px" value="${esc((f.bank || {}).acno)}">` : ''}
  <div class="btns" style="margin-top:14px"><button class="btn pri" id="ff_save">${T('Save')}</button><button class="btn" onclick="closeSheet()">${T('Cancel')}</button></div>`, p => {
    let photo = f.photo || '', idPhoto = f.id_photo || '';
    const ph = (btn, set) => { const b = p.querySelector(btn); if (b) b.onclick = async () => { try { b.textContent = 'Uploading…'; set(await uploadPhoto(await pickPhoto())); b.textContent = '✓ Photo added'; } catch (e) { b.textContent = 'Try again'; toast(e.message); } }; };
    ph('#ff_ph', v => photo = v); ph('#ff_idph', v => idPhoto = v);
    p.querySelector('#ff_mobile').oninput = e => { const m = e.target.value.replace(/\D/g, ''); const d = can(29) && m.length === 10 ? visibleFarmers().find(x => x.mobile === m && x.id !== id) : null; p.querySelector('#ff_dup').textContent = d ? `Same mobile as ${d.code} ${d.name} (${d.village})` : ''; };
    p.querySelector('#ff_save').onclick = async () => {
      const v = k => (p.querySelector('#ff_' + k) || {}).value; const name = v('name').trim(), village = v('village').trim(), mobile = v('mobile').replace(/\D/g, '');
      if (!name) return toast('Enter the farmer name'); if (!village) return toast('Choose the village'); if (mobile && mobile.length !== 10) return toast('Mobile must be 10 digits');
      if (can(29) && !id) { const dup = visibleFarmers().find(x => x.name.toLowerCase() === name.toLowerCase() && x.village.toLowerCase() === village.toLowerCase()); if (dup && !(await ask('Possible duplicate', `${dup.code} ${dup.name} already exists in ${dup.village}. Add anyway?`, 'Add anyway'))) return; }
      const row = {name, father: v('father').trim(), mobile, village, mandal: v('mandal').trim(), district: v('district').trim(), state: v('state')};
      if (p.querySelector('#ff_company')) row.company_id = v('company') || null; else if (!id) row.company_id = f.company_id || null;
      if (assign) { row.organizer_id = v('org') || (S.me.role === 'organizer' ? S.me.id : null); row.sub_organizer_id = v('sub') || null; row.field_staff_id = v('staff') || null; }
      if (can(82)) { row.photo = photo; row.id_photo = idPhoto; const b = {bank: v('bname').trim(), ifsc: v('ifsc').trim().toUpperCase(), acno: v('acno').replace(/\s/g, '')}; if (b.bank || b.acno) row.bank = b; }
      try {
        if (!(S.D.villages || []).some(x => x.name.toLowerCase() === village.toLowerCase())) save('spm_villages', {name: village, mandal: row.mandal, district: row.district, state: row.state}).then(x => x && S.D.villages.push(x)).catch(() => {});
        const r = await save('spm_farmers', row, id ? {id} : {}); closeSheet();
        if (id) Object.assign(byId('farmers', id), r); else S.D.farmers.push(r);
        toast(r.status === 'waiting' ? 'Saved — waiting for approval' : 'Saved'); if (!id && r.id) go('farmer/' + r.id); else render();
      } catch (e) { toast(e.message); }
    };
  });
}
function vFarmer(id) {
  const f = byId('farmers', id); if (!f) return hdr('Farmer') + '<div class="wrap"><div class="card">Farmer not found or removed.</div></div>';
  const fl = fieldsOf(id), canEdit = !['viewer', 'supervisor'].includes(S.me.role);
  const led = (S.D.ledger || []).filter(l => l.farmer_id === id), ag = (S.D.agreements || []).find(a => a.farmer_id === id && a.season_id === (currentSeason() || {}).id);
  const tel = f.mobile && (can(96) || can(120)) ? `<a class="btn sm" href="tel:${esc(f.mobile)}" onclick="logCall('${id}','call')">Call</a><a class="btn sm" target="_blank" rel="noopener" href="https://wa.me/91${esc(f.mobile)}" onclick="logCall('${id}','whatsapp')">WhatsApp</a>` : '';
  return hdr(f.name, `${esc(f.code)} · ${esc(f.village)}`) + `<div class="wrap">
  ${f.status !== 'approved' ? `<div class="banner ${f.status === 'waiting' ? 'warn' : 'bad'}">${f.status === 'waiting' ? 'Waiting for approval' : f.status === 'returned' ? 'Sent back: ' + esc(f.approval_note) : 'Rejected: ' + esc(f.approval_note)}</div>` : ''}
  <div class="card"><h2>Details<span class="sp"></span>${canEdit ? `<button class="btn sm" onclick="farmerForm('${id}')">Edit</button>` : ''}</h2>
   ${f.photo ? photoStrip([f.photo, f.id_photo].filter(Boolean)) : ''}
   <p>${f.father ? 'Father: ' + esc(f.father) + '<br>' : ''}Mobile: ${esc(maskMobile(f.mobile)) || '—'}<br>${esc([f.village, f.mandal, f.district, f.state].filter(Boolean).join(', '))}<br>
   Company: ${esc(companyName(f.company_id)) || '—'}<br>Organizer: ${esc(userName(f.organizer_id)) || '—'}${f.sub_organizer_id ? ' · Sub-organizer: ' + esc(userName(f.sub_organizer_id)) : ''}${f.field_staff_id ? ' · Field staff: ' + esc(userName(f.field_staff_id)) : ''}
   ${f.bank && f.bank.acno && (isOwner() || can(198)) ? `<br>Bank: ${esc(f.bank.bank)} · ${esc(f.bank.ifsc)} · ••••${esc(String(f.bank.acno).slice(-4))}` : ''}</p>
   <div class="btns">${tel}${isOwner() && can(176) ? `<button class="btn sm" onclick="farmerLogin('${id}')">${f.auth_id ? 'Reset farmer PIN' : 'Create farmer login'}</button>` : ''}</div></div>
  <div class="card"><h2>${T('Fields')} (${fl.length}) · ${num(sum(fl, x => x.acres))} ac<span class="sp"></span>${canEdit && (can(83) || can(112)) ? `<button class="btn sm pri" onclick="fieldForm(null,'${id}')">＋ Add field</button>` : ''}</h2>
   ${fl.length ? `<div class="list">${fl.map(x => { const ev = fieldEvents(x), od = ev.filter(e => e.state === 'overdue').length; return `<div class="it" onclick="go('field/${x.id}')"><div class="av">${icon('field', 18)}</div><div class="main"><b>${num(x.acres)} ac · ${esc(varietyName(x.variety_id)) || 'No variety'}</b><span>${x.survey_no ? 'Survey ' + esc(x.survey_no) + ' · ' : ''}${x.sown_on ? 'Sown ' + dmy(x.sown_on) : 'Not sown'}${x.lat == null ? ' · <b style="color:var(--warn)">Location missing</b>' : ''}</span></div><div class="side">${od ? `<span class="tag bad">${od} overdue</span>` : ''}${x.approval !== 'approved' ? `<br><span class="tag warn">${x.approval}</span>` : ''}${x.status !== 'active' ? `<br><span class="tag">${x.status}</span>` : ''}</div></div>`; }).join('')}</div>` : '<p class="mut">No fields yet.</p>'}</div>
  ${can(86) || can(178) ? `<div class="card"><h2>Agreement<span class="sp"></span></h2>${ag ? `<p>No. <b>${esc(ag.no)}</b> · ${dmy(ag.made_on)} ${ag.signature ? '· signed' : ''}</p>` : '<p class="mut">No agreement for this season yet.</p>'}
   <div class="btns">${canEdit ? `<button class="btn sm pri" onclick="agreementMake('${id}')">${ag ? 'Open / print' : 'Make agreement'}</button>` : ag ? `<button class="btn sm" onclick="agreementMake('${id}')">Open</button>` : ''}</div></div>` : ''}
  ${(can(36) || can(100)) && moneyOn() ? `<div class="card"><h2>Money<span class="sp"></span><button class="btn sm" onclick="go('ledger/${id}')">Ledger</button></h2>${ledgerSummary(led)}
   <div class="btns">${can(88) && canEdit ? `<button class="btn sm" onclick="ledgerForm('${id}','advance')">Request advance</button>` : ''}${can(89) && canEdit ? `<button class="btn sm" onclick="ledgerForm('${id}','input')">Issue inputs</button>` : ''}</div></div>` : ''}
  ${can(64) ? commentsCard('farmer', id) : ''}
  ${can(159) ? callLogCard(id) : ''}
  ${can(24) ? `<div class="card"><h2>History<span class="sp"></span><button class="btn sm" onclick="historySheet('spm_farmers','${id}')">Show changes</button></h2></div>` : ''}
  ${canEdit && (isOwner() || S.me.role === 'organizer') ? `<button class="btn bad block" onclick="removeFarmer('${id}')">Remove farmer</button>` : ''}
  </div>`;
}
async function logCall(fid, kind) { if (can(159)) save('spm_calls', {farmer_id: fid, kind}).catch(() => {}); }
function callLogCard(fid) { const c = (S.D.calls || []).filter(x => x.farmer_id === fid).slice(0, 5); return c.length ? `<div class="card"><h2>Calls</h2>${c.map(x => `<div class="sm">${dt(x.at)} · ${esc(x.kind)} · ${esc(userName(x.user_id))}</div>`).join('')}</div>` : ''; }
async function removeFarmer(id) {
  const why = await askText('Remove farmer', 'Why is this farmer being removed?', '', {required: true, ok: 'Remove'}); if (why == null) return;
  try { await save('spm_farmers', {deleted_at: new Date().toISOString(), approval_note: why}, {id}); byId('farmers', id).deleted_at = new Date().toISOString(); toast('Farmer removed — the owner can restore it'); go('farmers'); } catch (e) { toast(e.message); }
}
async function farmerLogin(id) {
  const f = byId('farmers', id); const pin = await askText(f.auth_id ? 'Reset farmer PIN' : 'Create farmer login', `Farmer signs in with mobile ${f.mobile || '(add mobile first)'} and this PIN (6–8 digits)`, '', {mode: 'numeric', required: true});
  if (!pin) return; try { await edge('spm-admin', {action: f.auth_id ? 'farmer_pin' : 'farmer_login', farmer_id: id, password: pin}); toast(f.auth_id ? 'PIN changed' : 'Farmer login created'); f.auth_id = f.auth_id || 'set'; render(); } catch (e) { toast(e.message); }
}

/* ---------- Fields ---------- */
function fieldForm(id, farmerId) {
  const x = id ? byId('fields', id) : {farmer_id: farmerId, season_id: (currentSeason() || {}).id, irrigation: 'Borewell'};
  const vs = (S.D.varieties || []).filter(v => v.active || v.id === x.variety_id), ss = S.D.seasons || [];
  sheet(`<h3>${id ? 'Edit field' : 'Add field'}</h3>
  <div class="row"><div><label class="f">Land size (acres) *</label><input class="in" id="fd_acres" inputmode="decimal" value="${esc(x.acres)}"></div><div><label class="f">Survey number</label><input class="in" id="fd_survey" value="${esc(x.survey_no)}"></div></div>
  <label class="f">Variety</label><select class="in" id="fd_var"><option value="">Choose</option>${vs.map(v => `<option value="${v.id}" ${x.variety_id === v.id ? 'selected' : ''}>${esc(v.name)}</option>`).join('')}</select>
  <label class="f">Season</label><select class="in" id="fd_season">${ss.map(s => `<option value="${s.id}" ${x.season_id === s.id ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select>
  <label class="f">Irrigation</label><div class="chips" id="fd_irr">${['Borewell', 'Canal', 'Tank', 'Rain-fed'].map(i => `<button class="chip ${x.irrigation === i ? 'on' : ''}" data-v="${i}">${i}</button>`).join('')}</div>
  <div class="row"><div><label class="f">Foundation seed delivered on</label><input class="in" type="date" id="fd_fs" value="${esc(x.fs_delivered_on)}"></div><div><label class="f">Sowing date</label><input class="in" type="date" id="fd_sown" max="${today()}" value="${esc(x.sown_on)}"></div></div>
  ${can(98) ? `<label class="f">Expected yield (kg per acre)</label><input class="in" id="fd_exp" inputmode="decimal" value="${esc(x.expected_kg_per_acre)}">` : ''}
  ${can(102) && ['owner', 'organizer', 'sub_organizer'].includes(S.me.role) ? `<label class="f">Assigned to</label><select class="in" id="fd_asg"><option value="">Farmer's field staff</option>${(S.D.users || []).filter(u => ['field_staff', 'company_assistant'].includes(u.role)).map(u => `<option value="${u.id}" ${x.assigned_to === u.id ? 'selected' : ''}>${esc(u.full_name)}</option>`).join('')}</select>` : ''}
  ${id && can(106) ? `<label class="f">Field status</label><select class="in" id="fd_status">${['active', 'failed', 'abandoned', 'ploughed_out', 'not_sown'].map(s => `<option value="${s}" ${x.status === s ? 'selected' : ''}>${s.replace('_', ' ')}</option>`).join('')}</select><input class="in" id="fd_reason" placeholder="Reason if not active" style="margin-top:8px" value="${esc(x.status_reason)}">` : ''}
  <div class="btns" style="margin-top:14px"><button class="btn pri" id="fd_save">${T('Save')}</button><button class="btn" onclick="closeSheet()">${T('Cancel')}</button></div>`, p => {
    let irr = x.irrigation; $$('#fd_irr .chip', p).forEach(c => c.onclick = () => { irr = c.dataset.v; $$('#fd_irr .chip', p).forEach(z => z.classList.toggle('on', z === c)); });
    p.querySelector('#fd_save').onclick = async () => {
      const v = k => (p.querySelector('#fd_' + k) || {}).value; const acres = parseFloat(v('acres'));
      if (!(acres > 0)) return toast('Enter land size in acres'); if (v('sown') && v('sown') > today()) return toast('Sowing date cannot be in the future');
      const row = {acres, survey_no: v('survey').trim(), variety_id: v('var') || null, season_id: v('season') || null, irrigation: irr, fs_delivered_on: v('fs') || null, sown_on: v('sown') || null};
      if (p.querySelector('#fd_exp')) row.expected_kg_per_acre = parseFloat(v('exp')) || null;
      if (p.querySelector('#fd_asg')) row.assigned_to = v('asg') || null;
      if (p.querySelector('#fd_status')) { row.status = v('status'); row.status_reason = v('reason').trim(); if (row.status !== 'active' && !row.status_reason) return toast('Write why the field is not active'); }
      if (!id) row.farmer_id = farmerId;
      try { const r = await save('spm_fields', row, id ? {id} : {}); closeSheet(); if (id) Object.assign(byId('fields', id), r); else S.D.fields.push(r); toast('Field saved'); if (!id && r.id) go('field/' + r.id); else render(); } catch (e) { toast(e.message); }
    };
  });
}
function vField(id) {
  const x = byId('fields', id); if (!x) return hdr('Field') + '<div class="wrap"><div class="card">Field not found.</div></div>';
  const f = farmerOf(x) || {}, ev = fieldEvents(x), canEdit = !['viewer', 'supervisor'].includes(S.me.role) && !seasonLocked(x);
  const vis = (S.D.visits || []).filter(v => v.field_id === id).sort((a, b) => b.start_at.localeCompare(a.start_at));
  const hv = (S.D.harvests || []).filter(h => h.field_id === id);
  const near = x.lat != null && (can(105) || can(33) || can(161)) ? isolationNear(x) : [];
  return hdr(`${num(x.acres)} ac · ${varietyName(x.variety_id) || 'Field'}`, `${esc(f.code)} ${esc(f.name)} · ${esc(f.village)}`) + `<div class="wrap">
  ${x.approval !== 'approved' ? `<div class="banner ${x.approval === 'waiting' ? 'warn' : 'bad'}">${x.approval === 'waiting' ? 'Waiting for approval' : 'Sent back: ' + esc(x.approval_note)}</div>` : ''}
  ${near.length ? `<div class="banner warn">Isolation: ${near.map(n => `${esc((farmerOf(n.f) || {}).name)} ${Math.round(n.d)} m (${esc(varietyName(n.f.variety_id))})`).join(', ')} — closer than ${setting('isolation_m', 200)} m.</div>` : ''}
  <div class="card"><h2>Field<span class="sp"></span>${canEdit ? `<button class="btn sm" onclick="fieldForm('${id}')">Edit</button>` : ''}<button class="btn sm" onclick="go('farmer/${f.id}')">Farmer</button></h2>
   <p>${x.survey_no ? 'Survey ' + esc(x.survey_no) + ' · ' : ''}${esc(x.irrigation)} · Season ${esc((byId('seasons', x.season_id) || {}).name || '—')}<br>Foundation seed: ${dmy(x.fs_delivered_on) || '—'} · Sowing: ${dmy(x.sown_on) || '<b style="color:var(--warn)">missing</b>'}
   ${x.expected_kg_per_acre ? `<br>Expected: ${num(x.expected_kg_per_acre * x.acres, 0)} kg (${num(x.expected_kg_per_acre)} kg/ac)` : ''}${x.status !== 'active' ? `<br><span class="tag bad">${esc(x.status)}</span> ${esc(x.status_reason)}` : ''}</p></div>
  <div class="card"><h2>Location<span class="sp"></span></h2>${x.lat != null ? `<p>${x.lat.toFixed(6)}, ${x.lng.toFixed(6)} · ±${Math.round(x.acc || 0)} m · ${esc(x.loc_source)} ${x.loc_at ? dmy(x.loc_at.slice(0, 10)) : ''}</p>
   <div class="btns"><a class="btn sm" target="_blank" rel="noopener" href="${mapsLink(x.lat, x.lng)}">Open in Google Maps</a>${can(134) ? `<a class="btn sm" target="_blank" rel="noopener" href="${navLink(x.lat, x.lng)}">Navigate</a>` : ''}</div>` : '<p class="mut">Location missing.</p>'}
   ${x.boundary ? `<p class="sm mut">Boundary walked: ${num(polyAcres(x.boundary), 2)} ac measured</p>` : ''}
   <div class="btns" style="margin-top:8px">${canEdit && (can(146) || can(117)) ? `<button class="btn sm pri" onclick="setLocation('${id}')">Use my current location</button><button class="btn sm" onclick="pasteLocation('${id}')">Paste Google Maps link</button>` : ''}${canEdit && can(147) ? `<button class="btn sm" onclick="walkBoundary('${id}')">Walk boundary</button>` : ''}</div></div>
  ${(can(135) || can(92) || can(114)) && canEdit ? `<div class="card"><h2>Field visit</h2>${visitControls(x)}</div>` : ''}
  <div class="card"><h2>Crop events</h2>${ev.length ? `<div class="list">${ev.map(e => `<div class="it" onclick="eventSheet('${id}','${e.ev.id}')"><div class="main"><b>${esc(e.ev.name)}${e.ev.must ? '' : ' <span class="tag">can skip</span>'}</b><span>${e.expected ? 'Expected ' + dmy(e.expected) : 'Waiting for sowing date'}${e.done_on ? ' · Done ' + dmy(e.done_on) : ''}${e.mark && e.mark.note ? ' · ' + esc(e.mark.note) : ''}</span></div><div class="side">${{done: '<span class="tag ok">Done</span>', skipped: '<span class="tag">Skipped</span>', overdue: `<span class="tag bad">${e.late} days late</span>`, today: '<span class="tag warn">Today</span>', upcoming: '', nodate: ''}[e.state]}</div></div>`).join('')}</div>` : '<p class="mut">Choose a variety with crop events.</p>'}</div>
  ${vis.length ? `<div class="card"><h2>Visits (${vis.length})</h2><div class="list">${vis.slice(0, 15).map(v => `<div class="it" onclick="visitSheet('${v.id}')"><div class="main"><b>${dt(v.start_at)} · ${esc(userName(v.user_id))}</b><span>${esc(v.stage)} ${esc(v.condition)} ${v.minutes ? '· ' + Math.round(v.minutes) + ' min' : ''}</span></div><div class="side">${v.inside === false ? '<span class="tag bad">Outside field</span>' : v.inside ? '<span class="tag ok">At field</span>' : ''}${(v.flags || []).length ? `<br><span class="tag warn">${esc(v.flags.join(', '))}</span>` : ''}</div></div>`).join('')}</div></div>` : ''}
  ${(can(99) || can(38) || can(127)) ? `<div class="card"><h2>Harvest<span class="sp"></span>${canEdit ? `<button class="btn sm" onclick="harvestForm('${id}')">＋ Harvest entry</button>` : ''}</h2>${hv.length ? `<table class="t"><tr><th>Date</th><th class="r">Weight kg</th><th class="r">Moisture %</th><th>Lot</th></tr>${hv.map(h => `<tr><td>${dmy(h.day)}</td><td class="r">${num(h.weight_kg, 0)}</td><td class="r">${num(h.moisture)}</td><td>${esc(h.lot_no)}</td></tr>`).join('')}</table>` : '<p class="mut">No harvest yet.</p>'}</div>` : ''}
  ${can(108) || can(126) || can(144) ? `<button class="btn block" onclick="reportForm('${f.id}','${id}')">Report disease / pest / problem</button>` : ''}
  ${can(64) ? commentsCard('field', id) : ''}
  </div>`;
}
function isolationNear(x) {
  const lim = setting('isolation_m', 200); return (S.D.fields || []).filter(o => o.id !== x.id && o.lat != null && !o.deleted_at && o.variety_id !== x.variety_id).map(o => ({f: o, d: haversine(x.lat, x.lng, o.lat, o.lng)})).filter(o => o.d < lim).sort((a, b) => a.d - b.d).slice(0, 5);
}
async function setLocation(id) {
  try { const fx = await gpsDialog('Field location'); if (fx.mock && !(await ask('Location looks suspicious', 'The readings look like a fake-GPS app. Save anyway?', 'Save anyway'))) return;
    if (fx.weak && !(await ask('Weak location', `Best accuracy was ±${Math.round(fx.acc)} m. Save it anyway?`, 'Save'))) return;
    const r = await save('spm_fields', {lat: fx.lat, lng: fx.lng, acc: fx.acc, loc_source: `GPS average of ${fx.n}`, loc_at: new Date().toISOString()}, {id}); Object.assign(byId('fields', id), r);
    const near = isolationNear(byId('fields', id)); toast(near.length ? `Saved. Warning: another variety ${Math.round(near[0].d)} m away` : `Location saved ±${Math.round(fx.acc)} m`); render();
  } catch (e) { toast(e.message); }
}
async function pasteLocation(id) {
  const s = await askText('Paste location', 'Google Maps link, Plus Code or "lat, lng"', '', {required: true, ok: 'Read location'}); if (!s) return;
  try { let m = s.match(/(-?\d{1,2}\.\d+)\s*,\s*(-?\d{1,3}\.\d+)/); let src = 'Typed';
    if (!m && /goo\.gl|google\./.test(s)) { const d = await edge('spm-resolve', {url: s}); m = d.url.match(/(-?\d{1,2}\.\d+)[,+\s]+(-?\d{1,3}\.\d+)/); src = 'Google Maps link'; }
    if (!m) throw new Error('Could not read a location from that');
    const lat = +m[1], lng = +m[2]; if (Math.abs(lat) > 90 || Math.abs(lng) > 180) throw new Error('That location is not valid');
    const r = await save('spm_fields', {lat, lng, acc: null, loc_source: src, loc_at: new Date().toISOString()}, {id}); Object.assign(byId('fields', id), r); toast('Location saved'); render();
  } catch (e) { toast(e.message); }
}
function polyAcres(pts) { if (!pts || pts.length < 3) return 0; const R = 6378137, r = x => x * Math.PI / 180; let a = 0; for (let i = 0; i < pts.length; i++) { const [la1, ln1] = pts[i], [la2, ln2] = pts[(i + 1) % pts.length]; a += r(ln2 - ln1) * (2 + Math.sin(r(la1)) + Math.sin(r(la2))); } return Math.abs(a * R * R / 2) / 4046.86; }
function walkBoundary(id) {
  const pts = []; let w = null;
  sheet(`<h3>Walk the field boundary</h3><p class="mut sm">Walk along the edge of the field. A point is added every few metres. Tap Finish when you are back at the start.</p><p class="b" id="wb">0 points</p>
  <div class="btns"><button class="btn pri" id="wbf">Finish</button><button class="btn" id="wbc">Cancel</button></div>`, p => {
    w = navigator.geolocation.watchPosition(pos => { const c = pos.coords; if (c.accuracy > 25) return; const l = pts[pts.length - 1]; if (!l || haversine(l[0], l[1], c.latitude, c.longitude) > 4) pts.push([c.latitude, c.longitude]); $('#wb').textContent = `${pts.length} points · ${num(polyAcres(pts), 2)} ac so far`; }, () => {}, {enableHighAccuracy: true});
    p.querySelector('#wbc').onclick = () => { navigator.geolocation.clearWatch(w); closeSheet(); };
    p.querySelector('#wbf').onclick = async () => { navigator.geolocation.clearWatch(w); if (pts.length < 4) return toast('Too few points — walk the whole edge'); closeSheet();
      try { const r = await save('spm_fields', {boundary: pts}, {id}); Object.assign(byId('fields', id), r); toast(`Boundary saved: ${num(polyAcres(pts), 2)} acres`); render(); } catch (e) { toast(e.message); } };
  });
}
function eventSheet(fieldId, evId) {
  const x = byId('fields', fieldId), e = fieldEvents(x).find(z => z.ev.id === evId); const canEdit = !['viewer', 'supervisor'].includes(S.me.role) && !seasonLocked(x) && (can(113) || can(137) || can(81));
  sheet(`<h3>${esc(e.ev.name)}</h3><p class="mut">${e.expected ? 'Expected ' + dmy(e.expected) : 'Needs sowing date'} · ${esc(e.ev.priority)} priority${e.ev.note ? '<br>' + esc(e.ev.note) : ''}</p>
  ${e.mark ? `<p>${e.mark.skipped ? 'Skipped' : 'Done on ' + dmy(e.mark.done_on)} · ${esc(userName(e.mark.by_user))}${e.mark.note ? '<br>' + esc(e.mark.note) : ''}</p>` : ''}
  ${canEdit ? (e.mark ? `<button class="btn bad" id="ev_undo">Undo</button>` : `<label class="f">Done on</label><input class="in" type="date" id="ev_day" max="${today()}" value="${today()}"><label class="f">Note</label><input class="in" id="ev_note">
   ${can(137) ? `<button class="btn sm" id="ev_ph" style="margin-top:8px">Add photo</button>` : ''}
   <div class="btns" style="margin-top:12px"><button class="btn pri" id="ev_done">${T('Mark done')}</button>${!e.ev.must || can(138) ? `<button class="btn" id="ev_skip">Skip</button>` : ''}</div>`) : ''}
  <div class="btns" style="margin-top:10px"><button class="btn" onclick="closeSheet()">Close</button>${(can(97) || can(43)) && !e.mark && (farmerOf(x) || {}).mobile ? `<a class="btn" target="_blank" rel="noopener" href="https://wa.me/91${esc(farmerOf(x).mobile)}?text=${encodeURIComponent(setting('msg_template', 'Namaste {{farmer}}, {{event}} is due on {{date}} in your seed field. — {{company}}').replace('{{farmer}}', farmerOf(x).name).replace('{{event}}', e.ev.name).replace('{{date}}', dmy(e.expected)).replace('{{company}}', companyName(farmerOf(x).company_id)))}">Remind farmer (WhatsApp)</a>` : ''}${can(64) ? `<button class="btn" onclick="closeSheet();commentSheet('event','${e.mark ? e.mark.id : evId}')">Comment</button>` : ''}</div>`, p => {
    let photo = ''; const ph = p.querySelector('#ev_ph'); if (ph) ph.onclick = async () => { try { ph.textContent = 'Getting location…'; let fx = null; try { fx = await gpsFix({maxMs: 15000, need: 50}); } catch (_) {} ph.textContent = 'Uploading…'; photo = await uploadPhoto(await pickPhoto(fx)); ph.textContent = '✓ Photo added'; } catch (err) { ph.textContent = 'Add photo'; toast(err.message); } };
    const mk = async skipped => { const note = (p.querySelector('#ev_note') || {}).value || ''; if (skipped && !note.trim()) return toast('Write why it is skipped');
      try { const r = await save('spm_event_marks', {field_id: fieldId, variety_event_id: evId, done_on: skipped ? null : p.querySelector('#ev_day').value, skipped, note: note + (photo ? ` [photo:${photo}]` : '')}); S.D.marks.push(r); closeSheet(); toast(skipped ? 'Skipped' : 'Marked done'); render(); } catch (err) { toast(err.message); } };
    const d = p.querySelector('#ev_done'); if (d) d.onclick = () => mk(false); const s = p.querySelector('#ev_skip'); if (s) s.onclick = () => mk(true);
    const u = p.querySelector('#ev_undo'); if (u) u.onclick = async () => { try { await api(`/rest/v1/spm_event_marks?id=eq.${e.mark.id}`, {method: 'DELETE'}); S.D.marks = S.D.marks.filter(m => m.id !== e.mark.id); closeSheet(); toast('Undone'); render(); } catch (err) { toast(err.message); } };
  });
}

/* ---------- comments & history ---------- */
function commentsCard(entity, id) { const c = (S.D.comments || []).filter(x => x.entity === entity && x.entity_id === id); return `<div class="card"><h2>Comments<span class="sp"></span><button class="btn sm" onclick="commentSheet('${entity}','${id}')">＋ Comment</button></h2>${c.map(x => `<p class="sm"><b>${esc(userName(x.by_user))}</b> · ${dt(x.at)}<br>${esc(x.body)}</p>`).join('') || '<p class="mut sm">No comments.</p>'}</div>`; }
async function commentSheet(entity, id) { const b = await askText('Comment', 'Write a comment', '', {long: true, required: true}); if (!b) return; try { const r = await save('spm_comments', {entity, entity_id: id, body: b}); (S.D.comments = S.D.comments || []).unshift(r); toast('Comment added'); render(); } catch (e) { toast(e.message); } }
async function historySheet(tbl, id) {
  sheet('<h3>Change history</h3><p class="mut">Loading…</p>'); try { const rows = await rest('spm_audit', `select=*&tbl=eq.${tbl}&row_id=eq.${id}&order=at.desc&limit=50`);
    const diff = r => { if (!r.old || !r.new) return r.action; return Object.keys(r.new).filter(k => !['updated_at'].includes(k) && JSON.stringify(r.old[k]) !== JSON.stringify(r.new[k])).map(k => `${k}: ${esc(String(r.old[k] ?? '—')).slice(0, 40)} → ${esc(String(r.new[k] ?? '—')).slice(0, 40)}`).join('<br>'); };
    sheet(`<h3>Change history</h3>${rows.map(r => `<p class="sm"><b>${dt(r.at)}</b> · ${esc(userName(r.actor) || 'System')}<br>${diff(r)}</p>`).join('') || '<p class="mut">No changes recorded.</p>'}<button class="btn" onclick="closeSheet()">Close</button>`);
  } catch (e) { toast(e.message); closeSheet(); }
}

/* ---------- Approvals ---------- */
function vApprovals() {
  const fw = visibleFarmers().filter(f => f.status === 'waiting'), flw = (S.D.fields || []).filter(f => !f.deleted_at && f.approval === 'waiting');
  const money = (S.D.ledger || []).filter(l => l.status === 'requested'), exp = (S.D.expenses || []).filter(e => e.status === 'waiting' && e.user_id !== S.me.id), lv = (S.D.leaves || []).filter(e => e.status === 'waiting' && e.user_id !== S.me.id);
  const mine = visibleFarmers().filter(f => f.status === 'returned' && f.created_by === S.me.id).concat((S.D.fields || []).filter(f => f.approval === 'returned' && f.created_by === S.me.id).map(f => ({...farmerOf(f), _field: f})));
  const card = (t, arr, fn) => arr.length ? `<div class="card"><h2>${t} (${arr.length})</h2><div class="list">${arr.map(fn).join('')}</div></div>` : '';
  const btns = (kind, id) => `<div class="btns" style="margin-top:6px"><button class="btn sm okb" onclick="event.stopPropagation();decide('${kind}','${id}','approved')">Approve</button><button class="btn sm" onclick="event.stopPropagation();decide('${kind}','${id}','returned')">Send back</button><button class="btn sm bad" onclick="event.stopPropagation();decide('${kind}','${id}','rejected')">Reject</button></div>`;
  return hdr(T('Approvals'), '', false) + `<div class="wrap">
  ${card('Sent back to you to fix', mine, f => `<div class="it" onclick="go('${f._field ? 'field/' + f._field.id : 'farmer/' + f.id}')"><div class="main"><b>${esc(f.name)}${f._field ? ' · field' : ''}</b><span>${esc((f._field || f).approval_note)}</span></div><div class="side">›</div></div>`)}
  ${can(52) || can(93) ? card('New / changed farmers', fw, f => `<div class="it" onclick="go('farmer/${f.id}')"><div class="main"><b>${esc(f.code)} ${esc(f.name)}</b><span>${esc(f.village)} · entered by ${esc(userName(f.created_by))} · ${dmy(f.created_at.slice(0, 10))}</span>${btns('farmer', f.id)}</div></div>`) : ''}
  ${can(52) || can(93) ? card('Fields', flw, x => { const f = farmerOf(x) || {}; return `<div class="it" onclick="go('field/${x.id}')"><div class="main"><b>${num(x.acres)} ac · ${esc(f.name)}</b><span>${esc(f.village)} · ${esc(varietyName(x.variety_id))} · by ${esc(userName(x.created_by))}</span>${btns('field', x.id)}</div></div>`; }) : ''}
  ${(can(68) || can(69)) && moneyOn() ? card('Advance and input requests', money, l => { const f = byId('farmers', l.farmer_id) || {}; return `<div class="it"><div class="main"><b>${esc(l.kind)} · ${rs(l.amount)} · ${esc(f.name)}</b><span>${esc(l.note)} · ${esc(userName(l.by_user) || 'Farmer request')} · ${dmy(l.day)}</span><div class="btns" style="margin-top:6px"><button class="btn sm okb" onclick="moneyDecide('${l.id}','approved')">Approve</button><button class="btn sm bad" onclick="moneyDecide('${l.id}','rejected')">Reject</button></div></div></div>`; }) : ''}
  ${card('Expenses', exp, e => `<div class="it"><div class="main"><b>${esc(userName(e.user_id))} · ${rs(e.amount)} · ${esc(e.kind)}</b><span>${dmy(e.day)} ${esc(e.note)}</span>${e.photo ? photoStrip([e.photo]) : ''}<div class="btns" style="margin-top:6px"><button class="btn sm okb" onclick="staffDecide('expense','${e.id}','approved')">Approve</button><button class="btn sm bad" onclick="staffDecide('expense','${e.id}','rejected')">Reject</button></div></div></div>`)}
  ${card('Leave requests', lv, e => `<div class="it"><div class="main"><b>${esc(userName(e.user_id))} · ${dmy(e.from_day)} – ${dmy(e.to_day)}</b><span>${esc(e.reason)}</span><div class="btns" style="margin-top:6px"><button class="btn sm okb" onclick="staffDecide('leave','${e.id}','approved')">Approve</button><button class="btn sm bad" onclick="staffDecide('leave','${e.id}','rejected')">Reject</button></div></div></div>`)}
  ${!fw.length && !flw.length && !money.length && !exp.length && !lv.length && !mine.length ? '<div class="card mut">Nothing waiting.</div>' : ''}</div>`;
}
async function decide(kind, id, decision) {
  let note = ''; if (decision !== 'approved') { note = await askText(decision === 'returned' ? 'Send back' : 'Reject', 'Write why', '', {required: true}); if (!note) return; }
  try { await rpc('spm_decide', {p_kind: kind, p_id: id, p_decision: decision, p_note: note}); const o = byId(kind === 'farmer' ? 'farmers' : 'fields', id); if (kind === 'farmer') { o.status = decision; o.approval_note = note; } else { o.approval = decision; o.approval_note = note; } toast({approved: 'Approved', returned: 'Sent back', rejected: 'Rejected'}[decision]); render(); } catch (e) { toast(e.message); }
}
async function staffDecide(kind, id, st) { try { await rpc('spm_staff_decide', {p_kind: kind, p_id: id, p_status: st}); const arr = S.D[kind === 'expense' ? 'expenses' : 'leaves']; arr.find(x => x.id === id).status = st; toast(st === 'approved' ? 'Approved' : 'Rejected'); render(); } catch (e) { toast(e.message); } }

/* ---------- field lists (no location, not visited, not sown) ---------- */
function vFieldList(kind) {
  const FL = (S.D.fields || []).filter(f => !f.deleted_at && f.status === 'active');
  const map = {noloc: ['Fields without location', f => f.lat == null], notsown: ['Waiting for sowing date', f => !f.sown_on],
    novisit15: ['Not visited in 15 days', f => { const v = lastVisit(f.id); return !v || daysBetween(v.start_at.slice(0, 10), today()) >= 15; }],
    novisit30: ['Not visited in 30 days', f => { const v = lastVisit(f.id); return !v || daysBetween(v.start_at.slice(0, 10), today()) >= 30; }]};
  const [t, fn] = map[kind] || map.noloc; const arr = FL.filter(fn);
  return hdr(t, arr.length + ' fields') + `<div class="wrap"><div class="card">${arr.length ? `<div class="list">${arr.slice(0, 300).map(x => { const f = farmerOf(x) || {}, v = lastVisit(x.id); return `<div class="it" onclick="go('field/${x.id}')"><div class="main"><b>${esc(f.name)} · ${num(x.acres)} ac</b><span>${esc(f.code)} · ${esc(f.village)} · ${esc(userName(f.field_staff_id) || userName(f.organizer_id))}</span></div><div class="side">${v ? 'Last visit ' + dmy(v.start_at.slice(0, 10)) : 'Never visited'}</div></div>`; }).join('')}</div>` : '<p class="mut">None.</p>'}</div></div>`;
}
