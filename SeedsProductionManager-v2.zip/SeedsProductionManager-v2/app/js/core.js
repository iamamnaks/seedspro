/* The Seeds Production Manager v2 — core: data access, sign-in, offline queue, feature switches, UI helpers */
'use strict';
const CFG = {
  url: 'https://hyxgkbypdntrkttfgtbp.supabase.co',
  key: 'sb_publishable_RZRsmFxLv9tMypM-cysLHA_zhmuv5R5',
  staffDomain: 'staff.cropline.in', farmerDomain: 'farmer.cropline.in',
  demo: false,           // one-tap demo logins on the sign-in screen (switch off for real use)
  demoPassword: 'demo',
  demoUsers: [['test.supervisor','Supervisor'],['test.org1','Organizer · Ravi'],['test.org2','Organizer · Lakshmi'],['test.sub1','Sub-organizer · Mahesh'],['test.staff1','Field assistant · Suresh'],['test.staff2','Field assistant · Naveen'],['test.staff3','Field assistant · Anil'],['test.viewer','Observer · Office TV']],
};
const ROLE = {admin:'Admin',owner:'Owner',supervisor:'Supervisor',viewer:'Observer',organizer:'Organizer',sub_organizer:'Sub-organizer',field_staff:'Field assistant',company_assistant:'Company assistant',farmer:'Farmer'};
const ROLE_ORDER = ['admin','owner','viewer','organizer','sub_organizer','field_staff','company_assistant','farmer'];
const FEATURE_PARENT = {owner:'admin',viewer:'owner',organizer:'owner',sub_organizer:'organizer',field_staff:'sub_organizer',company_assistant:'field_staff',farmer:'company_assistant'};

const S = { sess: null, me: null, farmer: null, feat: new Set(), D: {}, online: navigator.onLine, route: '', loaded: false };
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ls = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { v === undefined ? localStorage.removeItem(k) : localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} } };
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); }));
const deviceId = (() => { let d = ls.get('spm_device'); if (!d) { d = uid(); ls.set('spm_device', d); } return d; })();

/* ---------- dates & numbers ---------- */
const pad = n => String(n).padStart(2, '0');
const isoDay = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const today = () => isoDay(new Date());
const addDays = (s, n) => { const d = new Date(s + 'T00:00:00'); d.setDate(d.getDate() + n); return isoDay(d); };
const daysBetween = (a, b) => Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 864e5);
const dmy = s => { if (!s) return ''; const [y, m, d] = String(s).slice(0, 10).split('-'); return `${d}/${m}/${y}`; };
const tm = s => s ? new Date(s).toLocaleTimeString('en-IN', {hour: '2-digit', minute: '2-digit'}) : '';
const dt = s => s ? dmy(isoDay(new Date(s))) + ' ' + tm(s) : '';
const num = (v, d = 1) => (v == null || v === '' || isNaN(v)) ? '—' : Number(v).toLocaleString('en-IN', {maximumFractionDigits: d});
const rs = v => '₹' + Number(v || 0).toLocaleString('en-IN', {maximumFractionDigits: 0});
const initials = n => String(n || '?').trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase();
const sum = (a, f) => a.reduce((s, x) => s + (Number(f(x)) || 0), 0);
const groupBy = (a, f) => a.reduce((m, x) => { const k = f(x); (m[k] = m[k] || []).push(x); return m; }, {});

/* ---------- toast / sheet / dialogs ---------- */
let toastT;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2600); }
function sheet(html, mount) {
  const s = $('#sheet'); s.innerHTML = `<div class="pane" role="dialog" aria-modal="true">${html}</div>`; s.hidden = false;
  s.onclick = e => { if (e.target === s) closeSheet(); };
  const first = s.querySelector('input,select,textarea,button'); if (first && first.tagName !== 'BUTTON') setTimeout(() => first.focus(), 50);
  if (mount) mount(s.firstElementChild);
  return s.firstElementChild;
}
function closeSheet() { const s = $('#sheet'); s.hidden = true; s.innerHTML = ''; }
function ask(title, msg, ok = 'Yes', danger = false) {
  return new Promise(res => sheet(`<h3>${esc(title)}</h3><p class="mut">${esc(msg)}</p><div class="btns"><button class="btn ${danger ? 'bad' : 'pri'}" data-ok>${esc(ok)}</button><button class="btn" data-no>Cancel</button></div>`,
    p => { p.querySelector('[data-ok]').onclick = () => { closeSheet(); res(true); }; p.querySelector('[data-no]').onclick = () => { closeSheet(); res(false); }; }));
}
function askText(title, label, val = '', opt = {}) {
  return new Promise(res => sheet(`<h3>${esc(title)}</h3><label class="f">${esc(label)}</label>${opt.long ? `<textarea class="in" id="ask_v">${esc(val)}</textarea>` : `<input class="in" id="ask_v" value="${esc(val)}" ${opt.type ? `type="${opt.type}"` : ''} ${opt.mode ? `inputmode="${opt.mode}"` : ''}>`}
    <div class="btns" style="margin-top:12px"><button class="btn pri" data-ok>${esc(opt.ok || 'Save')}</button><button class="btn" data-no>Cancel</button></div>`,
    p => { const v = p.querySelector('#ask_v'); p.querySelector('[data-ok]').onclick = () => { if (opt.required && !v.value.trim()) { v.focus(); return; } closeSheet(); res(v.value.trim()); }; p.querySelector('[data-no]').onclick = () => { closeSheet(); res(null); }; }));
}

/* ---------- server access ---------- */
async function rawAuth(path, body) {
  const r = await fetch(CFG.url + '/auth/v1/' + path, {method: 'POST', headers: {apikey: CFG.key, 'Content-Type': 'application/json'}, body: JSON.stringify(body)});
  const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error_description || d.msg || d.message || 'Sign-in failed'); return d;
}
async function token() {
  if (!S.sess) return null;
  if (S.sess.expires_at && S.sess.expires_at * 1000 < Date.now() + 60000 && navigator.onLine) {
    try { S.sess = await rawAuth('token?grant_type=refresh_token', {refresh_token: S.sess.refresh_token}); ls.set('spm2_sess', S.sess); }
    catch (e) { logout('Please sign in again'); throw new Error('Signed out'); }
  }
  return S.sess.access_token;
}
async function api(path, opt = {}) {
  const t = await token();
  const headers = {apikey: CFG.key, Authorization: 'Bearer ' + (t || CFG.key), 'Content-Type': 'application/json', ...(opt.headers || {})};
  if (opt.prefer) headers.Prefer = opt.prefer;
  const r = await fetch(CFG.url + path, {method: opt.method || 'GET', headers, body: opt.body !== undefined ? JSON.stringify(opt.body) : undefined});
  if (r.status === 401) { logout('Please sign in again'); throw new Error('Signed out'); }
  const txt = await r.text(); let d = null; try { d = txt ? JSON.parse(txt) : null; } catch (e) { d = txt; }
  if (!r.ok) throw new Error(friendly((d && (d.message || d.error || d.hint)) || 'Error ' + r.status));
  return d;
}
function friendly(m) {
  m = String(m);
  if (/row-level security|permission denied|violates row/i.test(m)) return 'You do not have permission for this';
  if (/duplicate key/i.test(m)) return 'This already exists';
  if (/Failed to fetch|NetworkError/i.test(m)) return 'No network';
  return m;
}
const rest = (t, q = '') => api(`/rest/v1/${t}${q ? '?' + q : ''}`);
async function restAll(t, q = '') { // pages past the 1000-row limit
  const out = []; for (let from = 0; ; from += 1000) {
    const tk = await token();
    const r = await fetch(`${CFG.url}/rest/v1/${t}?${q}`, {headers: {apikey: CFG.key, Authorization: 'Bearer ' + tk, Range: `${from}-${from + 999}`, 'Range-Unit': 'items'}});
    if (r.status === 401) { logout('Please sign in again'); throw new Error('Signed out'); }
    if (!r.ok && r.status !== 206) { const d = await r.json().catch(() => ({})); throw new Error(friendly(d.message || 'Error ' + r.status)); }
    const d = await r.json(); out.push(...d); if (d.length < 1000) break;
  } return out;
}
const rpc = (fn, args) => api(`/rest/v1/rpc/${fn}`, {method: 'POST', body: args});
async function edge(fn, body) {
  const t = await token(); const r = await fetch(`${CFG.url}/functions/v1/${fn}`, {method: 'POST', headers: {apikey: CFG.key, Authorization: 'Bearer ' + t, 'Content-Type': 'application/json'}, body: JSON.stringify(body)});
  const d = await r.json().catch(() => ({})); if (!r.ok || d.error) throw new Error(d.error || 'Server error'); return d;
}

/* ---------- writes with offline queue ---------- */
const OUTBOX = 'spm2_outbox';
async function save(table, row, opt = {}) {
  // opt.id → PATCH that id; otherwise insert. Returns the saved row (or the local copy when offline).
  const job = {id: uid(), table, row, key: opt.id || null, at: Date.now()};
  if (!navigator.onLine && opt.offline !== false) { const q = ls.get(OUTBOX, []); q.push(job); ls.set(OUTBOX, q); syncBadge(); toast('Saved on this phone — will send when online'); return {...row, id: opt.id || row.id, _queued: true}; }
  return sendJob(job);
}
async function sendJob(job) {
  if (job.key) { const d = await api(`/rest/v1/${job.table}?id=eq.${job.key}`, {method: 'PATCH', body: job.row, prefer: 'return=representation'}); if (!d || !d.length) throw new Error('Not saved — you may not have permission'); return d[0]; }
  const d = await api(`/rest/v1/${job.table}`, {method: 'POST', body: job.row, prefer: 'return=representation'}); return d && d[0];
}
let syncing = false;
async function syncOutbox() {
  if (syncing || !navigator.onLine || !S.sess) return; syncing = true;
  let q = ls.get(OUTBOX, []), sent = 0, failed = [];
  for (const job of q) { try { await sendJob(job); sent++; } catch (e) { if (/No network/.test(e.message)) { failed.push(job); } else { job.error = e.message; failed.push(job); } } }
  ls.set(OUTBOX, failed); syncing = false; syncBadge();
  if (sent) { toast(`${sent} saved entr${sent === 1 ? 'y' : 'ies'} sent`); await loadData(true); render(); }
}
function syncBadge() { const n = ls.get(OUTBOX, []).length; const b = $('#syncb'); if (b) b.textContent = n ? `${n} waiting to send` : (navigator.onLine ? '' : 'Offline'); }
addEventListener('online', () => { S.online = true; syncOutbox(); syncBadge(); });
addEventListener('offline', () => { S.online = false; syncBadge(); });

/* ---------- sign-in ---------- */
async function login(user, pass) {
  user = user.trim().toLowerCase();
  const email = user.includes('@') ? user : /^\d{10}$/.test(user) ? `${user}@${CFG.farmerDomain}` : `${user}@${CFG.staffDomain}`;
  S.sess = await rawAuth('token?grant_type=password', {email, password: pass});
  ls.set('spm2_sess', S.sess);
  await loadMe(true);
}
async function loadMe(fresh) {
  const id = S.sess.user.id;
  const u = await rest('spm_users', `select=*&auth_id=eq.${id}`);
  S.me = u[0] || null; S.farmer = null;
  if (!S.me) { const f = await rest('spm_farmers', `select=*&auth_id=eq.${id}`); S.farmer = f[0] || null; if (!S.farmer) throw new Error('This login is not linked to anyone'); }
  if (S.me && !S.me.active) throw new Error('This login is switched off');
  if (S.me && S.me.signout_after && S.sess.user.last_sign_in_at && new Date(S.me.signout_after) > new Date(S.sess.user.last_sign_in_at)) { logout('You were signed out by the owner'); throw new Error('Signed out'); }
  await loadFeatures();
  // one-device lock (feature 23)
  if (S.me && can(23) && fresh) {
    if (S.me.device_id && S.me.device_id !== deviceId && !isOwner()) { logout('This login is locked to another phone. Ask the owner to reset it.'); throw new Error('Locked to another phone'); }
    if (!S.me.device_id) api(`/rest/v1/spm_users?id=eq.${S.me.id}`, {method: 'PATCH', body: {device_id: deviceId}}).catch(() => {});
  }
  if (fresh) api('/rest/v1/spm_logins', {method: 'POST', body: {device: navigator.userAgent.slice(0, 180), device_id: deviceId}}).catch(() => {});
  applyPrefs();
}
function logout(msg) { S.sess = null; S.me = null; S.farmer = null; S.D = {}; S.loaded = false; ls.set('spm2_sess'); stopTracking && stopTracking(); location.hash = ''; renderLogin(msg); }

/* ---------- roles & feature switches ---------- */
const isAdmin = () => !!(S.me && S.me.is_admin);
const isOwner = () => !!(S.me && S.me.role === 'owner');
const myRole = () => S.farmer ? 'farmer' : S.me.role;
const featRole = () => S.farmer ? 'farmer' : isAdmin() ? 'admin' : S.me.role === 'supervisor' ? 'organizer' : S.me.role;
async function loadFeatures() {
  try { const rows = await rest('spm_role_features', `select=feature_id&enabled=eq.true&role=eq.${featRole()}`); S.feat = new Set(rows.map(r => r.feature_id)); ls.set('spm2_feat', [...S.feat]); }
  catch (e) { S.feat = new Set(ls.get('spm2_feat', [])); }
}
const can = n => S.feat.has(n);
const canAny = (...a) => a.some(can);

/* ---------- reference & work data ---------- */
async function loadData(force) {
  const cached = ls.get('spm2_data_' + (S.me ? S.me.id : S.farmer.id));
  if (!force && cached && !navigator.onLine) { S.D = cached; S.loaded = true; return; }
  try {
    if (S.farmer) { await loadFarmerData(); }
    else {
      const [companies, seasons, varieties, vevents, villages, settings, users, farmers, fields, marks] = await Promise.all([
        rest('spm_companies', 'select=*&order=name'), rest('spm_seasons', 'select=*&order=created_at.desc'), rest('spm_varieties', 'select=*&order=name'),
        rest('spm_variety_events', 'select=*&order=sort'), rest('spm_villages', 'select=*&order=name'), rest('spm_settings', 'select=*'),
        rest('spm_users', 'select=*&order=full_name'), restAll('spm_farmers', 'select=*&order=code'), restAll('spm_fields', 'select=*'),
        restAll('spm_event_marks', 'select=*')]);
      S.D = {companies, seasons, varieties, vevents, villages, users, farmers, fields, marks, settings: Object.fromEntries(settings.map(s => [s.key, s.value]))};
    }
    S.D.at = Date.now(); S.loaded = true;
    ls.set('spm2_data_' + (S.me ? S.me.id : S.farmer.id), S.D);
  } catch (e) { if (cached) { S.D = cached; S.loaded = true; toast('Offline — showing saved data'); } else throw e; }
}
const setting = (k, d) => (S.D.settings && S.D.settings[k] !== undefined) ? S.D.settings[k] : d;
async function setSetting(k, v) { await api('/rest/v1/spm_settings?on_conflict=key', {method: 'POST', body: {key: k, value: v}, prefer: 'resolution=merge-duplicates,return=minimal'}); S.D.settings[k] = v; }
const byId = (arr, id) => (S.D[arr] || []).find(x => x.id === id);
const userName = id => { const u = byId('users', id); return u ? u.full_name : ''; };
const farmerOf = f => byId('farmers', f.farmer_id);
const fieldsOf = fid => (S.D.fields || []).filter(f => f.farmer_id === fid && !f.deleted_at);
const varietyName = id => (byId('varieties', id) || {}).name || '';
const companyName = id => (byId('companies', id) || {}).name || '';
const currentSeason = () => (S.D.seasons || []).find(s => s.active) || (S.D.seasons || [])[0];
const below = () => (S.D.users || []).filter(u => S.me && u.id !== S.me.id); // RLS already limits to people below

/* ---------- crop events: expected dates ---------- */
function fieldEvents(field) {
  const evs = (S.D.vevents || []).filter(e => e.variety_id === field.variety_id).sort((a, b) => a.sort - b.sort);
  const marks = (S.D.marks || []).filter(m => m.field_id === field.id);
  const res = {}; const t = today();
  const calc = (e, depth = 0) => {
    if (res[e.id]) return res[e.id];
    let base = field.sown_on;
    if (e.after_id && depth < 10) { const p = evs.find(x => x.id === e.after_id); if (p) { const pr = calc(p, depth + 1); base = pr.done_on || pr.expected; } }
    let expected = base ? addDays(base, e.days || 0) : null;
    if (expected) { const hol = setting('holidays', []) || [], sun = setting('skip_sundays', false); for (let k = 0; k < 10 && (hol.includes(expected) || (sun && new Date(expected + 'T00:00:00').getDay() === 0)); k++) expected = addDays(expected, 1); }
    const m = marks.find(x => x.variety_event_id === e.id);
    const done_on = m && !m.skipped ? m.done_on : null;
    const state = m ? (m.skipped ? 'skipped' : 'done') : !expected ? 'nodate' : expected < t ? 'overdue' : expected === t ? 'today' : 'upcoming';
    return res[e.id] = {ev: e, expected, done_on, mark: m, state, late: expected && state === 'overdue' ? daysBetween(expected, t) : 0};
  };
  evs.forEach(e => calc(e)); return evs.map(e => res[e.id]);
}
function allDue(fields) {
  const out = []; (fields || S.D.fields || []).filter(f => !f.deleted_at && f.status === 'active').forEach(f => fieldEvents(f).forEach(x => { if (x.state === 'overdue' || x.state === 'today') out.push({...x, field: f}); }));
  return out.sort((a, b) => (a.expected || '').localeCompare(b.expected || ''));
}
const lastVisit = fieldId => ((S.D.visits || []).filter(v => v.field_id === fieldId).sort((a, b) => b.start_at.localeCompare(a.start_at))[0]);

/* ---------- GPS ---------- */
const haversine = (a, b, c, d) => { const R = 6371000, r = x => x * Math.PI / 180, dLat = r(c - a), dLng = r(d - b); const h = Math.sin(dLat / 2) ** 2 + Math.cos(r(a)) * Math.cos(r(c)) * Math.sin(dLng / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };
function gpsFix({need = setting('gps_accuracy_m', 10), maxMs = 60000, onTick} = {}) {
  // waits for readings better than `need` metres, averages the good ones (weighted by accuracy)
  return new Promise((res, rej) => {
    if (!navigator.geolocation) return rej(new Error('This phone cannot share its location'));
    const good = []; let best = null, st = null; const t0 = Date.now();
    const resume = typeof tracking !== 'undefined' && tracking.on; if (resume) stopTracking(); // one GPS reader at a time
    const _res = res, _rej = rej; res = v => { if (resume) startTracking(); _res(v); }; rej = e => { if (resume) startTracking(); _rej(e); };
    const done = () => { navigator.geolocation.clearWatch(w); clearTimeout(tt); clearTimeout(st);
      if (good.length) { let W = 0, la = 0, ln = 0; good.forEach(p => { const w = 1 / (p.acc * p.acc); W += w; la += p.lat * w; ln += p.lng * w; }); res({lat: la / W, lng: ln / W, acc: Math.min(...good.map(p => p.acc)), n: good.length, mock: suspectMock(good)}); }
      else if (best) res({...best, n: 1, weak: true, mock: false}); else rej(new Error('Could not get location — turn on Location and try again')); };
    const onPos = p => {
      const fix = {lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy, speed: p.coords.speed, at: p.timestamp};
      if (!best || fix.acc < best.acc) best = fix; if (fix.acc <= need) good.push(fix);
      onTick && onTick(best, good.length, Math.round((Date.now() - t0) / 1000));
      if (good.length >= 5) return done();
      clearTimeout(st); if (good.length) st = setTimeout(done, 8000); // phone stopped sending new readings: use what we have
    };
    const onErr = e => { if (e.code === 1) { navigator.geolocation.clearWatch(w); clearTimeout(tt); rej(new Error('Location permission is off for this site')); } };
    const w = navigator.geolocation.watchPosition(onPos, onErr, {enableHighAccuracy: true, maximumAge: 0, timeout: maxMs});
    navigator.geolocation.getCurrentPosition(onPos, onErr, {enableHighAccuracy: true, maximumAge: 0, timeout: maxMs});
    const tt = setTimeout(done, maxMs);
  });
}
function suspectMock(pts) { // fake-GPS apps often return identical coordinates with round accuracy
  if (pts.length < 3) return false; const same = pts.every(p => p.lat === pts[0].lat && p.lng === pts[0].lng); const round = pts.every(p => Number.isInteger(p.acc) && p.acc <= 5);
  return same && round;
}
function gpsDialog(title = 'Getting location') {
  return new Promise((res, rej) => {
    let stop = false;
    sheet(`<h3>${esc(title)}</h3><p class="mut sm">Stand in the open. Waiting for ±${setting('gps_accuracy_m', 10)} m accuracy, then averaging the good readings.</p><div id="gp" class="b">Starting…</div>
      <div class="bar"><div class="tr"><div class="fl" id="gpb" style="width:3%"></div></div></div><div class="btns" style="margin-top:10px"><button class="btn" data-no>Cancel</button></div>`,
      p => p.querySelector('[data-no]').onclick = () => { stop = true; closeSheet(); rej(new Error('Cancelled')); });
    gpsFix({onTick: (b, n, s) => { const g = $('#gp'); if (g) { g.textContent = `Best ±${Math.round(b.acc)} m · ${n} good readings · ${s}s`; $('#gpb').style.width = Math.min(100, 20 * n + 4) + '%'; } }})
      .then(f => { if (!stop) { closeSheet(); res(f); } }).catch(e => { if (!stop) { closeSheet(); rej(e); } });
  });
}
const mapsLink = (lat, lng) => `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
const navLink = (lat, lng) => `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;

/* ---------- photos (compressed, stamped with time and GPS) ---------- */
function pickPhoto(stamp) {
  return new Promise((res, rej) => {
    const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.capture = 'environment';
    i.onchange = async () => { const f = i.files[0]; if (!f) return rej(new Error('No photo')); try { res(await compress(f, stamp)); } catch (e) { rej(e); } };
    i.click();
  });
}
async function compress(file, stamp) {
  const img = await new Promise((r, j) => { const im = new Image(); im.onload = () => r(im); im.onerror = j; im.src = URL.createObjectURL(file); });
  const m = 1280, k = Math.min(1, m / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = img.width * k; c.height = img.height * k;
  const x = c.getContext('2d'); x.drawImage(img, 0, 0, c.width, c.height);
  if (stamp && can(205)) { const txt = `${new Date().toLocaleString('en-IN')}${stamp.lat ? `  ${stamp.lat.toFixed(5)}, ${stamp.lng.toFixed(5)} ±${Math.round(stamp.acc || 0)}m` : ''}`; x.fillStyle = 'rgba(0,0,0,.55)'; x.fillRect(0, c.height - 34, c.width, 34); x.fillStyle = '#fff'; x.font = '18px sans-serif'; x.fillText(txt, 10, c.height - 11); }
  return await new Promise(r => c.toBlob(r, 'image/jpeg', 0.78));
}
async function uploadPhoto(blob) {
  const path = `${S.sess.user.id}/${Date.now()}-${Math.random().toString(36).slice(2, 7)}.jpg`; const t = await token();
  const r = await fetch(`${CFG.url}/storage/v1/object/spm-photos/${path}`, {method: 'POST', headers: {apikey: CFG.key, Authorization: 'Bearer ' + t, 'Content-Type': 'image/jpeg'}, body: blob});
  if (!r.ok) throw new Error('Photo upload failed'); return path;
}
const photoCache = {};
async function photoURL(path) {
  if (!path) return ''; if (photoCache[path]) return photoCache[path];
  const t = await token(); const r = await fetch(`${CFG.url}/storage/v1/object/authenticated/spm-photos/${path}`, {headers: {apikey: CFG.key, Authorization: 'Bearer ' + t}});
  if (!r.ok) return ''; return photoCache[path] = URL.createObjectURL(await r.blob());
}
function hydratePhotos(root = document) { $$('img[data-ph]', root).forEach(async im => { im.src = await photoURL(im.dataset.ph); im.removeAttribute('data-ph'); }); }
const photoStrip = arr => (arr || []).length ? `<div class="ph">${arr.map(p => `<img data-ph="${esc(p)}" alt="Photo">`).join('')}</div>` : '';

/* ---------- export ---------- */
function loadScript(src) { return new Promise((r, j) => { if ($(`script[src="${src}"]`)) return r(); const s = document.createElement('script'); s.src = src; s.onload = r; s.onerror = j; document.head.appendChild(s); }); }
async function exportXlsx(name, sheets) { // sheets: {SheetName: [ {col: val} ]}
  await loadScript('vendor/xlsx.mini.min.js'); const wb = XLSX.utils.book_new();
  Object.entries(sheets).forEach(([n, rows]) => XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows.length ? rows : [{Note: 'No rows'}]), n.slice(0, 31)));
  XLSX.writeFile(wb, `${name}-${today()}.xlsx`);
}
function downloadText(name, text, type = 'text/csv') { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([type === 'text/csv' ? '﻿' + text : text], {type})); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); }
const csv = rows => { if (!rows.length) return ''; const k = Object.keys(rows[0]); const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`; return [k.map(q).join(','), ...rows.map(r => k.map(c => q(r[c])).join(','))].join('\n'); };

/* ---------- preferences: theme, text size, language ---------- */
function prefs() { return ls.get('spm2_prefs', {mode: 'light', theme: 'green', size: 'normal', start: 'today', lang: (S.me && S.me.lang) || 'en'}); }
function applyPrefs() {
  const p = prefs(), h = document.documentElement; const dark = p.mode === 'dark' || (p.mode === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  h.classList.toggle('dark', dark); h.classList.remove('big', 'xbig', 't-blue', 't-brown', 't-teal');
  if (p.size === 'large') h.classList.add('big'); if (p.size === 'xlarge') h.classList.add('xbig'); if (p.theme !== 'green') h.classList.add('t-' + p.theme);
  h.lang = p.lang || 'en';
}
const LANG = {
  te: {Today: 'ఈరోజు', Farmers: 'రైతులు', Approvals: 'ఆమోదాలు', Team: 'టీం', More: 'మరిన్ని', Track: 'ట్రాకింగ్', 'Check in': 'హాజరు', 'Check out': 'బయలుదేరు', 'Start visit': 'సందర్శన ప్రారంభం', 'End visit': 'సందర్శన ముగింపు', Save: 'సేవ్', Cancel: 'రద్దు', 'Mark done': 'పూర్తి', Overdue: 'ఆలస్యం', 'Due today': 'ఈరోజు చేయాలి', 'My fields': 'నా పొలాలు', Money: 'డబ్బు', Complaint: 'ఫిర్యాదు', 'Sign out': 'లాగ్ అవుట్', Fields: 'పొలాలు', Search: 'వెతకండి', Reports: 'నివేదికలు', Settings: 'సెట్టింగ్స్', Home: 'హోమ్', Help: 'సహాయం', Notices: 'సూచనలు', 'Sign in': 'లాగిన్'},
  bn: {Today: 'আজ', Farmers: 'কৃষক', Approvals: 'অনুমোদন', Team: 'টিম', More: 'আরও', Track: 'ট্র্যাকিং', 'Check in': 'হাজিরা', 'Check out': 'ছুটি', 'Start visit': 'ভিজিট শুরু', 'End visit': 'ভিজিট শেষ', Save: 'সেভ', Cancel: 'বাতিল', 'Mark done': 'সম্পন্ন', Overdue: 'দেরি', 'Due today': 'আজকের কাজ', 'My fields': 'আমার জমি', Money: 'টাকা', Complaint: 'অভিযোগ', 'Sign out': 'লগ আউট', Fields: 'জমি', Search: 'খুঁজুন', Reports: 'রিপোর্ট', Settings: 'সেটিংস', Home: 'হোম', Help: 'সাহায্য', Notices: 'নোটিশ', 'Sign in': 'লগইন'},
  hi: {Today: 'आज', Farmers: 'किसान', Approvals: 'मंज़ूरी', Team: 'टीम', More: 'और', Track: 'ट्रैकिंग', 'Check in': 'हाज़िरी', 'Check out': 'छुट्टी', 'Start visit': 'विज़िट शुरू', 'End visit': 'विज़िट ख़त्म', Save: 'सेव', Cancel: 'रद्द', 'Mark done': 'पूरा', Overdue: 'देरी', 'Due today': 'आज का काम', 'My fields': 'मेरे खेत', Money: 'पैसा', Complaint: 'शिकायत', 'Sign out': 'लॉग आउट', Fields: 'खेत', Search: 'खोजें', Reports: 'रिपोर्ट', Settings: 'सेटिंग्स', Home: 'होम', Help: 'मदद', Notices: 'सूचना', 'Sign in': 'लॉगिन'},
};
const T = s => { const l = prefs().lang; return (LANG[l] && LANG[l][s]) || s; };
function speak(text) { try { const u = new SpeechSynthesisUtterance(text); u.lang = {te: 'te-IN', bn: 'bn-IN', hi: 'hi-IN'}[prefs().lang] || 'en-IN'; speechSynthesis.cancel(); speechSynthesis.speak(u); } catch (e) { toast('Voice not available on this phone'); } }

/* ---------- screen frame ---------- */
const ICONS = {
  today: '<path d="M4 5h16v15H4zM4 9h16M9 3v4M15 3v4"/>', farmers: '<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3 3-5 6-5s6 2 6 5M16 11a3 3 0 1 0 0-6M21 20c0-2-1.5-3.6-3.5-4.5"/>',
  approvals: '<path d="M4 4h16v12H4zM8 20h8M9 10l2 2 4-4"/>', team: '<circle cx="12" cy="7" r="3"/><path d="M6 21v-2a6 6 0 0 1 12 0v2"/>', more: '<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>',
  track: '<path d="M12 21s-7-6.5-7-12a7 7 0 0 1 14 0c0 5.5-7 12-7 12z"/><circle cx="12" cy="9" r="2.5"/>', money: '<rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/>', home: '<path d="M3 11l9-7 9 7v9H3z"/>', field: '<path d="M3 20h18M5 20V10l7-5 7 5v10"/>',
};
const icon = (n, s = 22) => `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ''}</svg>`;
function hdr(title, sub = '', back = true) {
  return `<header class="top">${back ? `<button class="ib" onclick="history.length>1?history.back():go('')" aria-label="Back">‹</button>` : ''}<h1>${esc(title)}${sub ? `<small>${sub}</small>` : ''}</h1><span class="sm" id="syncb"></span></header>`;
}
function go(r) { location.hash = '#/' + r; }
