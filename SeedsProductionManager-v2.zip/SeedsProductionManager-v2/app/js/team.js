/* Team, people, logins, tasks, access control (feature switches) */
'use strict';
function vTeam() {
  const me = S.me, users = S.D.users || [];
  const roots = isOwner() ? users.filter(u => !u.parent_id && u.id !== me.id) : users.filter(u => u.parent_id === me.id);
  const tree = (u, d = 0) => { const kids = users.filter(k => k.parent_id === u.id); return `<div class="it" style="padding-left:${d * 18}px" onclick="go('person/${u.id}')"><div class="av">${esc(initials(u.full_name))}</div><div class="main"><b>${esc(u.full_name)}${u.is_admin ? ' <span class="tag">Admin</span>' : ''}</b><span>${ROLE[u.role]}${u.username ? ' · ' + esc(u.username) : ' · No login'}${!u.active ? ' · <span class="tag bad">Switched off</span>' : ''}</span></div><div class="side">›</div></div>${kids.map(k => tree(k, d + 1)).join('')}`; };
  const order = ['owner', 'supervisor', 'viewer', 'organizer', 'sub_organizer', 'field_staff', 'company_assistant'];
  roots.sort((a, b) => order.indexOf(a.role) - order.indexOf(b.role));
  return hdr(T('Team'), users.length + ' people you can see', false) + `<div class="wrap">
  <div class="btns" style="margin-bottom:12px">${isOwner() ? `<button class="btn pri" onclick="go('team/edit/new')">＋ Add person</button>` : ''}${can(79) || can(211) ? `<button class="btn" onclick="taskForm()">＋ Task</button>` : ''}${can(217) ? `<button class="btn" onclick="go('exceptions')">Exceptions</button>` : ''}${can(58) || can(72) ? `<button class="btn" onclick="go('live')">Today live</button>` : ''}</div>
  ${(S.D.tasks || []).filter(t => t.created_by === me.id && !t.done_at).length ? `<div class="card"><h2>Tasks I gave</h2>${(S.D.tasks || []).filter(t => t.created_by === me.id && !t.done_at).map(t => `<div class="it" onclick="taskSheet('${t.id}')"><div class="main"><b>${esc(t.title)}</b><span>${esc(userName(t.assigned_to))} ${t.due ? '· due ' + dmy(t.due) : ''}</span></div></div>`).join('')}</div>` : ''}
  <div class="card"><div class="list">${roots.map(u => tree(u)).join('') || '<p class="mut">Nobody below you yet.</p>'}</div></div></div>`;
}
function vLive() { return hdr('Team today', 'Check-in, visits and last location') + `<div class="wrap" id="live"><div class="card mut">Loading…</div></div>`; }
async function bindLive() {
  try { const [att, vis, pts] = await Promise.all([rest('spm_attendance', `select=*&day=eq.${today()}`), rest('spm_visits', `select=user_id,start_at,end_at,inside,flags&start_at=gte.${today()}T00:00:00%2B05:30`), rest('spm_track_points', `select=user_id,at,lat,lng&at=gte.${today()}T00:00:00%2B05:30&order=at.desc&limit=1000`)]);
    const staff = (S.D.users || []).filter(u => ['organizer', 'sub_organizer', 'field_staff', 'company_assistant'].includes(u.role) && u.active && u.id !== S.me.id);
    ($('#live') || {}).innerHTML = `<div class="card"><div class="tw"><table class="t"><tr><th>Person</th><th>In</th><th>Out</th><th class="r">Visits</th><th>Last seen</th></tr>${staff.map(u => { const a = att.find(x => x.user_id === u.id), v = vis.filter(x => x.user_id === u.id), p = pts.find(x => x.user_id === u.id);
      return `<tr onclick="go('person/${u.id}')"><td><b>${esc(u.full_name)}</b><br><span class="sm mut">${ROLE[u.role]}</span></td><td>${a ? tm(a.in_at) : '<span class="tag bad">No</span>'}</td><td>${a && a.out_at ? tm(a.out_at) : ''}</td><td class="r">${v.length}${v.some(x => x.inside === false) ? ' <span class="tag warn">!</span>' : ''}</td><td>${p ? `<a target="_blank" rel="noopener" href="${mapsLink(p.lat, p.lng)}" onclick="event.stopPropagation()">${tm(p.at)}</a>` : '—'}</td></tr>`; }).join('')}</table></div></div>`;
  } catch (e) { ($('#live') || {}).innerHTML = `<div class="card">${esc(e.message)}</div>`; }
}

/* ---------- person editor (owner) ---------- */
function vPersonEdit(id) {
  const u = id === 'new' ? {role: 'field_staff', active: true} : byId('users', id); if (!u) return hdr('Person') + '<div class="wrap">Not found</div>';
  const users = S.D.users || [], roles = ['owner', 'supervisor', 'viewer', 'organizer', 'sub_organizer', 'field_staff', 'company_assistant'];
  return hdr(id === 'new' ? 'Add person' : 'Edit ' + u.full_name) + `<div class="wrap"><div class="card">
  <label class="f">Full name *</label><input class="in" id="pe_name" value="${esc(u.full_name)}">
  <label class="f">Role</label><select class="in" id="pe_role">${roles.map(r => `<option value="${r}" ${u.role === r ? 'selected' : ''}>${ROLE[r]}</option>`).join('')}</select>
  <label class="f">Reports to</label><select class="in" id="pe_parent"><option value="">No parent</option>${users.filter(x => ['organizer', 'sub_organizer', 'field_staff'].includes(x.role) && x.id !== u.id).map(x => `<option value="${x.id}" ${u.parent_id === x.id ? 'selected' : ''}>${esc(x.full_name)} (${ROLE[x.role]})</option>`).join('')}</select>
  <p class="sm mut">Sub-organizer → under an Organizer · Field assistant → under an Organizer or Sub-organizer · Company assistant → under a Field assistant.</p>
  <label class="f">Company</label><select class="in" id="pe_co"><option value="">All companies</option>${(S.D.companies || []).map(c => `<option value="${c.id}" ${u.company_id === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
  <label class="f">Phone</label><input class="in" id="pe_phone" inputmode="numeric" value="${esc(u.phone)}">
  ${can(73) ? `<label class="f">Target acres this season</label><input class="in" id="pe_target" inputmode="decimal" value="${esc((setting('targets', {}) || {})[u.id] || '')}">` : ''}
  <div class="btns" style="margin-top:14px"><button class="btn pri" id="pe_save">${T('Save')}</button></div></div>
  ${id !== 'new' ? `<div class="card"><h2>Login</h2><p>${u.username ? 'User ID: <b>' + esc(u.username) + '</b>' : 'No login yet'}${u.device_id ? '<br><span class="sm mut">Locked to one phone</span>' : ''}</p><div class="btns">
   ${u.username ? `<button class="btn" onclick="setPw('${u.id}')">Reset password</button><button class="btn" onclick="adminAct('force_signout','${u.id}')">Force sign-out</button>${u.device_id ? `<button class="btn" onclick="adminAct('reset_device','${u.id}')">Allow another phone</button>` : ''}` : `<button class="btn pri" onclick="makeLogin('${u.id}')">Create login</button>`}
   <button class="btn ${u.active ? 'bad' : ''}" onclick="toggleActive('${u.id}')">${u.active ? 'Switch off' : 'Switch on'}</button></div></div>
   ${u.role === 'supervisor' ? supervisorCard(u) : ''}${u.role === 'viewer' ? viewerCard(u) : ''}
   ${can(233) || can(234) ? `<div class="card"><h2>Staff leaving</h2><p class="sm mut">Move everyone and every farmer under this person to someone else, and get a handover report.</p><div class="btns">${can(233) ? `<button class="btn" onclick="reassignAll('${u.id}')">Reassign downline</button>` : ''}${can(234) ? `<button class="btn" onclick="handover('${u.id}')">Handover report</button>` : ''}</div></div>` : ''}
   ${can(22) ? `<div class="card"><h2>Login history</h2><div id="lh" class="sm mut">Loading…</div></div>` : ''}` : ''}</div>`;
}
function bindPersonEdit(id) {
  $('#pe_save').onclick = async () => { const v = k => $('#pe_' + k).value; if (!v('name').trim()) return toast('Enter the name');
    const row = {full_name: v('name').trim(), role: v('role'), parent_id: v('parent') || null, company_id: v('co') || null, phone: v('phone').trim()};
    if (['owner', 'supervisor', 'viewer', 'organizer'].includes(row.role)) row.parent_id = null;
    try { const r = await save('spm_users', row, id === 'new' ? {} : {id}); if (id === 'new') S.D.users.push(r); else Object.assign(byId('users', id), r);
      if ($('#pe_target')) { const t = {...(setting('targets', {}) || {})}; t[r.id] = parseFloat($('#pe_target').value) || 0; await setSetting('targets', t); }
      toast('Saved'); go('team/edit/' + r.id); } catch (e) { toast(e.message); } };
  if ($('#lh')) rest('spm_logins', `select=*&user_id=eq.${id}&order=at.desc&limit=15`).then(rows => $('#lh').innerHTML = rows.map(r => `${dt(r.at)} · ${esc(/Android|iPhone|Windows|Mac/.exec(r.device) || 'device')}`).join('<br>') || 'No sign-ins yet.').catch(e => $('#lh').textContent = e.message);
}
function supervisorCard(u) { return `<div class="card"><h2>Organizers this supervisor watches</h2><div id="sup" class="chips">${(S.D.users || []).filter(x => x.role === 'organizer').map(o => `<button class="chip ${(S.D.supOrgs || []).some(s => s.supervisor_id === u.id && s.organizer_id === o.id) ? 'on' : ''}" onclick="toggleSup('${u.id}','${o.id}',this)">${esc(o.full_name)}</button>`).join('')}</div></div>`; }
async function toggleSup(sid, oid, el) { const on = el.classList.contains('on'); try { if (on) await api(`/rest/v1/spm_supervisor_organizers?supervisor_id=eq.${sid}&organizer_id=eq.${oid}`, {method: 'DELETE'}); else await api('/rest/v1/spm_supervisor_organizers', {method: 'POST', body: {supervisor_id: sid, organizer_id: oid}}); el.classList.toggle('on'); } catch (e) { toast(e.message); } }
function viewerCard(u) { return `<div class="card"><h2>What this observer sees</h2><p class="sm mut">Whole companies or single organizers.</p><div class="chips">${(S.D.companies || []).map(c => `<button class="chip ${(S.D.viewerScope || []).some(s => s.viewer_id === u.id && s.company_id === c.id) ? 'on' : ''}" onclick="toggleScope('${u.id}','company_id','${c.id}',this)">${esc(c.name)}</button>`).join('')}${(S.D.users || []).filter(x => x.role === 'organizer').map(o => `<button class="chip ${(S.D.viewerScope || []).some(s => s.viewer_id === u.id && s.organizer_id === o.id) ? 'on' : ''}" onclick="toggleScope('${u.id}','organizer_id','${o.id}',this)">${esc(o.full_name)}</button>`).join('')}</div></div>`; }
async function toggleScope(vid, col, id, el) { const on = el.classList.contains('on'); try { if (on) await api(`/rest/v1/spm_viewer_scope?viewer_id=eq.${vid}&${col}=eq.${id}`, {method: 'DELETE'}); else await api('/rest/v1/spm_viewer_scope', {method: 'POST', body: {viewer_id: vid, [col]: id}}); el.classList.toggle('on'); } catch (e) { toast(e.message); } }
async function makeLogin(id) {
  sheet(`<h3>Create login</h3><label class="f">User ID</label><input class="in" id="ml_u" autocapitalize="none" placeholder="e.g. ravi.k"><label class="f">Password (8+ characters)</label><input class="in" id="ml_p" type="text">
  <div class="btns" style="margin-top:12px"><button class="btn pri" id="ml_s">Create login</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, p => p.querySelector('#ml_s').onclick = async () => {
    try { await edge('spm-admin', {action: 'create_login', user_id: id, username: p.querySelector('#ml_u').value, password: p.querySelector('#ml_p').value}); closeSheet(); toast('Login created'); await loadData(true); render(); } catch (e) { toast(e.message); } });
}
async function setPw(id) { const pw = await askText('Reset password', 'New password (8+ characters)', '', {required: true}); if (!pw) return; try { await edge('spm-admin', {action: 'set_password', user_id: id, password: pw}); toast('Password changed'); } catch (e) { toast(e.message); } }
async function adminAct(action, id) { try { await edge('spm-admin', {action, user_id: id}); toast(action === 'force_signout' ? 'They will be signed out on next open' : 'Done'); await loadData(true); render(); } catch (e) { toast(e.message); } }
async function toggleActive(id) { const u = byId('users', id); if (!(await ask(u.active ? 'Switch off' : 'Switch on', `${u.active ? 'Stop' : 'Allow'} ${u.full_name} signing in?`, u.active ? 'Switch off' : 'Switch on', u.active))) return; try { const r = await save('spm_users', {active: !u.active}, {id}); Object.assign(u, r); render(); } catch (e) { toast(e.message); } }
async function reassignAll(id) {
  const u = byId('users', id); const cands = (S.D.users || []).filter(x => x.role === u.role && x.id !== id && x.active);
  sheet(`<h3>Reassign from ${esc(u.full_name)}</h3><label class="f">Move everything to</label><select class="in" id="ra">${cands.map(c => `<option value="${c.id}">${esc(c.full_name)}</option>`).join('')}</select>
  <div class="btns" style="margin-top:12px"><button class="btn pri" id="ra_s">Move</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, p => p.querySelector('#ra_s').onclick = async () => {
    const to = p.querySelector('#ra').value; if (!to) return; const col = {organizer: 'organizer_id', sub_organizer: 'sub_organizer_id', field_staff: 'field_staff_id'}[u.role];
    try { if (col) await api(`/rest/v1/spm_farmers?${col}=eq.${id}`, {method: 'PATCH', body: {[col]: to}});
      for (const k of (S.D.users || []).filter(x => x.parent_id === id)) await api(`/rest/v1/spm_users?id=eq.${k.id}`, {method: 'PATCH', body: {parent_id: to}});
      closeSheet(); toast('Moved'); await loadData(true); render(); } catch (e) { toast(e.message); } });
}
function handover(id) {
  const u = byId('users', id), fs = (S.D.farmers || []).filter(f => !f.deleted_at && [f.organizer_id, f.sub_organizer_id, f.field_staff_id].includes(id));
  const rows = fs.flatMap(f => fieldsOf(f.id).map(x => { const ev = fieldEvents(x); const nx = ev.find(e => ['overdue', 'today', 'upcoming'].includes(e.state)); return {'Farmer ID': f.code, Farmer: f.name, Village: f.village, Mobile: f.mobile, Acres: x.acres, Variety: varietyName(x.variety_id), Sown: dmy(x.sown_on), 'Next event': nx ? nx.ev.name : '', Expected: nx ? dmy(nx.expected) : '', Overdue: ev.filter(e => e.state === 'overdue').length, Location: x.lat ? mapsLink(x.lat, x.lng) : 'missing'}; }));
  exportXlsx('handover-' + u.full_name.replace(/\W+/g, '-'), {Handover: rows});
}

/* ---------- tasks (79, 211) ---------- */
function taskForm() {
  const people = (S.D.users || []).filter(u => u.id !== S.me.id);
  sheet(`<h3>New task</h3><label class="f">For</label><select class="in" id="tk_to">${people.map(u => `<option value="${u.id}">${esc(u.full_name)} (${ROLE[u.role]})</option>`).join('')}</select>
  <label class="f">Task</label><input class="in" id="tk_t"><label class="f">Details</label><textarea class="in" id="tk_n"></textarea><label class="f">Due</label><input class="in" type="date" id="tk_d">
  <div class="btns" style="margin-top:12px"><button class="btn pri" id="tk_s">Give task</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, p => p.querySelector('#tk_s').onclick = async () => {
    const t = p.querySelector('#tk_t').value.trim(); if (!t) return toast('Write the task'); try { const r = await save('spm_tasks', {assigned_to: p.querySelector('#tk_to').value, title: t, note: p.querySelector('#tk_n').value, due: p.querySelector('#tk_d').value || null}); (S.D.tasks = S.D.tasks || []).unshift(r); closeSheet(); toast('Task given'); render(); } catch (e) { toast(e.message); } });
}
function taskSheet(id) {
  const t = (S.D.tasks || []).find(x => x.id === id); if (!t) return;
  sheet(`<h3>${esc(t.title)}</h3><p>${esc(t.note)}</p><p class="sm mut">From ${esc(userName(t.created_by))} to ${esc(userName(t.assigned_to))}${t.due ? ' · due ' + dmy(t.due) : ''}${t.done_at ? ' · done ' + dt(t.done_at) : ''}</p>
  ${!t.done_at && t.assigned_to === S.me.id ? `<label class="f">What was done</label><input class="in" id="td_n"><div class="btns" style="margin-top:12px"><button class="btn pri" id="td_s">Mark done</button></div>` : ''}<button class="btn" style="margin-top:8px" onclick="closeSheet()">Close</button>`, p => {
    const b = p.querySelector('#td_s'); if (b) b.onclick = async () => { try { const r = await save('spm_tasks', {done_at: new Date().toISOString(), done_note: p.querySelector('#td_n').value}, {id}); Object.assign(t, r); closeSheet(); toast('Task done'); render(); } catch (e) { toast(e.message); } }; });
}

/* ---------- reassign farmers & bulk mark (62, 63) ---------- */
function vBulk() {
  const villages = [...new Set(visibleFarmers().map(f => f.village))].sort(), orgs = (S.D.users || []).filter(u => u.role === 'organizer');
  return hdr('Bulk work') + `<div class="wrap">${can(63) ? `<div class="card"><h2>Mark an event done for a whole village</h2><label class="f">Village</label><select class="in" id="bk_v">${villages.map(v => `<option>${esc(v)}</option>`).join('')}</select>
   <label class="f">Event</label><select class="in" id="bk_e">${[...new Set((S.D.vevents || []).map(e => e.name))].map(n => `<option>${esc(n)}</option>`).join('')}</select><label class="f">Done on</label><input class="in" type="date" id="bk_d" value="${today()}" max="${today()}">
   <button class="btn pri" style="margin-top:12px" id="bk_go">Mark done</button></div>` : ''}
  ${can(62) ? `<div class="card"><h2>Move farmers to another organizer</h2><label class="f">From</label><select class="in" id="mv_f">${orgs.map(o => `<option value="${o.id}">${esc(o.full_name)}</option>`).join('')}</select><label class="f">Village (optional)</label><select class="in" id="mv_v"><option value="">All villages</option>${villages.map(v => `<option>${esc(v)}</option>`).join('')}</select>
   <label class="f">To</label><select class="in" id="mv_t">${orgs.map(o => `<option value="${o.id}">${esc(o.full_name)}</option>`).join('')}</select><button class="btn pri" style="margin-top:12px" id="mv_go">Move</button></div>` : ''}</div>`;
}
function bindBulk() {
  const b = $('#bk_go'); if (b) b.onclick = async () => { const v = $('#bk_v').value, en = $('#bk_e').value, d = $('#bk_d').value; const ids = new Set(visibleFarmers().filter(f => f.village === v).map(f => f.id));
    const todo = []; (S.D.fields || []).filter(x => ids.has(x.farmer_id) && !x.deleted_at).forEach(x => fieldEvents(x).filter(e => e.ev.name === en && !e.mark).forEach(e => todo.push({field_id: x.id, variety_event_id: e.ev.id, done_on: d, skipped: false, note: 'Village bulk entry'})));
    if (!todo.length) return toast('Nothing to mark'); if (!(await ask('Mark done', `Mark "${en}" done on ${todo.length} fields in ${v}?`, 'Mark done'))) return;
    try { const r = await api('/rest/v1/spm_event_marks', {method: 'POST', body: todo, prefer: 'return=representation'}); S.D.marks.push(...r); toast(`${r.length} fields marked`); } catch (e) { toast(e.message); } };
  const m = $('#mv_go'); if (m) m.onclick = async () => { const f = $('#mv_f').value, t = $('#mv_t').value, v = $('#mv_v').value; if (f === t) return toast('Choose a different organizer');
    if (!(await ask('Move farmers', `Move ${visibleFarmers().filter(x => x.organizer_id === f && (!v || x.village === v)).length} farmers?`, 'Move'))) return;
    try { await api(`/rest/v1/spm_farmers?organizer_id=eq.${f}${v ? '&village=eq.' + encodeURIComponent(v) : ''}`, {method: 'PATCH', body: {organizer_id: t, sub_organizer_id: null, field_staff_id: null}}); toast('Moved'); await loadData(true); render(); } catch (e) { toast(e.message); } };
}

/* ---------- Access control: feature switches (20, 225, 229) ---------- */
let ACQ = '';
function vAccess() {
  const edit = isAdmin() || isOwner();
  return hdr('Access control', isAdmin() ? 'Admin — all roles' : isOwner() ? 'Owner — roles below Owner' : 'View only') + `<div class="wrap">
  <div class="card"><p class="sm mut" style="margin:0">A role can only get a feature the role above it has. Turning a feature off also turns it off for every role below. Observer does not block the roles below it. Every change is logged.</p>
  ${edit && can(229) ? `<div class="btns" style="margin-top:8px"><button class="btn sm" onclick="copyRole()">Copy one role's switches to another</button>${can(225) ? '<button class="btn sm" onclick="permLog()">Who changed what</button>' : ''}</div>` : ''}</div>
  <div class="search"><input class="in" id="acq" placeholder="Search features…" value="${esc(ACQ)}"></div><div class="card tw" id="acc" style="max-height:72vh;padding:0"><p class="mut" style="padding:12px">Loading…</p></div></div>`;
}
let AC = {F: [], ON: {}};
async function bindAccess() {
  try { const [F, on] = await Promise.all([rest('spm_features', 'select=*&order=sort'), restAll('spm_role_features', 'select=role,feature_id&enabled=eq.true')]);
    AC.F = F; AC.ON = {}; ROLE_ORDER.forEach(r => AC.ON[r] = new Set()); on.forEach(x => AC.ON[x.role] && AC.ON[x.role].add(x.feature_id)); drawAccess(); } catch (e) { ($('#acc') || {}).innerHTML = `<p style="padding:12px">${esc(e.message)}</p>`; }
  $('#acq').oninput = e => { ACQ = e.target.value; drawAccess(); };
}
const acCanEdit = r => isAdmin() || (isOwner() && r !== 'admin' && r !== 'owner');
const acAllowed = (r, id) => !FEATURE_PARENT[r] || AC.ON[FEATURE_PARENT[r]].has(id);
function drawAccess() {
  const el = $('#acc'); if (!el) return; const sT = el.scrollTop, sL = el.scrollLeft; const q = ACQ.toLowerCase(); let la = '';
  const cols = (isAdmin() || isOwner()) ? ROLE_ORDER : [featRole()];
  el.innerHTML = `<table class="t matrix"><thead><tr><th class="f">Feature</th>${cols.map(r => `<th>${ROLE[r]}<br><span class="mut">${AC.ON[r].size}</span></th>`).join('')}</tr></thead><tbody>${AC.F.filter(f => !q || f.name.toLowerCase().includes(q)).map(f => {
    const g = f.area !== la ? (la = f.area, `<tr><td colspan="${cols.length + 1}" style="background:var(--soft);font-weight:700">${esc(f.area)}</td></tr>`) : '';
    return g + `<tr><td class="f"><span class="mut">${f.id} · </span>${esc(f.name)}</td>${cols.map(r => { const on = AC.ON[r].has(f.id), dis = !acCanEdit(r) || (!on && !acAllowed(r, f.id)); return `<td><input type="checkbox" data-r="${r}" data-id="${f.id}" ${on ? 'checked' : ''} ${dis ? 'disabled' : ''} aria-label="${ROLE[r]}: ${esc(f.name)}"></td>`; }).join('')}</tr>`; }).join('')}</tbody></table>`;
  el.scrollTop = sT; el.scrollLeft = sL;
  el.onchange = async e => { const c = e.target; if (!c.dataset.r) return; const r = c.dataset.r, id = +c.dataset.id; c.disabled = true;
    try { const d = await api(`/rest/v1/spm_role_features?role=eq.${r}&feature_id=eq.${id}`, {method: 'PATCH', body: {enabled: c.checked}, prefer: 'return=representation'}); if (!d.length) throw new Error('Not allowed');
      const on = await restAll('spm_role_features', `select=role,feature_id&enabled=eq.true&feature_id=eq.${id}`); ROLE_ORDER.forEach(x => AC.ON[x].delete(id)); on.forEach(x => AC.ON[x.role].add(id)); drawAccess(); toast('Saved'); if (r === featRole()) loadFeatures(); }
    catch (err) { c.checked = !c.checked; c.disabled = false; toast(err.message); } };
}
async function copyRole() {
  const edits = ROLE_ORDER.filter(acCanEdit);
  sheet(`<h3>Copy switches</h3><label class="f">From role</label><select class="in" id="cr_f">${ROLE_ORDER.map(r => `<option value="${r}">${ROLE[r]}</option>`).join('')}</select><label class="f">To role</label><select class="in" id="cr_t">${edits.map(r => `<option value="${r}">${ROLE[r]}</option>`).join('')}</select>
  <p class="sm mut">Only features the role above allows are copied.</p><div class="btns" style="margin-top:12px"><button class="btn pri" id="cr_s">Copy</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, p => p.querySelector('#cr_s').onclick = async () => {
    const f = p.querySelector('#cr_f').value, t = p.querySelector('#cr_t').value; if (f === t) return toast('Choose two different roles'); closeSheet(); toast('Copying…');
    const want = AC.ON[f]; let n = 0; for (const x of AC.F) { const on = want.has(x.id) && acAllowed(t, x.id); if (on !== AC.ON[t].has(x.id)) { try { await api(`/rest/v1/spm_role_features?role=eq.${t}&feature_id=eq.${x.id}`, {method: 'PATCH', body: {enabled: on}}); n++; } catch (e) {} } }
    toast(`${n} switches changed`); bindAccess(); });
}
async function permLog() { try { const rows = await rest('spm_audit', 'select=*&tbl=eq.spm_role_features&order=at.desc&limit=60'); sheet(`<h3>Who changed what</h3>${rows.map(r => `<p class="sm"><b>${dt(r.at)}</b> · ${esc(userName(r.actor) || 'Admin')}<br>${ROLE[(r.new || {}).role] || ''} · feature ${(r.new || {}).feature_id} → ${(r.new || {}).enabled ? 'on' : 'off'}</p>`).join('') || '<p class="mut">No changes yet.</p>'}<button class="btn" onclick="closeSheet()">Close</button>`); } catch (e) { toast(e.message); } }
