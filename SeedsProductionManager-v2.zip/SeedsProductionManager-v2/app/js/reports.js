/* Reports, dashboards, TV mode, exports, problem reports, photo gallery */
'use strict';
function bars(obj, fmt = v => num(v)) { const max = Math.max(1, ...Object.values(obj)); return Object.entries(obj).sort((a, b) => b[1] - a[1]).map(([k, v]) => `<div class="bar"><span class="t">${esc(k)}</span><div class="tr"><div class="fl" style="width:${Math.max(2, 100 * v / max)}%"></div></div><span class="v">${fmt(v)}</span></div>`).join('') || '<p class="mut sm">No data.</p>'; }
function vReports() {
  const FL = (S.D.fields || []).filter(f => !f.deleted_at), F = visibleFarmers();
  const byVar = {}, byStage = {}, exp = {}; FL.forEach(f => { const v = varietyName(f.variety_id) || 'No variety'; byVar[v] = (byVar[v] || 0) + +f.acres; const lv = lastVisit(f.id); const st = !f.sown_on ? 'Not sown' : (lv && lv.stage) || 'Sown'; byStage[st] = (byStage[st] || 0) + +f.acres; if (f.expected_kg_per_acre) exp[v] = (exp[v] || 0) + f.expected_kg_per_acre * f.acres; });
  const byCo = {}; F.forEach(f => { const c = companyName(f.company_id) || 'No company'; byCo[c] = (byCo[c] || 0) + sum(fieldsOf(f.id), x => x.acres); });
  const hv = S.D.harvests || [], expTot = sum(Object.values(exp), x => x);
  return hdr(T('Reports'), (currentSeason() || {}).name || '') + `<div class="wrap">
  <div class="btns" style="margin-bottom:12px">${can(32) || can(170) || can(57) ? `<button class="btn" onclick="go('map')">Map</button>` : ''}${can(167) ? `<button class="btn" onclick="go('tv')">TV mode</button>` : ''}${can(27) || can(76) || can(173) || can(104) ? `<button class="btn" onclick="exportPicker()">Download Excel…</button>` : ''}${can(65) || can(109) ? `<button class="btn" onclick="teamReport()">Weekly / monthly report</button>` : ''}${can(216) ? `<button class="btn" onclick="dailySummary()">Daily summary</button>` : ''}${can(77) ? `<button class="btn" onclick="go('gallery')">Photos</button>` : ''}${can(78) || can(210) ? `<button class="btn" onclick="go('problems')">Problems</button>` : ''}</div>
  ${can(30) || can(168) ? `<div class="cols"><div class="card"><h2>Acres by variety</h2>${bars(byVar)}</div><div class="card"><h2>Acres by company</h2>${bars(byCo)}</div></div>` : ''}
  ${can(66) ? `<div class="card"><h2>Crop stage (latest visit)</h2>${bars(byStage)}</div>` : ''}
  ${can(34) ? `<div class="card"><h2>Expected production</h2>${bars(exp, v => num(v / 1000, 1) + ' t')}<p class="sm mut">Total ${num(expTot / 1000, 1)} t. Set expected kg per acre on each field.</p></div>` : ''}
  ${can(172) ? `<div class="card"><h2>Harvest progress</h2><div class="bar"><span class="t">${num(sum(hv, h => h.weight_kg) / 1000, 1)} t of ${num(expTot / 1000, 1)} t</span><div class="tr"><div class="fl" style="width:${expTot ? Math.min(100, 100 * sum(hv, h => h.weight_kg) / expTot) : 0}%"></div></div></div></div>` : ''}
  ${can(33) || can(67) ? isolationCard() : ''}
  ${can(31) || can(169) ? leagueCard() : ''}
  ${can(80) || can(73) ? `<div class="card" id="vcount"><h2>Visits per staff this month</h2><p class="mut sm">Loading…</p></div>` : ''}
  ${can(50) ? `<div class="card" id="usage"><h2>App use (last 7 days)</h2><p class="mut sm">Loading…</p></div>` : ''}
  ${can(209) ? `<div class="card" id="fapp"><h2>Farmer app use</h2><p class="mut sm">Loading…</p></div>` : ''}
  </div>`;
}
async function bindReports() {
  const vc = $('#vcount'); if (vc) { try { const v = await rest('spm_visits', `select=user_id&start_at=gte.${today().slice(0, 7)}-01`); const c = {}; v.forEach(x => c[userName(x.user_id) || 'Unknown'] = (c[userName(x.user_id) || 'Unknown'] || 0) + 1);
    const t = setting('targets', {}) || {}; const tg = can(73) ? (S.D.users || []).filter(u => t[u.id]).map(u => { const ac = sum((S.D.farmers || []).filter(f => !f.deleted_at && [f.organizer_id, f.sub_organizer_id, f.field_staff_id].includes(u.id)).flatMap(f => fieldsOf(f.id)), x => x.acres); return `<div class="bar"><span class="t">${esc(u.full_name)}</span><div class="tr"><div class="fl" style="width:${Math.min(100, 100 * ac / t[u.id])}%"></div></div><span class="v">${num(ac)}/${num(t[u.id])}</span></div>`; }).join('') : '';
    vc.innerHTML = `<h2>Visits per staff this month</h2>${bars(c, v => v)}${tg ? `<h2 style="margin-top:14px">Target vs achieved acres</h2>${tg}` : ''}`; } catch (e) { vc.remove(); } }
  const us = $('#usage'); if (us) { try { const l = await rest('spm_logins', `select=user_id,farmer_id,at&at=gte.${addDays(today(), -7)}`); const c = {}; l.filter(x => x.user_id).forEach(x => c[userName(x.user_id) || '?'] = (c[userName(x.user_id) || '?'] || 0) + 1); const active = new Set(l.map(x => x.user_id)); const idle = (S.D.users || []).filter(u => u.username && u.active && !active.has(u.id));
    us.innerHTML = `<h2>App use (last 7 days)</h2>${bars(c, v => v + ' sign-ins')}${idle.length ? `<p class="sm"><b>Not used:</b> ${idle.map(u => esc(u.full_name)).join(', ')}</p>` : ''}`; } catch (e) { us.remove(); } }
  const fa = $('#fapp'); if (fa) { try { const l = await rest('spm_logins', `select=farmer_id,at&farmer_id=not.is.null&order=at.desc&limit=500`); const last = {}; l.forEach(x => last[x.farmer_id] = last[x.farmer_id] || x.at); const withLogin = visibleFarmers().filter(f => f.auth_id);
    fa.innerHTML = `<h2>Farmer app use</h2><p>${withLogin.length} farmers have a login · ${Object.keys(last).length} opened the app</p>${withLogin.slice(0, 30).map(f => `<div class="sm">${esc(f.name)} · ${last[f.id] ? 'last opened ' + dt(last[f.id]) : 'never opened'}</div>`).join('')}`; } catch (e) { fa.remove(); } }
}
function isolationCard() {
  const lim = setting('isolation_m', 200), FL = (S.D.fields || []).filter(f => f.lat != null && !f.deleted_at), out = [];
  for (let i = 0; i < FL.length; i++) for (let j = i + 1; j < FL.length; j++) { const a = FL[i], b = FL[j]; if (a.variety_id === b.variety_id) continue; const d = haversine(a.lat, a.lng, b.lat, b.lng); if (d < lim) out.push({a, b, d}); }
  out.sort((x, y) => x.d - y.d);
  return `<div class="card"><h2>Isolation conflicts (closer than ${lim} m, different variety) · ${out.length}</h2>${out.slice(0, 30).map(o => `<div class="it" onclick="go('field/${o.a.id}')"><div class="main"><b>${esc((farmerOf(o.a) || {}).name)} ↔ ${esc((farmerOf(o.b) || {}).name)}</b><span>${esc(varietyName(o.a.variety_id))} / ${esc(varietyName(o.b.variety_id))}</span></div><div class="side"><span class="tag bad">${Math.round(o.d)} m</span></div></div>`).join('') || '<p class="mut sm">No conflicts among fields with a location.</p>'}</div>`;
}
function leagueCard() {
  const due = allDue(); const orgs = (S.D.users || []).filter(u => u.role === 'organizer');
  const r = orgs.map(o => { const ids = new Set((S.D.farmers || []).filter(f => f.organizer_id === o.id && !f.deleted_at).map(f => f.id)); const fl = (S.D.fields || []).filter(f => ids.has(f.farmer_id) && !f.deleted_at); const ov = due.filter(d => ids.has(d.field.farmer_id) && d.state === 'overdue').length; const vis = (S.D.visits || []).filter(v => ids.has(v.farmer_id)).length;
    return {o, ac: sum(fl, f => f.acres), ovp: fl.length ? 100 * ov / fl.length : 0, vis}; }).sort((a, b) => a.ovp - b.ovp || b.ac - a.ac);
  return `<div class="card"><h2>Organizer league</h2><table class="t"><tr><th>#</th><th>Organizer</th><th class="r">Acres</th><th class="r">Overdue %</th><th class="r">Visits</th></tr>${r.map((x, i) => `<tr><td>${i + 1}</td><td>${esc(x.o.full_name)}</td><td class="r">${num(x.ac)}</td><td class="r">${num(x.ovp, 0)}%</td><td class="r">${x.vis}</td></tr>`).join('')}</table></div>`;
}
function exportPicker() {
  const COLS = ['Farmer ID', 'Farmer', 'Father', 'Mobile', 'Village', 'Mandal', 'District', 'State', 'Company', 'Organizer', 'Sub-organizer', 'Field staff', 'Status', 'Acres', 'Survey no', 'Variety', 'Season', 'Irrigation', 'Foundation seed date', 'Sowing date', 'Field status', 'Latitude', 'Longitude', 'Location link', 'Overdue events', 'Last visit', 'Harvest kg'];
  const saved = ls.get('spm2_cols', COLS.slice(0, 16));
  sheet(`<h3>Download Excel</h3><label class="f">Columns (tick and order by ticking)</label><div class="chips" id="xc">${COLS.map(c => `<button class="chip ${saved.includes(c) ? 'on' : ''}" data-c="${esc(c)}">${esc(c)}</button>`).join('')}</div>
  <label class="f">Only</label><select class="in" id="xf"><option value="">Everything I can see</option><option value="overdue">Fields with overdue events</option><option value="noloc">Fields without location</option><option value="waiting">Waiting for approval</option></select>
  <div class="btns" style="margin-top:12px"><button class="btn pri" id="xg">Download fields</button><button class="btn" id="xe">Download events</button><button class="btn" onclick="closeSheet()">Close</button></div>`, p => {
    let sel = saved.slice(); $$('#xc .chip', p).forEach(b => b.onclick = () => { const c = b.dataset.c; if (sel.includes(c)) sel = sel.filter(x => x !== c); else sel.push(c); b.classList.toggle('on'); ls.set('spm2_cols', sel); });
    p.querySelector('#xg').onclick = () => { const fil = p.querySelector('#xf').value; const rows = [];
      (S.D.fields || []).filter(x => !x.deleted_at).forEach(x => { const f = farmerOf(x); if (!f || f.deleted_at) return; const ev = fieldEvents(x), od = ev.filter(e => e.state === 'overdue').length;
        if (fil === 'overdue' && !od) return; if (fil === 'noloc' && x.lat != null) return; if (fil === 'waiting' && x.approval !== 'waiting' && f.status !== 'waiting') return;
        const lv = lastVisit(x.id); const all = {'Farmer ID': f.code, Farmer: f.name, Father: f.father, Mobile: maskMobile(f.mobile), Village: f.village, Mandal: f.mandal, District: f.district, State: f.state, Company: companyName(f.company_id), Organizer: userName(f.organizer_id), 'Sub-organizer': userName(f.sub_organizer_id), 'Field staff': userName(f.field_staff_id), Status: f.status, Acres: x.acres, 'Survey no': x.survey_no, Variety: varietyName(x.variety_id), Season: (byId('seasons', x.season_id) || {}).name, Irrigation: x.irrigation, 'Foundation seed date': dmy(x.fs_delivered_on), 'Sowing date': dmy(x.sown_on), 'Field status': x.status, Latitude: x.lat, Longitude: x.lng, 'Location link': x.lat ? mapsLink(x.lat, x.lng) : '', 'Overdue events': od, 'Last visit': lv ? dmy(lv.start_at.slice(0, 10)) : '', 'Harvest kg': sum((S.D.harvests || []).filter(h => h.field_id === x.id), h => h.weight_kg)};
        rows.push(Object.fromEntries(sel.map(c => [c, all[c]]))); });
      exportXlsx('fields', {Fields: rows}); };
    p.querySelector('#xe').onclick = () => { const rows = []; (S.D.fields || []).filter(x => !x.deleted_at).forEach(x => { const f = farmerOf(x) || {}; fieldEvents(x).forEach(e => rows.push({'Farmer ID': f.code, Farmer: f.name, Village: f.village, Variety: varietyName(x.variety_id), Event: e.ev.name, Priority: e.ev.priority, Expected: dmy(e.expected), 'Done on': dmy(e.done_on), Status: e.state, 'Days late': e.late, Note: e.mark ? e.mark.note : ''})); }); exportXlsx('events', {Events: rows}); };
  });
}
function reportText(days) {
  const from = addDays(today(), -days + 1), v = (S.D.visits || []).filter(x => x.start_at.slice(0, 10) >= from), m = (S.D.marks || []).filter(x => (x.done_on || '') >= from), due = allDue();
  const nf = visibleFarmers().filter(f => f.created_at.slice(0, 10) >= from).length;
  return `${S.me.full_name} — ${days === 1 ? 'Daily' : days === 7 ? 'Weekly' : 'Monthly'} report ${dmy(from)} to ${dmy(today())}\n\nFarmers: ${visibleFarmers().length} (${nf} new)\nAcres: ${num(sum((S.D.fields || []).filter(f => !f.deleted_at), f => f.acres))}\nField visits: ${v.length}\nEvents done: ${m.filter(x => !x.skipped).length}\nOverdue now: ${due.filter(d => d.state === 'overdue').length}\nDue today: ${due.filter(d => d.state === 'today').length}\nFields without location: ${(S.D.fields || []).filter(f => !f.deleted_at && f.lat == null).length}`;
}
function teamReport() {
  sheet(`<h3>Report</h3><div class="chips"><button class="chip on" data-d="7">Weekly</button><button class="chip" data-d="30">Monthly</button></div><pre id="rtx" style="white-space:pre-wrap;font:14px/1.5 inherit">${esc(reportText(7))}</pre>
  <div class="btns"><button class="btn" onclick="window.print()">Print / PDF</button><a class="btn" id="rwa" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(reportText(7))}">WhatsApp</a><button class="btn" onclick="closeSheet()">Close</button></div>`, p => $$('[data-d]', p).forEach(b => b.onclick = () => { $$('[data-d]', p).forEach(z => z.classList.toggle('on', z === b)); const t = reportText(+b.dataset.d); p.querySelector('#rtx').textContent = t; p.querySelector('#rwa').href = 'https://wa.me/?text=' + encodeURIComponent(t); }));
}
function dailySummary() { const t = reportText(1); sheet(`<h3>Daily summary</h3><pre style="white-space:pre-wrap;font:14px/1.5 inherit">${esc(t)}</pre><div class="btns"><a class="btn pri" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(t)}">Send on WhatsApp</a><button class="btn" onclick="closeSheet()">Close</button></div>`); }

/* ---------- TV mode (167, 175) ---------- */
let tvTimer = null;
function vTV() { return `<div class="wrap tv" id="tv"></div>`; }
function bindTV() {
  $('#nav').hidden = true; let i = 0; const screens = [() => { const due = allDue(); return `<h1>Season ${esc((currentSeason() || {}).name || '')}</h1><div class="tiles"><div class="tile"><b>${visibleFarmers().length}</b><span>Farmers</span></div><div class="tile"><b>${num(sum((S.D.fields || []).filter(f => !f.deleted_at), f => f.acres))}</b><span>Acres</span></div><div class="tile bad"><b>${due.filter(d => d.state === 'overdue').length}</b><span>Overdue</span></div><div class="tile warn"><b>${due.filter(d => d.state === 'today').length}</b><span>Due today</span></div></div>`; },
    () => leagueCard(), () => byOrganizerCard(allDue()), () => isolationCard()];
  const show = () => { const el = $('#tv'); if (!el) { clearInterval(tvTimer); return; } el.innerHTML = screens[i++ % screens.length]() + `<p class="mut sm">${new Date().toLocaleTimeString('en-IN')} · tap to leave TV mode</p>`; el.onclick = () => { clearInterval(tvTimer); go('reports'); }; };
  show(); clearInterval(tvTimer); tvTimer = setInterval(async () => { if (i % 20 === 0 && can(175)) { await loadData(true); } show(); }, 15000);
}

/* ---------- problems: disease, pest, complaint (78, 108, 126, 144, 148, 188, 210) ---------- */
function reportForm(farmerId, fieldId) {
  sheet(`<h3>Report a problem</h3><label class="f">Type</label><div class="chips" id="rp_k">${[['disease', 'Disease'], ['pest', 'Pest'], ['complaint', 'Farmer complaint'], ['isolation', 'Maize field nearby'], ['other', 'Other']].map(([k, l], i) => `<button class="chip ${i === 0 ? 'on' : ''}" data-v="${k}">${l}</button>`).join('')}</div>
  <label class="f">What do you see?</label><textarea class="in" id="rp_n"></textarea><button class="btn sm" id="rp_ph" style="margin-top:8px">Add photo</button><span class="sm mut" id="rp_c"></span>
  <div class="btns" style="margin-top:12px"><button class="btn pri" id="rp_s">Send</button><button class="btn" onclick="closeSheet()">Cancel</button></div>`, p => {
    let kind = 'disease', photos = [], fx = null; $$('#rp_k .chip', p).forEach(c => c.onclick = () => { kind = c.dataset.v; $$('#rp_k .chip', p).forEach(z => z.classList.toggle('on', z === c)); });
    p.querySelector('#rp_ph').onclick = async () => { try { fx = fx || await gpsFix({maxMs: 15000, need: 50}).catch(() => null); photos.push(await uploadPhoto(await pickPhoto(fx))); p.querySelector('#rp_c').textContent = ` ${photos.length} photo(s)`; } catch (e) { toast(e.message); } };
    p.querySelector('#rp_s').onclick = async () => { const note = p.querySelector('#rp_n').value.trim(); if (!note && !photos.length) return toast('Write what you see or add a photo');
      try { const r = await save('spm_reports', {kind, farmer_id: farmerId || null, field_id: fieldId || null, note, photos, lat: fx && fx.lat, lng: fx && fx.lng}); (S.D.reports = S.D.reports || []).unshift(r); closeSheet(); toast('Report sent'); render(); } catch (e) { toast(e.message); } };
  });
}
function vProblems() {
  const r = S.D.reports || [];
  return hdr('Problems', `${r.filter(x => x.status !== 'closed').length} open`) + `<div class="wrap"><div class="card"><div class="list">${r.map(x => { const f = byId('farmers', x.farmer_id) || {}; return `<div class="it" onclick="problemSheet('${x.id}')"><div class="main"><b>${esc(x.kind)} · ${esc(f.name || 'No farmer')}</b><span>${dt(x.at)} · ${esc(userName(x.by_user) || (x.by_farmer ? 'From farmer' : ''))} · ${esc(x.note).slice(0, 60)}</span></div><div class="side"><span class="tag ${x.status === 'closed' ? 'ok' : 'warn'}">${x.status.replace('_', ' ')}</span></div></div>`; }).join('') || '<p class="mut">No problems reported.</p>'}</div></div></div>`;
}
function problemSheet(id) {
  const x = (S.D.reports || []).find(r => r.id === id); const f = byId('farmers', x.farmer_id) || {};
  sheet(`<h3>${esc(x.kind)} · ${esc(f.name || '')}</h3><p>${esc(x.note)}</p>${photoStrip(x.photos)}<p class="sm mut">${dt(x.at)}${x.lat ? ` · <a target="_blank" rel="noopener" href="${mapsLink(x.lat, x.lng)}">location</a>` : ''}</p>${x.reply ? `<p><b>Reply:</b> ${esc(x.reply)}</p>` : ''}
  ${S.me && !['viewer'].includes(S.me.role) ? `<label class="f">Reply / action taken</label><input class="in" id="pr_r" value="${esc(x.reply)}"><div class="btns" style="margin-top:12px"><button class="btn" data-s="in_progress">In progress</button><button class="btn okb" data-s="closed">Close problem</button></div>` : ''}<button class="btn" style="margin-top:8px" onclick="closeSheet()">Close</button>`, p => {
    hydratePhotos(p); $$('[data-s]', p).forEach(b => b.onclick = async () => { try { const r = await save('spm_reports', {status: b.dataset.s, reply: p.querySelector('#pr_r').value, ...(b.dataset.s === 'closed' ? {closed_by: S.me.id, closed_at: new Date().toISOString()} : {})}, {id}); Object.assign(x, r); closeSheet(); render(); } catch (e) { toast(e.message); } }); });
}
function vGallery() {
  const ph = []; (S.D.visits || []).forEach(v => (v.photos || []).forEach(p => ph.push({p, v}))); const by = {}; ph.forEach(o => (by[o.v.stage || 'No stage'] = by[o.v.stage || 'No stage'] || []).push(o));
  return hdr('Field photos', ph.length + ' photos') + `<div class="wrap">${Object.entries(by).map(([st, arr]) => `<div class="card"><h2>${esc(st)} (${arr.length})</h2><div class="ph">${arr.slice(0, 40).map(o => `<img data-ph="${esc(o.p)}" alt="${esc((byId('farmers', o.v.farmer_id) || {}).name)}" onclick="visitSheet('${o.v.id}')">`).join('')}</div></div>`).join('') || '<div class="card mut">No photos yet.</div>'}</div>`;
}
