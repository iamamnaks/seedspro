// Offline shell: app files come from the cache when there is no network; data always goes to the server.
const C = 'spm2-v1';
const FILES = ['./', 'index.html', 'css/app.css', 'js/core.js', 'js/staff.js', 'js/track.js', 'js/team.js', 'js/money.js', 'js/reports.js', 'js/settings.js', 'js/farmer.js', 'js/main.js', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png', 'vendor/leaflet.js', 'vendor/leaflet.css', 'vendor/xlsx.mini.min.js'];
self.addEventListener('install', e => { e.waitUntil(caches.open(C).then(c => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== C).map(x => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  e.respondWith(fetch(e.request).then(r => { const copy = r.clone(); caches.open(C).then(c => c.put(e.request, copy)); return r; }).catch(() => caches.match(e.request).then(r => r || caches.match('index.html'))));
});
